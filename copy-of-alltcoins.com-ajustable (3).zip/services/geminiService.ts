
import { GoogleGenAI, Type } from "@google/genai";
import { NewsArticle } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export interface CryptoInsight {
  text: string;
  sentiment: 'Bullish' | 'Bearish' | 'Neutral';
  score: number;
  sources: any[];
}

// --- FALLBACK IMAGE BANK (When API Credits Run Dry) ---
const FALLBACK_IMAGES: Record<string, string[]> = {
  'bitcoin': [
    'https://images.unsplash.com/photo-1518546305927-5a555bb7020d?q=80&w=1200&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1621416894569-0f39ed31d247?q=80&w=1200&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1516245834210-c4c14278733f?q=80&w=1200&auto=format&fit=crop'
  ],
  'ethereum': [
    'https://images.unsplash.com/photo-1622790698141-94e30457ef12?q=80&w=1200&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=1200&auto=format&fit=crop'
  ],
  'tech': [
    'https://images.unsplash.com/photo-1639322537228-f710d846310a?q=80&w=1200&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?q=80&w=1200&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=1200&auto=format&fit=crop'
  ],
  'regulation': [
    'https://images.unsplash.com/photo-1589829085413-56de8ae18c73?q=80&w=1200&auto=format&fit=crop', // Gavel/Law
    'https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=1200&auto=format&fit=crop'  // Business/Suit
  ]
};

const getBackupImage = (title: string): string => {
  const t = title.toLowerCase();
  let category = 'tech';
  if (t.includes('bitcoin') || t.includes('btc')) category = 'bitcoin';
  else if (t.includes('ethereum') || t.includes('eth') || t.includes('defi')) category = 'ethereum';
  else if (t.includes('sec') || t.includes('law') || t.includes('regulation') || t.includes('ban')) category = 'regulation';
  
  const images = FALLBACK_IMAGES[category];
  return images[Math.floor(Math.random() * images.length)];
};

// ... (Existing Mock Data Code remains same, keeping it concise for the update) ...
const getMockNews = (count: number = 5): NewsArticle[] => {
  const news: NewsArticle[] = [
    {
      title: "Bitcoin Miners Pivot to AI Compute Amid Halving Pressure",
      url: "#",
      source: "CryptoReporter",
      published_at: new Date().toISOString(),
      summary: "Major mining firms are repurposing infrastructure for high-performance computing as BTC rewards decrease.",
      sentiment: "neutral",
      category: "Mining"
    },
    {
      title: "DeFi TVL Surges past $100B as Yield Farmers Return",
      url: "#",
      source: "BlockchainDaily",
      published_at: new Date(Date.now() - 3600000 * 2).toISOString(),
      summary: "Decentralized finance protocols see massive inflows driven by liquid restaking narratives.",
      sentiment: "positive",
      category: "DeFi"
    },
    {
      title: "SEC Delays Ethereum ETF Decision, Market Reacts",
      url: "#",
      source: "GlobalRegs",
      published_at: new Date(Date.now() - 3600000 * 5).toISOString(),
      summary: "Regulatory uncertainty continues as the commission requests further public comment.",
      sentiment: "negative",
      category: "Regulation"
    },
    {
      title: "New Layer 2 Scaling Solution Promises Zero-Gas Transactions",
      url: "#",
      source: "TechWire",
      published_at: new Date(Date.now() - 3600000 * 8).toISOString(),
      summary: "Innovative zk-rollup technology aims to eliminate gas fees for end users.",
      sentiment: "positive",
      category: "Altcoins"
    },
    {
      title: "Institutional Accumulation of Bitcoin Hits 3-Year High",
      url: "#",
      source: "MarketWatch",
      published_at: new Date(Date.now() - 3600000 * 12).toISOString(),
      summary: "Wallet analysis shows smart money is aggressively buying the dip.",
      sentiment: "positive",
      category: "Bitcoin"
    }
  ];
  return news.slice(0, count);
};

const getMockAssetNews = (symbol: string): NewsArticle[] => {
  return [
    {
      title: `${symbol} Technical Analysis: Approaching Key Support`,
      url: "#",
      source: "TradingView",
      published_at: new Date().toISOString(),
      summary: `Market indicators for ${symbol} suggest a potential reversal zone as volume profiles stabilize.`,
      sentiment: "neutral",
      category: "Altcoins"
    },
    {
      title: `${symbol} Network Activity Shows Steady Growth`,
      url: "#",
      source: "OnChainData",
      published_at: new Date(Date.now() - 3600000 * 4).toISOString(),
      summary: "Active address count and transaction throughput have increased over the last week.",
      sentiment: "positive",
      category: "Altcoins"
    },
    {
      title: `Community Sentiment for ${symbol} Remains Strong`,
      url: "#",
      source: "SocialMetrics",
      published_at: new Date(Date.now() - 3600000 * 24).toISOString(),
      summary: "Social media engagement metrics indicate sustained interest from the retail sector.",
      sentiment: "positive",
      category: "Altcoins"
    }
  ];
};

export const getCryptoInsights = async (coinName?: string): Promise<CryptoInsight> => {
  const model = 'gemini-3-flash-preview';
  const query = coinName 
    ? `Provide a professional market analysis for ${coinName}. 
       Include current trends, potential outlook, and a sentiment score from 0 (Extremely Bearish) to 100 (Extremely Bullish).
       Format your response as a JSON object with keys: "analysis" (string), "sentiment" ("Bullish", "Bearish", or "Neutral"), and "score" (number).`
    : `Provide a professional summary of the overall cryptocurrency market.
       Include a general sentiment score from 0 to 100.
       Format your response as a JSON object with keys: "analysis" (string), "sentiment" ("Bullish", "Bearish", or "Neutral"), and "score" (number).`;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: query,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json"
      }
    });
    
    const data = JSON.parse(response.text || "{}");
    
    return {
      text: data.analysis || "Analysis currently unavailable.",
      sentiment: data.sentiment || 'Neutral',
      score: data.score ?? 50,
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  } catch (error) {
    return { 
      text: coinName 
        ? `Automated Analysis for ${coinName}: Market structure indicates a neutral trend with high volatility. Traders are advised to watch for breakouts above immediate resistance levels. (AI limit reached, showing fallback analysis)` 
        : "Global Market Analysis: The cryptocurrency market is currently experiencing a period of consolidation. Institutional inflows remain a key driver, while macroeconomic headwinds persist. (AI limit reached, showing fallback analysis)", 
      sentiment: 'Neutral', 
      score: 50, 
      sources: [] 
    };
  }
};

export const getAssetNews = async (symbol: string): Promise<NewsArticle[]> => {
  const model = 'gemini-3-pro-preview';
  try {
    const response = await ai.models.generateContent({
      model,
      contents: `Find the latest 10 most relevant news articles specifically about ${symbol} cryptocurrency. 
      For each article, analyze the sentiment as positive, negative, or neutral.
      Format the output as a JSON array of objects with title, url, source, published_at, summary, and sentiment.`,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              url: { type: Type.STRING },
              source: { type: Type.STRING },
              published_at: { type: Type.STRING },
              summary: { type: Type.STRING },
              sentiment: { type: Type.STRING }
            },
            required: ["title", "url", "source", "sentiment"]
          }
        }
      }
    });
    return JSON.parse(response.text || "[]");
  } catch (error) {
    return getMockAssetNews(symbol);
  }
};

export const getLatestNews = async (): Promise<NewsArticle[]> => {
  const model = 'gemini-3-pro-preview';
  try {
    const response = await ai.models.generateContent({
      model,
      contents: `Find 45 distinct, high-impact breaking cryptocurrency news stories from the last 36 hours.
      
      CRITICAL: You MUST distribute the articles across these exact categories, with at least 3-4 articles PER CATEGORY:
      'Bitcoin', 'Altcoins', 'Mining', 'Regulation', 'DeFi', 'Tech', 'Web3', 'Blockchain', 'NFTs', 'APIs', 'Trading', 'Wallets', 'Layer2'.

      Focus on headlines that are engaging, controversial, or highly significant (e.g., massive price moves, regulatory crackdowns, technological breakthroughs).
      
      Format as a JSON list of objects.`,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              url: { type: Type.STRING },
              source: { type: Type.STRING },
              published_at: { type: Type.STRING },
              summary: { type: Type.STRING },
              sentiment: { type: Type.STRING, description: "positive, negative, or neutral" },
              category: { type: Type.STRING }
            },
            required: ["title", "url", "source", "published_at", "category"]
          }
        }
      }
    });

    return JSON.parse(response.text || "[]");
  } catch (error) {
    return getMockNews(12);
  }
};

export const generateNewsThumbnail = async (title: string): Promise<string | null> => {
  // RANDOMIZE STYLES to prevent "template" look.
  // We want: Candle, Graph, Logo, Meme, Abstract.
  const styles = [
    `A glowing, neon Japanese Candlestick chart pattern floating in a dark void. Specific to the mood of: "${title}". Green candles if bullish, Red if bearish. High contrast.`,
    `A complex, futuristic 3D financial graph interface. Holographic data lines. Dark cyberpunk aesthetic. No text.`,
    `A high-quality 3D metallic cryptocurrency coin logo related to the news topic "${title}", sitting on a dark obsidian table. Cinematic lighting.`,
    `An abstract, artistic digital interpretation of "${title}". Glitch art style, vibrant colors against deep black.`,
    `A clean, minimalist financial network node diagram. Glowing connections. Deep blue and purple neon.`,
  ];
  
  const randomStyle = styles[Math.floor(Math.random() * styles.length)];

  // Plan A: Try Gemini Flash Image
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          { text: `Generate a thumbnail image. Style: ${randomStyle}` }
        ]
      },
      config: {
        imageConfig: { aspectRatio: "16:9" }
      }
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
  } catch (error) {
     // Fallback handled by caller usually or return null to trigger static fallback
  }
  
  return getBackupImage(title);
};
