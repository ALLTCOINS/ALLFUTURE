
import { Coin, GlobalData, SearchResultItem } from '../types';

const BASE_URL = 'https://api.coingecko.com/api/v3';

const cache: Record<string, { data: any; timestamp: number }> = {};
const CACHE_DURATION = 60 * 1000;

// Helper to get consistent mock images
const getMockImage = (symbol: string) => {
  const s = symbol.toLowerCase();
  // Majors
  if (s === 'btc') return 'https://assets.coingecko.com/coins/images/1/large/bitcoin.png';
  if (s === 'eth') return 'https://assets.coingecko.com/coins/images/279/large/ethereum.png';
  if (s === 'usdt') return 'https://assets.coingecko.com/coins/images/325/large/Tether.png';
  if (s === 'bnb') return 'https://assets.coingecko.com/coins/images/825/large/bnb-icon2_2x.png';
  if (s === 'sol') return 'https://assets.coingecko.com/coins/images/4128/large/solana.png';
  if (s === 'xrp') return 'https://assets.coingecko.com/coins/images/44/large/xrp-symbol-white-128.png';
  if (s === 'usdc') return 'https://assets.coingecko.com/coins/images/6319/large/USD_Coin_icon.png';
  if (s === 'ada') return 'https://assets.coingecko.com/coins/images/975/large/cardano.png';
  if (s === 'avax') return 'https://assets.coingecko.com/coins/images/12559/large/Avalanche_Circle_RedWhite_Trans.png';
  
  // Memes
  if (s === 'doge') return 'https://assets.coingecko.com/coins/images/5/large/dogecoin.png';
  if (s === 'shib') return 'https://assets.coingecko.com/coins/images/11939/large/shiba.png';
  if (s === 'pepe') return 'https://assets.coingecko.com/coins/images/29850/large/pepe-token.png';
  if (s === 'wif') return 'https://assets.coingecko.com/coins/images/33566/large/dogwifhat.jpg';
  if (s === 'floki') return 'https://assets.coingecko.com/coins/images/16746/large/FLOKI.png';
  if (s === 'bonk') return 'https://assets.coingecko.com/coins/images/28600/large/bonk.jpg';
  
  // RWA / DeFi / Gaming
  if (s === 'ondo') return 'https://assets.coingecko.com/coins/images/27443/large/ondo.png';
  if (s === 'om') return 'https://assets.coingecko.com/coins/images/12678/large/mantra.png';
  if (s === 'cfg') return 'https://assets.coingecko.com/coins/images/15396/large/centrifuge.png';
  if (s === 'imx') return 'https://assets.coingecko.com/coins/images/17233/large/immutableX_symbol.png';
  if (s === 'gala') return 'https://assets.coingecko.com/coins/images/12493/large/gala.png';
  if (s === 'sand') return 'https://assets.coingecko.com/coins/images/12129/large/sandbox_logo.jpg';
  if (s === 'mana') return 'https://assets.coingecko.com/coins/images/878/large/decentraland-token.png';
  
  // CEX
  if (s === 'okb') return 'https://assets.coingecko.com/coins/images/4463/large/WeChat_Image_20220118095618.png';
  if (s === 'kcs') return 'https://assets.coingecko.com/coins/images/1047/large/kucoin.png';
  if (s === 'leo') return 'https://assets.coingecko.com/coins/images/8418/large/leo-token.png';
  if (s === 'cro') return 'https://assets.coingecko.com/coins/images/7310/large/cypto.png';
  
  return `https://assets.coingecko.com/coins/images/1/large/bitcoin.png`; // Fallback
};

const generateMockCoins = (count: number, page: number, category: string = ''): Coin[] => {
  let symbols: string[] = [];
  let names: string[] = [];
  let prices: number[] = [];

  // DEFINING CATEGORY SPECIFIC MOCK DATA
  if (category === 'meme-token' || category === 'meme') {
     symbols = ['DOGE', 'SHIB', 'PEPE', 'WIF', 'FLOKI', 'BONK', 'MEME', 'BOME', 'BRETT', 'POPCAT'];
     names = ['Dogecoin', 'Shiba Inu', 'Pepe', 'dogwifhat', 'Floki', 'Bonk', 'Memecoin', 'Book of Meme', 'Brett', 'Popcat'];
     prices = [0.16, 0.000025, 0.000008, 3.20, 0.00018, 0.000024, 0.025, 0.012, 0.08, 0.45];
  } 
  else if (category === 'non-fungible-tokens-nft') {
     symbols = ['APE', 'BLUR', 'IMX', 'AXS', 'SAND', 'MANA', 'RARI', 'SUPER', 'LOOKS', 'ILV'];
     names = ['ApeCoin', 'Blur', 'Immutable', 'Axie Infinity', 'The Sandbox', 'Decentraland', 'Rarible', 'SuperVerse', 'LooksRare', 'Illuvium'];
     prices = [1.20, 0.35, 2.10, 7.50, 0.45, 0.42, 2.50, 0.95, 0.12, 85.00];
  } 
  else if (category === 'decentralized-finance-defi') {
     symbols = ['UNI', 'AAVE', 'MKR', 'LDO', 'CRV', 'SNX', 'COMP', 'PENDLE', 'RPL', 'FXS'];
     names = ['Uniswap', 'Aave', 'Maker', 'Lido DAO', 'Curve DAO', 'Synthetix', 'Compound', 'Pendle', 'Rocket Pool', 'Frax Share'];
     prices = [7.50, 92.00, 2800.00, 2.10, 0.45, 2.80, 55.00, 4.20, 22.00, 4.50];
  } 
  else if (category === 'gaming') {
     symbols = ['IMX', 'GALA', 'BEAM', 'AXS', 'SAND', 'MANA', 'ILV', 'PRIME', 'PIXEL', 'YGG'];
     names = ['Immutable', 'Gala', 'Beam', 'Axie Infinity', 'The Sandbox', 'Decentraland', 'Illuvium', 'Echelon Prime', 'Pixels', 'Yield Guild Games'];
     prices = [2.10, 0.04, 0.025, 7.50, 0.45, 0.42, 85.00, 18.00, 0.40, 0.85];
  }
  else if (category === 'real-world-assets' || category === 'rwa') {
     symbols = ['ONDO', 'OM', 'CFG', 'MPL', 'GFI', 'NXRA', 'CTC', 'CPOOL', 'RIO', 'PRO'];
     names = ['Ondo', 'Mantra', 'Centrifuge', 'Maple', 'Goldfinch', 'AllianceBlock', 'Creditcoin', 'Clearpool', 'Realio', 'Propy'];
     prices = [0.95, 0.75, 0.65, 15.00, 4.20, 0.12, 0.65, 0.18, 1.80, 2.40];
  }
  else if (category === 'centralized-exchange-token-cex') {
     symbols = ['BNB', 'LEO', 'OKB', 'KCS', 'CRO', 'BGB', 'GT', 'MX', 'HT', 'WOO'];
     names = ['BNB', 'LEO Token', 'OKB', 'KuCoin Token', 'Cronos', 'Bitget Token', 'GateToken', 'MX Token', 'Huobi Token', 'WOO'];
     prices = [580.00, 5.90, 52.00, 10.50, 0.12, 1.15, 8.50, 4.20, 0.60, 0.35];
  }
  else {
     // Default / All Assets
     symbols = ['BTC', 'ETH', 'USDT', 'BNB', 'SOL', 'XRP', 'USDC', 'ADA', 'AVAX', 'DOGE', 'DOT', 'TRX', 'LINK', 'MATIC', 'BCH', 'NEAR', 'LTC', 'ICP', 'DAI', 'UNI'];
     names = ['Bitcoin', 'Ethereum', 'Tether', 'BNB', 'Solana', 'XRP', 'USDC', 'Cardano', 'Avalanche', 'Dogecoin', 'Polkadot', 'TRON', 'Chainlink', 'Polygon', 'Bitcoin Cash', 'Near', 'Litecoin', 'Internet Computer', 'Dai', 'Uniswap'];
     prices = [64230, 3450, 1.00, 580, 145, 0.62, 1.00, 0.45, 38.00, 0.16, 7.20, 0.12, 17.50, 0.72, 450.00, 6.80, 82.00, 12.50, 1.00, 7.50];
  }

  return Array.from({ length: count }, (_, i) => {
    const globalIdx = i + (page - 1) * count;
    // Loop through our specific lists
    const index = globalIdx % symbols.length;
    
    // Add randomness to the base price to make it look alive
    const basePrice = prices[index] || 10;
    const currentPrice = Math.max(0.00000001, basePrice + (Math.random() - 0.5) * (basePrice * 0.05));

    // Realistic Market Cap Calculation to prevent negative numbers
    let mockSupply = 0;
    if (currentPrice > 1000) mockSupply = 19000000 + (globalIdx * 10000); // BTC-like
    else if (currentPrice > 10) mockSupply = 100000000 + (globalIdx * 1000000); // ETH/SOL-like
    else if (currentPrice > 1) mockSupply = 500000000 + (globalIdx * 5000000); // USDT/MATIC-like
    else mockSupply = 10000000000 + (globalIdx * 100000000); // Meme-like

    const marketCap = currentPrice * mockSupply * (0.8 + Math.random() * 0.4);

    return {
      id: `mock-${symbols[index].toLowerCase()}-${globalIdx}`,
      symbol: symbols[index].toLowerCase(),
      name: names[index],
      image: getMockImage(symbols[index]), 
      current_price: currentPrice,
      market_cap: marketCap,
      market_cap_rank: globalIdx + 1,
      circulating_supply: mockSupply,
      price_change_percentage_24h: (Math.random() - 0.5) * 8,
      price_change_percentage_1h_in_currency: (Math.random() - 0.5) * 2,
      price_change_percentage_7d_in_currency: (Math.random() - 0.5) * 15,
      total_volume: marketCap * 0.05 * (0.8 + Math.random() * 0.4),
      sparkline_in_7d: {
        price: Array.from({ length: 40 }, () => currentPrice * (1 + (Math.random() - 0.5) * 0.1))
      }
    };
  });
};

const generateMockGlobalData = (): GlobalData => ({
  data: {
    total_market_cap: { usd: 2650000000000 },
    total_volume: { usd: 92000000000 },
    market_cap_percentage: { btc: 52.8, eth: 17.2 },
    market_cap_change_percentage_24h_usd: 0.85,
    active_cryptocurrencies: 24500,
    markets: 700
  }
});

const generateMockHistory = (days: number = 7) => {
  const data = [];
  const now = Date.now();
  const startPrice = 60000 + Math.random() * 5000;
  const points = days * 24;
  for (let i = 0; i < points; i++) {
    data.push({
      time: now - (points - i) * 3600000,
      price: startPrice + Math.sin(i / 15) * 3000 + (Math.random() - 0.5) * 1000
    });
  }
  return data;
};

const resilientFetch = async (url: string, retries = 2): Promise<Response> => {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 8000);

  try {
    const response = await fetch(url, { signal: controller.signal, mode: 'cors' });
    clearTimeout(timeoutId);
    return response;
  } catch (err) {
    clearTimeout(timeoutId);
    if (retries > 0) {
      await new Promise(r => setTimeout(r, 1000 * (3 - retries)));
      return resilientFetch(url, retries - 1);
    }
    throw err;
  }
};

const getFromCache = (key: string) => {
  const entry = cache[key];
  if (entry && Date.now() - entry.timestamp < CACHE_DURATION) return entry.data;
  return null;
};

const setToCache = (key: string, data: any) => {
  cache[key] = { data, timestamp: Date.now() };
};

export const fetchTopCoins = async (
  page: number = 1, 
  perPage: number = 75, 
  category: string = ''
): Promise<Coin[]> => {
  const cacheKey = `coins-${page}-${perPage}-${category}`;
  const cached = getFromCache(cacheKey);
  if (cached) return cached;

  try {
    let url = `${BASE_URL}/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=${perPage}&page=${page}&sparkline=true&price_change_percentage=1h,24h,7d`;
    
    // STRICT CATEGORY HANDLING
    if (category && category !== 'all') {
      url += `&category=${category}`;
    }
    
    const response = await resilientFetch(url);
    
    // Handle Rate Limiting (429) immediately with proper mock data
    if (response.status === 429) {
      // console.warn('Rate limit hit, using category-aware mock data');
      return generateMockCoins(perPage, page, category);
    }
    
    if (!response.ok) throw new Error(`HTTP Error ${response.status}`);
    const data = await response.json();
    
    if (Array.isArray(data) && data.length > 0) {
      setToCache(cacheKey, data);
      return data;
    }
    // Fallback if data array is empty
    return generateMockCoins(perPage, page, category);
  } catch (error) {
    // Silently fallback to mock data on error to prevent UI disruption
    return generateMockCoins(perPage, page, category);
  }
};

export const fetchSingleCoin = async (id: string): Promise<Coin | null> => {
  // If it's a mock coin, don't hit the API, return details from id
  if (id.startsWith('mock-')) {
     const parts = id.split('-');
     const symbol = parts[1] || 'btc';
     // Generate a fresh mock coin for detail view
     const mockData = generateMockCoins(1, 1, '')[0]; 
     const mockImage = getMockImage(symbol);
     return { 
        ...mockData, 
        id: id,
        symbol: symbol, 
        name: symbol.toUpperCase(), 
        image: mockImage 
     };
  }

  try {
    const url = `${BASE_URL}/coins/markets?vs_currency=usd&ids=${id}&sparkline=false&price_change_percentage=1h,24h,7d`;
    const response = await resilientFetch(url);
    if (!response.ok) return null;
    const data = await response.json();
    return data[0] || null;
  } catch (error) {
    return null;
  }
};

export const fetchGlobalMarketData = async (): Promise<GlobalData | null> => {
  const cacheKey = 'global-market';
  const cached = getFromCache(cacheKey);
  if (cached) return cached;

  try {
    const response = await resilientFetch(`${BASE_URL}/global`);
    if (!response.ok) return generateMockGlobalData();
    const data = await response.json();
    setToCache(cacheKey, data);
    return data;
  } catch (error) {
    return generateMockGlobalData();
  }
};

export const fetchCoinHistory = async (id: string, days: number = 7) => {
  const cacheKey = `history-${id}-${days}`;
  const cached = getFromCache(cacheKey);
  if (cached) return cached;

  try {
    const response = await resilientFetch(
      `${BASE_URL}/coins/${id}/market_chart?vs_currency=usd&days=${days}`
    );
    if (!response.ok) return generateMockHistory(days);
    const data = await response.json();
    const result = data.prices.map((p: [number, number]) => ({ time: p[0], price: p[1] }));
    setToCache(cacheKey, result);
    return result;
  } catch (error) {
    return generateMockHistory(days);
  }
};

export const fetchFearAndGreedIndex = async () => {
  const cacheKey = 'fear-and-greed';
  const cached = getFromCache(cacheKey);
  if (cached) return cached;

  try {
    const response = await fetch('https://api.alternative.me/fng/');
    if (!response.ok) throw new Error('Fear & Greed API failed');
    const data = await response.json();
    const result = {
      value: parseInt(data.data[0].value),
      classification: data.data[0].value_classification,
      timestamp: data.data[0].timestamp
    };
    setToCache(cacheKey, result);
    return result;
  } catch (error) {
    return { value: 50, classification: 'Neutral', timestamp: Date.now() / 1000 };
  }
};

export const searchGlobal = async (query: string): Promise<SearchResultItem[]> => {
  if (!query || query.length < 2) return [];
  
  const cacheKey = `search-${query.toLowerCase()}`;
  const cached = getFromCache(cacheKey);
  if (cached) return cached;

  try {
    const response = await resilientFetch(`${BASE_URL}/search?query=${encodeURIComponent(query)}`);
    if (!response.ok) throw new Error('Search failed');
    
    const data = await response.json();
    
    const coins: SearchResultItem[] = (data.coins || []).slice(0, 6).map((c: any) => ({
      id: c.id,
      name: c.name,
      symbol: c.symbol,
      thumb: c.thumb,
      market_cap_rank: c.market_cap_rank,
      type: 'coin'
    }));

    const nfts: SearchResultItem[] = (data.nfts || []).slice(0, 3).map((n: any) => ({
      id: n.id,
      name: n.name,
      symbol: n.symbol,
      thumb: n.thumb,
      type: 'nft'
    }));
    
    const results = [...coins, ...nfts];
    
    setToCache(cacheKey, results);
    return results;
  } catch (error) {
    const mockData: SearchResultItem[] = [
      { id: 'bitcoin', name: 'Bitcoin', symbol: 'BTC', thumb: 'https://assets.coingecko.com/coins/images/1/thumb/bitcoin.png', market_cap_rank: 1, type: 'coin' },
      { id: 'gomining-token', name: 'GoMining', symbol: 'GOMINING', thumb: 'https://assets.coingecko.com/coins/images/27049/thumb/gomining.png', market_cap_rank: 145, type: 'coin' },
      { id: 'ethereum', name: 'Ethereum', symbol: 'ETH', thumb: 'https://assets.coingecko.com/coins/images/279/thumb/ethereum.png', market_cap_rank: 2, type: 'coin' }
    ];
    return mockData.filter(i => i.name.toLowerCase().includes(query.toLowerCase()) || i.symbol.toLowerCase().includes(query.toLowerCase()));
  }
};
