
import React, { useState, useEffect, useMemo, useCallback, Suspense } from 'react';
import { 
  Search, Zap, Wallet, Star, BarChart3, Users, Settings, Grid, Lock, BookOpen, GraduationCap, Radio, Newspaper
} from 'lucide-react';
import { Coin, MarketStats, NewsArticle, Coupon } from './types';
import { fetchTopCoins, fetchGlobalMarketData, fetchCoinHistory } from './services/cryptoService';
import { getLatestNews, getCryptoInsights, CryptoInsight } from './services/geminiService';
import MarketHeader from './components/MarketHeader';
import Dashboard from './components/Dashboard';
import Starfield from './components/Starfield';
import Footer from './components/Footer';
import GlobalSearch from './components/GlobalSearch';
import KnowledgeBase from './components/KnowledgeBase';
import NewsTicker from './components/NewsTicker';
import NewsPortal from './components/NewsPortal';

// Lazy Load Heavy Components
const AssetDetail = React.lazy(() => import('./components/AssetDetail'));

type Category = 'all' | 'decentralized-finance-defi' | 'non-fungible-tokens-nft' | 'meme-token' | 'gaming' | 'real-world-assets' | 'centralized-exchange-token-cex';

const COUPONS: Coupon[] = [
  { 
    id: 'binance', 
    platform: 'Binance', 
    description: '100 USDT Credit', 
    link: 'https://accounts.binance.com/register?ref=ALLTCOINS', 
    code: 'ALLTCOINS', 
    color: 'text-[#F0B90B] bg-[#F0B90B]',
    logo: 'https://www.google.com/s2/favicons?domain=binance.com&sz=256' 
  },
  { 
    id: 'bybit', 
    platform: 'Bybit', 
    description: '$30k Sign-Up Bonus', 
    link: 'https://www.bybit.com/invite?ref=MW72XBY', 
    code: 'MW72XBY', 
    color: 'text-[#17181e] bg-[#17181e]',
    logo: 'https://www.google.com/s2/favicons?domain=bybit.com&sz=256'
  },
  { 
    id: 'okx', 
    platform: 'OKX', 
    description: '$10k Mystery Box', 
    link: 'https://okx.com/join/34729331', 
    code: '34729331', 
    color: 'text-white bg-white',
    logo: 'https://www.google.com/s2/favicons?domain=okx.com&sz=256'
  },
  { 
    id: 'bitget', 
    platform: 'Bitget', 
    description: '1,000 USDT Pack', 
    link: 'https://share.bitget.com/u/VH31BLC4', 
    code: 'YW0QTH5C', 
    color: 'text-[#00F0FF] bg-[#00F0FF]',
    logo: 'https://www.google.com/s2/favicons?domain=bitget.com&sz=256'
  },
  { 
    id: 'kucoin', 
    platform: 'Kucoin', 
    description: '700 USDT Gift', 
    link: 'https://www.kucoin.com/r/rf/CXEVU7LK', 
    code: 'CXEVU7LK', 
    color: 'text-[#00D09B] bg-[#00D09B]',
    logo: 'https://www.google.com/s2/favicons?domain=kucoin.com&sz=256'
  },
];

const CATEGORY_DEFINITIONS: Record<string, string> = {
  'all': 'Comprehensive view of all available digital assets',
  'decentralized-finance-defi': 'DeFi: Decentralized Finance - Open financial system without intermediaries',
  'non-fungible-tokens-nft': 'NFT: Non-Fungible Tokens - Unique digital ownership & collectibles',
  'gaming': 'GameFi: Play-to-earn ecosystems & metaverse economies',
  'real-world-assets': 'RWA: Real World Assets - Tokenized physical finance (Real Estate, Bonds)',
  'centralized-exchange-token-cex': 'CEX: Centralized Exchange - Tokens powering traditional crypto platforms',
  'meme-token': 'Meme: Community-driven viral tokens & internet culture'
};

const App: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<Category>('all');
  const [coins, setCoins] = useState<Coin[]>([]);
  const [marketStats, setMarketStats] = useState<MarketStats | null>(null);
  const [news, setNews] = useState<NewsArticle[]>([]);
  const [loading, setLoading] = useState(true);
  const [newsLoading, setNewsLoading] = useState(true);
  const [isDark, setIsDark] = useState(true);
  
  const [showWalletModal, setShowWalletModal] = useState(false);
  const [showKnowledgeBase, setShowKnowledgeBase] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [walletAddress, setWalletAddress] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const coinsPerPage = 100;

  const [selectedCoin, setSelectedCoin] = useState<Coin | null>(null);
  const [history, setHistory] = useState<{time: number; price: number}[]>([]);
  const [insight, setInsight] = useState<CryptoInsight | null>(null);
  
  // Watchlist State
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('favorites');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  
  const [viewMode, setViewMode] = useState<'all' | 'news'>('all');
  const [showWatchlistOnly, setShowWatchlistOnly] = useState(false);

  // Sorting State
  const [sortConfig, setSortConfig] = useState<{ key: keyof Coin; direction: 'asc' | 'desc' } | null>(null);

  useEffect(() => {
    localStorage.setItem('favorites', JSON.stringify(favorites));
  }, [favorites]);

  const toggleFavorite = useCallback((e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setFavorites(prev => 
      prev.includes(id) ? prev.filter(f => f !== id) : [...prev, id]
    );
  }, []);

  const handleSort = useCallback((key: keyof Coin) => {
    setSortConfig(prev => {
      let direction: 'asc' | 'desc' = 'desc';
      if (prev && prev.key === key && prev.direction === 'desc') {
        direction = 'asc';
      }
      return { key, direction };
    });
  }, []);

  // Reset to Home State
  const handleGoHome = useCallback(() => {
    setViewMode('all');
    setSelectedCoin(null);
    setActiveCategory('all');
    setShowWatchlistOnly(false);
    setCurrentPage(1);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const handleNavClick = (type: 'exchanges' | 'community' | 'products') => {
    if (type === 'exchanges') {
       setActiveCategory('centralized-exchange-token-cex');
       setViewMode('all');
       window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (type === 'community') {
       setActiveCategory('meme-token');
       setViewMode('all');
       window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (type === 'products') {
       // Scroll to tools section (bottom of dashboard)
       const element = document.getElementById('converter-widget');
       if (element) {
         element.scrollIntoView({ behavior: 'smooth', block: 'center' });
       } else {
         window.scrollTo({ top: 500, behavior: 'smooth' });
       }
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [coinsData, globalData] = await Promise.all([
          fetchTopCoins(currentPage, coinsPerPage, activeCategory === 'all' ? '' : activeCategory),
          fetchGlobalMarketData()
        ]);
        setCoins(coinsData);
        if (globalData) setMarketStats(globalData.data);
      } catch (error) {
        // Error logging removed to reduce console noise during fallback
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [currentPage, activeCategory]);

  useEffect(() => {
    const fetchNews = async () => {
        if (news.length === 0) {
            setNewsLoading(true);
            const newsData = await getLatestNews();
            setNews(newsData);
            setNewsLoading(false);
        }
    };
    setTimeout(fetchNews, 500);
  }, []); 

  useEffect(() => {
    if (isDark) document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
  }, [isDark]);

  const handleCoinSelect = useCallback(async (id: string) => {
    const existingCoin = coins.find(c => c.id === id);
    if (existingCoin) setSelectedCoin(existingCoin);
    
    const [fullCoinData, histData, insightData] = await Promise.all([
      existingCoin ? Promise.resolve(existingCoin) : import('./services/cryptoService').then(m => m.fetchSingleCoin(id)),
      fetchCoinHistory(id),
      existingCoin ? getCryptoInsights(existingCoin.name) : Promise.resolve(null)
    ]);
    
    if (fullCoinData) {
       setSelectedCoin(fullCoinData);
       if (!existingCoin) {
          const newInsight = await getCryptoInsights(fullCoinData.name);
          setInsight(newInsight);
       } else {
          setInsight(insightData);
       }
       setHistory(histData);
    }
  }, [coins]);

  const processedCoins = useMemo(() => {
    let result = [...coins];

    if (showWatchlistOnly) {
      result = result.filter(c => favorites.includes(c.id));
    }

    if (sortConfig) {
      result.sort((a, b) => {
        const valA = a[sortConfig.key] as number;
        const valB = b[sortConfig.key] as number;
        
        if (valA < valB) return sortConfig.direction === 'asc' ? -1 : 1;
        if (valA > valB) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }

    return result;
  }, [coins, showWatchlistOnly, favorites, sortConfig]);

  const connectWallet = () => {
    setLoading(true);
    setTimeout(() => {
      setIsConnected(true);
      setWalletAddress('0x71C...456f');
      setShowWalletModal(false);
      setLoading(false);
    }, 800);
  };

  const categories = [
    { id: 'all', label: 'All Markets' },
    { id: 'decentralized-finance-defi', label: 'DeFi' },
    { id: 'non-fungible-tokens-nft', label: 'NFTs' },
    { id: 'gaming', label: 'GameFi' },
    { id: 'real-world-assets', label: 'RWA' },
    { id: 'centralized-exchange-token-cex', label: 'CEX' },
    { id: 'meme-token', label: 'Meme' }
  ];

  return (
    <div className="min-h-screen font-mono text-slate-300 relative z-0 flex flex-col transition-colors duration-300 pb-0 bg-transparent">
      
      {/* Animated Starfield Background */}
      <Starfield />
      
      {/* Academy Modal */}
      <KnowledgeBase isOpen={showKnowledgeBase} onClose={() => setShowKnowledgeBase(false)} />

      {/* Navbar - Strict Square */}
      <nav className="sticky top-0 z-[50] bg-[#010409]/90 border-b border-white/10 backdrop-blur-md">
        
        {/* News Ticker Integration */}
        <NewsTicker news={news} />

        <div className="max-w-[1920px] mx-auto px-4 md:px-6 h-[64px] flex items-center justify-between gap-2 md:gap-4">
          
          <div className="flex items-center gap-2 md:gap-8 shrink-0">
            <div className="flex items-center gap-2 cursor-pointer group shrink-0" onClick={handleGoHome}>
               <div className="bg-brand-primary p-1 text-black group-hover:scale-110 transition-transform">
                 <Zap size={18} strokeWidth={3} />
               </div>
               <h1 className="text-sm md:text-lg font-black tracking-tighter uppercase leading-none text-white block">
                 ALLTCOINS<span className="text-brand-primary">.COM</span>
               </h1>
            </div>

            <div className="hidden lg:flex items-center gap-px font-bold text-[10px] uppercase tracking-wider bg-white/5 border border-white/10 p-1">
              <button 
                onClick={() => handleNavClick('exchanges')}
                className={`flex items-center gap-2 px-4 py-1.5 transition-all ${activeCategory === 'centralized-exchange-token-cex' ? 'bg-brand-primary text-black' : 'hover:text-white'}`}
              >
                Exchanges
              </button>
              <button 
                onClick={() => handleNavClick('community')}
                className={`flex items-center gap-2 px-4 py-1.5 transition-all ${activeCategory === 'meme-token' ? 'bg-brand-primary text-black' : 'hover:text-white'}`}
              >
                Community
              </button>
              <button 
                onClick={() => handleNavClick('products')}
                className="flex items-center gap-2 px-4 py-1.5 hover:text-white transition-all hover:bg-white/5"
              >
                <Settings size={12} /> Tools
              </button>
              <button 
                onClick={() => setShowKnowledgeBase(true)}
                className="flex items-center gap-2 px-4 py-1.5 hover:text-white transition-all hover:bg-white/5 text-slate-400"
              >
                <GraduationCap size={12} /> Academy
              </button>
              <button 
                onClick={() => setViewMode('news')}
                className={`flex items-center gap-2 px-4 py-1.5 transition-all ${viewMode === 'news' ? 'bg-brand-primary text-black' : 'hover:text-white hover:bg-white/5 text-slate-400'}`}
              >
                <Newspaper size={12} /> Crypto News
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2 md:gap-3 flex-1 justify-end min-w-0">
            <GlobalSearch 
              onCoinSelect={handleCoinSelect}
              onNavigate={handleNavClick}
            />

            <button onClick={() => setShowWalletModal(true)} className="bg-brand-primary text-black px-3 py-1.5 md:px-4 md:py-1.5 text-[10px] md:text-xs font-black uppercase tracking-wider hover:bg-white transition-colors flex items-center gap-2 shrink-0">
              <Wallet size={14} />
              <span className="hidden sm:inline">{isConnected ? walletAddress : 'Connect'}</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content Switcher */}
      {viewMode !== 'all' ? (
        <NewsPortal 
          news={news} 
          loading={newsLoading} 
          onRead={(article) => { }}
          onClose={() => setViewMode('all')} 
        />
      ) : (
        <main className="flex-1 max-w-[1920px] mx-auto p-4 md:p-6 w-full relative z-0 min-h-screen">
           
           {/* Categories Toolbar & Sub-Nav */}
           <div className="mb-6 sticky top-20 z-30 pointer-events-none">
              <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between pointer-events-auto gap-4 lg:gap-0">
                
                {/* Left: Categories with Tooltips */}
                <div className="flex gap-1 bg-[#010409]/90 p-1 border border-white/10 overflow-x-auto scrollbar-hide w-full lg:w-auto max-w-full">
                  {categories.map(cat => (
                    <div key={cat.id} className="relative group">
                        <button
                          onClick={() => { setActiveCategory(cat.id as Category); setCurrentPage(1); setViewMode('all'); setShowWatchlistOnly(false); }}
                          className={`whitespace-nowrap px-4 py-1.5 text-[10px] uppercase font-bold transition-all border ${
                            (activeCategory as string) === cat.id && !showWatchlistOnly
                              ? 'bg-white text-black border-white' 
                              : 'bg-transparent text-slate-500 border-transparent hover:text-white'
                          }`}
                        >
                          {cat.label}
                        </button>
                        <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 w-48 p-3 bg-black/95 border border-brand-primary/30 text-[9px] text-slate-300 rounded opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none z-50 text-center shadow-[0_0_20px_rgba(0,0,0,0.5)] backdrop-blur-md translate-y-2 group-hover:translate-y-0">
                          {CATEGORY_DEFINITIONS[cat.id]}
                          <div className="absolute bottom-full left-1/2 -translate-x-1/2 -mb-[1px] border-4 border-transparent border-b-brand-primary/30"></div>
                        </div>
                    </div>
                  ))}
                </div>

                {/* Right: Crypto News - ORANGE */}
                <div className="flex items-center gap-3 w-full lg:w-auto justify-end">
                    
                    {/* Crypto News - DISTINCTIVE, WIDE, ORANGE */}
                    <button 
                        onClick={() => setViewMode(viewMode !== 'all' ? 'all' : 'news')}
                        className={`
                          relative flex items-center justify-center gap-2 px-8 py-2.5 
                          font-black text-[10px] uppercase tracking-[0.2em] transition-all 
                          border border-orange-500 bg-orange-500/5 text-orange-500 
                          shadow-[0_0_15px_rgba(249,115,22,0.2)] hover:shadow-[0_0_25px_rgba(249,115,22,0.4)]
                          hover:bg-orange-500 hover:text-black
                          group overflow-hidden
                        `}
                    >
                        <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
                        <Newspaper size={16} strokeWidth={2.5} className="relative z-10" />
                        <span className="relative z-10 hidden sm:inline">Crypto News</span>
                    </button>

                </div>

              </div>
           </div>

           {/* Loading State Overlay */}
           <div className="relative min-h-[600px]">
             {loading && (
               <div className="absolute inset-0 z-50 bg-[#010409]/50 backdrop-blur-sm flex items-center justify-center">
                  <div className="flex flex-col items-center gap-4">
                    <div className="w-12 h-12 border-4 border-brand-primary border-t-transparent rounded-full animate-spin"></div>
                    <span className="text-xs font-black uppercase tracking-widest text-brand-primary animate-pulse">Loading Asset Data...</span>
                  </div>
               </div>
             )}
             
             {/* Dynamic Grid Dashboard */}
             <Dashboard 
                coins={processedCoins}
                news={news}
                coupons={COUPONS}
                loadingNews={newsLoading}
                onCoinSelect={handleCoinSelect}
                selectedCoinId={selectedCoin?.id || ''}
                favorites={favorites}
                toggleFavorite={toggleFavorite}
                sortConfig={sortConfig}
                onSort={handleSort}
                isWatchlistActive={showWatchlistOnly}
                onToggleWatchlist={() => setShowWatchlistOnly(!showWatchlistOnly)}
             />
           </div>

           {/* Pagination */}
           {!showWatchlistOnly && (
             <div className="flex justify-center gap-px pt-8 pb-10">
               <button disabled={currentPage === 1} onClick={() => setCurrentPage(p => p-1)} className="px-6 py-2 bg-[#0d1117] text-xs font-bold uppercase disabled:opacity-30 border border-white/10 hover:border-brand-primary hover:text-brand-primary transition-all">Prev</button>
               <span className="px-6 py-2 text-xs font-bold text-slate-500 bg-[#0d1117] border-y border-white/10 flex items-center uppercase">Page {currentPage}</span>
               <button onClick={() => setCurrentPage(p => p+1)} className="px-6 py-2 bg-[#0d1117] text-xs font-bold uppercase border border-white/10 hover:border-brand-primary hover:text-brand-primary transition-all">Next</button>
            </div>
           )}
        </main>
      )}

      {/* Detail Modal Overlay */}
      <Suspense fallback={null}>
        {selectedCoin && (
          <AssetDetail 
            coin={selectedCoin} 
            history={history} 
            insight={insight} 
            onClose={() => setSelectedCoin(null)} 
          />
        )}
      </Suspense>

      {/* New Footer */}
      <div className="pb-16">
        <Footer />
      </div>

      {/* Sticky Market Header */}
      <MarketHeader stats={marketStats} />
    </div>
  );
};

export default App;
