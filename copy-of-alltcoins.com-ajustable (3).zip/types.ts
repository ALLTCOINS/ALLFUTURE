
export interface Coin {
  id: string;
  symbol: string;
  name: string;
  image: string;
  current_price: number;
  market_cap: number;
  market_cap_rank: number;
  circulating_supply: number;
  price_change_percentage_24h: number;
  price_change_percentage_1h_in_currency?: number;
  price_change_percentage_7d_in_currency?: number;
  total_volume: number;
  sparkline_in_7d?: {
    price: number[];
  };
}

export interface MarketStats {
  total_market_cap: { [key: string]: number };
  total_volume: { [key: string]: number };
  market_cap_percentage: { [key: string]: number };
  market_cap_change_percentage_24h_usd: number;
  active_cryptocurrencies?: number;
  markets?: number;
}

export interface NewsArticle {
  title: string;
  url: string;
  source: string;
  published_at: string;
  summary?: string;
  sentiment?: 'positive' | 'negative' | 'neutral';
  category?: 'Bitcoin' | 'DeFi' | 'Mining' | 'Regulation' | 'Altcoins' | 'NFT';
  author?: string;
}

export interface Coupon {
  id: string;
  platform: string;
  description: string;
  link: string;
  code: string;
  color: string;
  logo: string;
  icon?: string;
}

export interface GlobalData {
  data: MarketStats;
}

export interface PriceAlert {
  coinId: string;
  targetPrice: number;
  condition: 'above' | 'below';
}

export interface ChartConfig {
  showMA_Short: boolean;
  showMA_Long: boolean;
  showRSI: boolean;
  showMACD: boolean;
  showBB: boolean;
  maShortPeriod: number;
  maLongPeriod: number;
  rsiPeriod: number;
  macdFast: number;
  macdSlow: number;
  macdSignal: number;
  bbPeriod: number;
  bbStdDev: number;
  chartType: 'area' | 'line' | 'tradingview';
}

export type WidgetType = 'market-table' | 'converter' | 'news-feed' | 'bonus-drops';
export type WidgetSize = 'small' | 'medium' | 'large' | 'full';

export interface DashboardWidget {
  id: string;
  type: WidgetType;
  size: WidgetSize;
  visible: boolean;
}

export interface SearchResultItem {
  id: string;
  name: string;
  symbol: string;
  thumb: string;
  market_cap_rank?: number;
  type: 'coin' | 'nft' | 'tool' | 'exchange';
}
