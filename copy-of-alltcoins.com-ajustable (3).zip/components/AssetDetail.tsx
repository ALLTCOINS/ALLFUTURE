import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  X, Maximize2, Minimize2, TrendingUp, TrendingDown, Clock, 
  Bell, Share2, Target, Zap, Newspaper,
  ExternalLink as ExternalLinkIcon,
  ChevronLeft, ChevronRight, ShoppingCart, CheckCircle2,
  BarChart2, Database, AlertTriangle, Twitter, Facebook, Link as LinkIcon, Info, Users, Globe, Coins, PlayCircle, Activity,
  Settings, Sliders, Layers, Eye, EyeOff, Loader2, Plus, ArrowUp, ArrowDown
} from 'lucide-react';
import PriceChart from './PriceChart';
import TradingViewChart from './TradingViewChart';
import BitcoinRainbowChart from './BitcoinRainbowChart';
import TradeModal from './TradeModal';
import Starfield from './Starfield';
import ChartSettingsModal from './ChartSettingsModal';
import { Coin, PriceAlert, NewsArticle, ChartConfig } from '../types';
import { fetchSingleCoin, fetchFearAndGreedIndex } from '../services/cryptoService';
import { CryptoInsight, getAssetNews } from '../services/geminiService';

interface AssetDetailProps {
  coin: Coin;
  history: { time: number; price: number }[];
  insight: CryptoInsight | null;
  onClose: () => void;
}

const DEFAULT_CHART_CONFIG: ChartConfig = {
  showMA_Short: false,
  showMA_Long: false,
  showRSI: false,
  showMACD: false,
  showBB: false,
  maShortPeriod: 50,
  maLongPeriod: 200,
  rsiPeriod: 14,
  macdFast: 12,
  macdSlow: 26,
  macdSignal: 9,
  bbPeriod: 20,
  bbStdDev: 2,
  chartType: 'area'
};

// Internal News Reader Modal Component
const NewsReaderModal = ({ article, onClose }: { article: NewsArticle, onClose: () => void }) => {
  if (!article) return null;
  
  const handleShare = (platform: 'twitter' | 'reddit' | 'copy') => {
     const text = encodeURIComponent(`${article.title} - via Alltcoins Terminal`);
     const url = encodeURIComponent(article.url);
     
     if (platform === 'twitter') {
       window.open(`https://twitter.com/intent/tweet?text=${text}&url=${url}`, '_blank');
     } else if (platform === 'reddit') {
       window.open(`https://www.reddit.com/submit?url=${url}&title=${text}`, '_blank');
     } else {
       navigator.clipboard.writeText(`${article.title} ${article.url}`);
     }
  };

  return (
    <div className="absolute inset-0 z-[60] bg-[#020617]/95 backdrop-blur-2xl flex flex-col animate-in slide-in-from-bottom-10 duration-300">
       <div className="flex items-center justify-between p-6 border-b border-white/10 bg-[#020617]">
          <div className="flex items-center gap-3">
             <div className="p-2 bg-brand-primary/10 rounded-lg text-brand-primary border border-brand-primary/20 shadow-[0_0_15px_rgba(0,243,255,0.2)]">
                <Newspaper size={20} />
             </div>
             <div>
                <h3 className="text-sm font-black uppercase tracking-widest text-slate-300">Intel Reader</h3>
                <p className="text-xs font-bold text-white truncate max-w-[200px] md:max-w-md opacity-90">{article.source}</p>
             </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors text-slate-300 hover:text-white">
             <X size={24} />
          </button>
       </div>
       
       <div className="flex-1 overflow-y-auto p-8 max-w-4xl mx-auto w-full">
          <span className="inline-block px-3 py-1 bg-brand-primary/10 border border-brand-primary/20 rounded text-[10px] font-black uppercase tracking-widest text-brand-primary mb-6 shadow-[0_0_10px_rgba(0,243,255,0.1)]">
             {new Date(article.published_at).toLocaleString()}
          </span>
          
          <h1 className="text-2xl md:text-4xl font-black text-white leading-tight mb-8 tracking-tight drop-shadow-lg">
             {article.title}
          </h1>
          
          <div className="prose prose-invert prose-lg max-w-none">
             <p className="text-xl text-slate-200 leading-relaxed font-medium">
                {article.summary || "Summary not available for this intelligence report. Please refer to the source for full details."}
             </p>
          </div>

          <div className="mt-12 pt-8 border-t border-white/10">
             <div className="flex flex-col md:flex-row items-center justify-between gap-6">
                <div className="flex gap-4">
                   <button onClick={() => handleShare('twitter')} className="flex items-center gap-2 px-4 py-2 bg-[#1DA1F2]/10 text-[#1DA1F2] border border-[#1DA1F2]/20 rounded-lg hover:bg-[#1DA1F2] hover:text-white transition-all font-bold text-xs uppercase">
                      <Twitter size={16} /> Tweet
                   </button>
                   <button onClick={() => handleShare('copy')} className="flex items-center gap-2 px-4 py-2 bg-white/10 text-slate-200 border border-white/20 rounded-lg hover:bg-white/20 hover:text-white transition-all font-bold text-xs uppercase">
                      <LinkIcon size={16} /> Copy Link
                   </button>
                </div>
                
                <a 
                   href={article.url} 
                   target="_blank" 
                   rel="noopener noreferrer"
                   className="flex items-center gap-2 px-6 py-3 bg-brand-primary text-black font-black uppercase tracking-widest text-xs rounded-lg hover:scale-105 transition-transform shadow-[0_0_20px_rgba(0,243,255,0.4)] hover:shadow-[0_0_30px_rgba(0,243,255,0.6)]"
                >
                   Read Full Source <ExternalLinkIcon size={14} />
                </a>
             </div>
          </div>
       </div>
    </div>
  );
};

const InfoTooltip = ({ text }: { text: string }) => (
  <div className="group relative ml-2 inline-flex z-50">
    <Info size={12} className="text-slate-400 cursor-help hover:text-brand-primary transition-colors" />
    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 p-3 bg-black border border-white/20 text-[11px] leading-relaxed text-slate-200 rounded shadow-xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50">
      {text}
      <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-1 border-4 border-transparent border-t-white/20"></div>
    </div>
  </div>
);

const FearAndGreedGauge = () => {
  const [data, setData] = useState<{ value: number; classification: string } | null>(null);

  useEffect(() => {
    const load = async () => {
      const res = await fetchFearAndGreedIndex();
      setData(res);
    };
    load();
  }, []);

  if (!data) return (
    <div className="bg-white/5 p-5 border border-white/5 h-[100px] flex flex-col justify-center gap-2 animate-pulse">
        <div className="h-3 w-24 bg-white/10"></div>
        <div className="h-8 w-16 bg-white/10"></div>
    </div>
  );

  const getColor = (val: number) => {
    if (val < 25) return '#ff2e5f'; 
    if (val < 45) return '#facc15'; 
    if (val < 55) return '#94a3b8'; 
    if (val < 75) return '#39ff14'; 
    return '#00ffa3'; 
  };

  return (
    <div className="bg-[#0b0e14]/50 p-5 border border-white/10 flex items-center justify-between transition-all duration-300 group hover:border-brand-primary/30 hover:shadow-[0_0_15px_rgba(0,243,255,0.1)] relative overflow-hidden backdrop-blur-sm rounded-lg">
      <div className="flex flex-col relative z-10">
        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1 group-hover:text-brand-primary transition-colors">Sentiment Index</span>
        <div className="flex items-baseline gap-2">
          <span className="text-3xl font-black font-mono leading-none drop-shadow-md" style={{ color: getColor(data.value) }}>{data.value}</span>
          <span className="text-xs font-bold uppercase tracking-tight text-slate-300">/ 100</span>
        </div>
        <span className="text-xs font-black uppercase mt-1" style={{ color: getColor(data.value) }}>{data.classification}</span>
      </div>
      <div className="h-16 w-1 bg-white/5 relative overflow-hidden z-10 rounded-full">
        <div 
          className="absolute bottom-0 left-0 w-full transition-all duration-1000 ease-out shadow-[0_0_10px_currentColor]" 
          style={{ height: `${data.value}%`, backgroundColor: getColor(data.value), color: getColor(data.value) }} 
        />
      </div>
    </div>
  );
};

const TechnicalAnalysisSummary = () => {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 1200);
    return () => clearTimeout(t);
  }, []);

  if (loading) {
      return (
        <div className="bg-white/5 p-6 border border-white/5 mt-6 animate-pulse space-y-4 rounded-lg">
           {/* Skeleton content */}
        </div>
      );
  }

  const indicators = [
    { label: 'RSI (14)', value: '42.5', signal: 'Neutral', color: 'text-yellow-400', bar: 42 },
    { label: 'Stoch (9,6)', value: '28.0', signal: 'Buy', color: 'text-brand-success', bar: 28 },
    { label: 'MACD (12,26)', value: '-0.42', signal: 'Sell', color: 'text-brand-danger', bar: 65 },
  ];

  return (
    <div className="bg-[#0b0e14]/50 backdrop-blur-sm p-6 border border-white/10 shadow-sm mt-6 transition-all duration-300 group hover:border-brand-primary/30 hover:shadow-[0_0_15px_rgba(0,243,255,0.1)] rounded-lg">
      <div className="flex items-center space-x-2 mb-4">
        <BarChart2 size={16} className="text-slate-400 group-hover:text-brand-primary transition-colors" />
        <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-300 group-hover:text-white transition-colors">Technical Analysis</h4>
      </div>
      <div className="space-y-4">
        {indicators.map((ind, i) => (
          <div key={i}>
            <div className="flex justify-between items-end mb-1">
              <span className="text-[10px] font-bold text-slate-300 uppercase">{ind.label}</span>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono font-bold text-slate-300">{ind.value}</span>
                <span className={`text-[9px] font-black uppercase ${ind.color}`}>{ind.signal}</span>
              </div>
            </div>
            <div className="h-1.5 w-full bg-white/10 overflow-hidden rounded-full">
              <div 
                className={`h-full shadow-[0_0_8px_currentColor] rounded-full ${ind.signal === 'Buy' ? 'bg-brand-success text-brand-success' : ind.signal === 'Sell' ? 'bg-brand-danger text-brand-danger' : 'bg-yellow-400 text-yellow-400'}`} 
                style={{ width: `${ind.bar}%` }}
              ></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const AssetNewsCarousel = ({ news, loading, onRead }: { news: NewsArticle[], loading: boolean, onRead: (n: NewsArticle) => void }) => {
  const [index, setIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    if (news.length === 0 || isPaused) return;
    const interval = setInterval(() => {
      setIndex((i) => (i + 1) % news.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [news.length, isPaused]);

  if (loading) return <div className="min-h-[160px] bg-white/5 animate-pulse rounded-lg" />;
  if (news.length === 0) return null;

  const current = news[index];

  return (
    <div 
      className="relative min-h-[160px] bg-[#0b0e14]/50 backdrop-blur-sm border border-white/10 overflow-hidden mb-6 group hover:border-brand-primary/30 transition-all shadow-sm hover:shadow-[0_0_20px_rgba(0,243,255,0.1)] duration-300 cursor-pointer rounded-lg flex flex-col"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onClick={() => onRead(current)}
    >
      <div className="absolute inset-0 bg-gradient-to-br from-brand-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
      
      <div className="p-6 h-full flex flex-col justify-between relative z-10">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
             <span className="px-2.5 py-1 bg-white/10 text-[9px] font-black uppercase text-slate-300 tracking-widest border border-white/10 group-hover:border-brand-primary/30 group-hover:text-brand-primary transition-colors rounded">{current.source}</span>
          </div>
          <span className="text-[10px] text-slate-400 font-bold font-mono">{new Date(current.published_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
        </div>
        
        <h4 className="text-sm font-bold leading-snug line-clamp-3 text-slate-100 group-hover:text-brand-primary transition-colors group-hover:scale-[1.01] origin-left">
            {current.title}
        </h4>

        <div className="flex items-center justify-between mt-4">
           <div className="flex items-center gap-1">
             {news.map((_, i) => (
               <div key={i} className={`h-1 transition-all duration-300 rounded-full ${i === index ? 'w-6 bg-brand-primary shadow-[0_0_5px_#00f3ff]' : 'w-1.5 bg-white/20'}`}></div>
             ))}
           </div>
           
           <div className="text-[9px] font-black uppercase tracking-widest text-brand-primary opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1">
              Read Report <ChevronRight size={10} />
           </div>
        </div>
      </div>
    </div>
  );
};

const ProVisuals = ({ coin }: { coin: Coin }) => {
  if (coin.symbol.toLowerCase() === 'btc') {
    return <BitcoinRainbowChart />;
  }

  const levels = 24;

  return (
    <div className="bg-[#0b0e14]/50 backdrop-blur-sm p-6 border border-white/10 h-[300px] flex flex-col group hover:border-brand-primary/30 hover:shadow-[0_0_20px_rgba(0,243,255,0.15)] transition-all duration-500 rounded-lg hover:-translate-y-1">
       <div className="flex items-center justify-between mb-6">
          <h3 className="text-sm font-black uppercase tracking-widest text-white flex items-center gap-2 group-hover:text-brand-primary transition-colors">
             <Database size={16} className="text-brand-primary" />
             Liquidity Heatmap
          </h3>
          <span className="text-[10px] font-mono text-slate-400 group-hover:text-white transition-colors">Aggregated Depth</span>
       </div>
       
       <div className="flex-1 flex gap-px relative overflow-hidden rounded bg-[#020617] border border-white/5 p-2 items-end">
          {/* Bids Side */}
          <div className="flex-1 flex items-end justify-end gap-0.5 px-1 border-r border-white/10">
             {Array.from({length: levels}).map((_, i) => {
                 // Simulated Depth Logic - Tapering off from center
                 const centerProximity = i / levels;
                 const randomDepth = Math.random();
                 const height = 10 + (randomDepth * 30) + (centerProximity * 60);
                 const opacity = 0.2 + (randomDepth * 0.8);
                 
                 return (
                    <div 
                      key={`bid-${i}`}
                      className="w-full bg-brand-success rounded-t-sm hover:brightness-125 transition-all duration-300"
                      style={{ 
                          height: `${height}%`, 
                          opacity: opacity
                      }}
                      title={`Bid Volume: ${(height).toFixed(0)}%`}
                    />
                 );
             })}
          </div>

          {/* Asks Side */}
          <div className="flex-1 flex items-end justify-start gap-0.5 px-1">
             {Array.from({length: levels}).map((_, i) => {
                 const centerProximity = 1 - (i / levels);
                 const randomDepth = Math.random();
                 const height = 10 + (randomDepth * 30) + (centerProximity * 60);
                 const opacity = 0.2 + (randomDepth * 0.8);

                 return (
                    <div 
                      key={`ask-${i}`}
                      className="w-full bg-brand-danger rounded-t-sm hover:brightness-125 transition-all duration-300"
                      style={{ 
                          height: `${height}%`, 
                          opacity: opacity
                      }}
                      title={`Ask Volume: ${(height).toFixed(0)}%`}
                    />
                 );
             })}
          </div>

          {/* Price Label Overlay */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-20">
             <span className="bg-[#050910]/90 border border-white/10 px-3 py-1.5 text-[12px] font-mono font-bold text-white rounded shadow-lg backdrop-blur-md">
                ${coin.current_price.toLocaleString()}
             </span>
          </div>
       </div>
       
       <div className="flex justify-between mt-3 text-[9px] font-mono font-bold text-slate-500 uppercase tracking-wider">
          <span className="text-brand-success flex items-center gap-1"><div className="w-2 h-2 bg-brand-success rounded-full"></div>Buy Orders</span>
          <span className="text-brand-danger flex items-center gap-1">Sell Orders<div className="w-2 h-2 bg-brand-danger rounded-full"></div></span>
       </div>
    </div>
  );
};

const KeyStatsRow = ({ coin }: { coin: Coin }) => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
       <div className="bg-[#0b0e14]/50 backdrop-blur-sm p-4 border border-white/10 flex flex-col items-center justify-center group hover:border-brand-primary/30 transition-all duration-300 hover:-translate-y-1 relative overflow-hidden rounded-lg hover:shadow-[0_0_15px_rgba(0,243,255,0.1)]">
          <div className="absolute inset-0 bg-brand-primary/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
          <span className="text-[9px] font-black uppercase tracking-widest text-slate-400 mb-1 z-10 group-hover:text-slate-300 transition-colors">Market Cap</span>
          <span className="text-xs font-mono font-bold text-white group-hover:text-brand-primary transition-colors z-10">${(coin.market_cap / 1e9).toFixed(2)}B</span>
       </div>
       <div className="bg-[#0b0e14]/50 backdrop-blur-sm p-4 border border-white/10 flex flex-col items-center justify-center group hover:border-brand-primary/30 transition-all duration-300 hover:-translate-y-1 relative overflow-hidden rounded-lg hover:shadow-[0_0_15px_rgba(0,243,255,0.1)]">
          <div className="absolute inset-0 bg-brand-primary/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
          <span className="text-[9px] font-black uppercase tracking-widest text-slate-400 mb-1 z-10 group-hover:text-slate-300 transition-colors">Volume (24h)</span>
          <span className="text-xs font-mono font-bold text-white group-hover:text-brand-primary transition-colors z-10">${(coin.total_volume / 1e6).toFixed(2)}M</span>
       </div>
       <div className="bg-[#0b0e14]/50 backdrop-blur-sm p-4 border border-white/10 flex flex-col items-center justify-center group hover:border-brand-primary/30 transition-all duration-300 hover:-translate-y-1 relative overflow-hidden rounded-lg hover:shadow-[0_0_15px_rgba(0,243,255,0.1)]">
          <div className="absolute inset-0 bg-brand-primary/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
          <span className="text-[9px] font-black uppercase tracking-widest text-slate-400 mb-1 z-10 group-hover:text-slate-300 transition-colors">Supply</span>
          <span className="text-xs font-mono font-bold text-white group-hover:text-brand-primary transition-colors z-10">{(coin.circulating_supply / 1e6).toFixed(2)}M</span>
       </div>
       <div className="bg-[#0b0e14]/50 backdrop-blur-sm p-4 border border-white/10 flex flex-col items-center justify-center group hover:border-brand-primary/30 transition-all duration-300 hover:-translate-y-1 relative overflow-hidden rounded-lg hover:shadow-[0_0_15px_rgba(0,243,255,0.1)]">
          <div className="absolute inset-0 bg-brand-primary/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
          <span className="text-[9px] font-black uppercase tracking-widest text-slate-400 mb-1 z-10 group-hover:text-slate-300 transition-colors">Global Rank</span>
          <span className="text-xs font-mono font-bold text-white group-hover:text-brand-primary transition-colors z-10">#{coin.market_cap_rank}</span>
       </div>
    </div>
  );
};

const AssetDetail: React.FC<AssetDetailProps> = ({ coin: initialCoin, history: initialHistory, insight, onClose }) => {
  const [coin, setCoin] = useState<Coin>(initialCoin);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [showAlertUI, setShowAlertUI] = useState(false);
  const [alertPrice, setAlertPrice] = useState<string>(coin.current_price.toString());
  const [assetNews, setAssetNews] = useState<NewsArticle[]>([]);
  const [newsLoading, setNewsLoading] = useState(false);
  const [readingArticle, setReadingArticle] = useState<NewsArticle | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  
  // Chart Interval State for TradingView
  const [chartInterval, setChartInterval] = useState('D');
  
  const [tradeModal, setTradeModal] = useState<{ type: 'buy' | 'sell', isOpen: boolean } | null>(null);

  // Chart Configuration State
  const [showChartSettings, setShowChartSettings] = useState(false);
  const [chartConfig, setChartConfig] = useState<ChartConfig>(DEFAULT_CHART_CONFIG);

  // Price Alert State
  const [alertTarget, setAlertTarget] = useState<string>('');
  const [alertCondition, setAlertCondition] = useState<'above' | 'below'>('above');
  const [activeAlert, setActiveAlert] = useState<PriceAlert | null>(null);

  // News Scroll State
  const newsContainerRef = useRef<HTMLDivElement>(null);
  const [visibleNewsCount, setVisibleNewsCount] = useState(5);

  const isUp = coin.price_change_percentage_24h >= 0;
  
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  useEffect(() => {
    const fetchNews = async () => {
      setNewsLoading(true);
      try {
        const news = await getAssetNews(coin.name);
        setAssetNews(news);
      } catch (e) { console.error(e); } finally { setNewsLoading(false); }
    };
    fetchNews();
  }, [coin.name]);

  useEffect(() => {
    const intervalId = setInterval(async () => {
      const updatedCoin = await fetchSingleCoin(coin.id);
      if (updatedCoin) setCoin(updatedCoin);
    }, 15000);
    return () => clearInterval(intervalId);
  }, [coin.id]);

  const handleShareSystem = async () => {
    const shareUrl = `${window.location.origin}?asset=${coin.id}`;
    navigator.clipboard.writeText(shareUrl);
    showToast("Link Copied to Clipboard");
  };

  const handleSetAlert = () => {
    if (!alertTarget || isNaN(parseFloat(alertTarget))) return;
    setActiveAlert({
      coinId: coin.id,
      targetPrice: parseFloat(alertTarget),
      condition: alertCondition
    });
    showToast(`Alert Set: ${alertCondition === 'above' ? 'Above' : 'Below'} $${alertTarget}`);
    setAlertTarget('');
  };

  const handleNewsScroll = () => {
    if (newsContainerRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = newsContainerRef.current;
      // If close to bottom
      if (scrollHeight - scrollTop <= clientHeight + 50) { 
         if (visibleNewsCount < assetNews.length) {
            setVisibleNewsCount(prev => Math.min(prev + 5, assetNews.length));
         }
      }
    }
  };

  // Helper for news thumbs in detail view
  const getThumbnail = (article: NewsArticle) => {
    const text = (article.title + article.source).toLowerCase();
    let icon = <Newspaper size={16} className="text-slate-400" />;
    
    if (text.includes('bitcoin') || text.includes('btc')) {
       return (
         <div className="w-10 h-10 rounded-lg shrink-0 overflow-hidden border border-white/10 bg-[#F7931A]/10 flex items-center justify-center">
            <img src="https://assets.coingecko.com/coins/images/1/thumb/bitcoin.png" className="w-6 h-6 object-contain opacity-90" />
         </div>
       );
    }
    
    return (
        <div className={`w-10 h-10 rounded-lg shrink-0 flex items-center justify-center border border-white/10 bg-[#050910]`}>
            {icon}
        </div>
    );
  };

  return (
    <div className={`fixed inset-0 z-[9999] flex items-center justify-center p-0 md:p-6 transition-all duration-500 ${isFullScreen ? 'bg-[#010409]' : 'bg-[#010409]/80 backdrop-blur-md'}`}>
      <div className={`relative bg-[#010409] border border-white/10 shadow-2xl overflow-hidden transition-all duration-500 flex flex-col ${isFullScreen ? 'w-full h-full' : 'w-full max-w-[1400px] h-full md:h-[92vh] md:rounded-lg'}`}>
        
        <Starfield className="absolute inset-0 z-0 pointer-events-none bg-[#010409]" />
        <div className="absolute inset-0 pointer-events-none z-0 opacity-[0.05]" 
           style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '40px 40px' }}>
        </div>

        {/* Trade Modal (Nested) */}
        {tradeModal && (
          <TradeModal 
            isOpen={tradeModal.isOpen} 
            type={tradeModal.type} 
            coin={coin} 
            onClose={() => setTradeModal(null)} 
          />
        )}

        {/* Reader Modal Overlay */}
        {readingArticle && (
            <NewsReaderModal article={readingArticle} onClose={() => setReadingArticle(null)} />
        )}

        {/* Chart Settings Modal */}
        {showChartSettings && (
           <ChartSettingsModal 
              config={chartConfig} 
              onChange={setChartConfig} 
              onClose={() => setShowChartSettings(false)} 
           />
        )}

        {toastMessage && (
          <div className="absolute top-24 left-1/2 -translate-x-1/2 z-[200] bg-brand-primary text-black px-6 py-3 shadow-[0_0_20px_rgba(0,243,255,0.4)] flex items-center gap-2 animate-in fade-in slide-in-from-top-4 font-bold uppercase tracking-wider rounded">
            <CheckCircle2 size={16} />
            <span>{toastMessage}</span>
          </div>
        )}

        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-white/10 bg-transparent shrink-0 relative z-10 backdrop-blur-sm">
          <div className="flex items-center space-x-3 md:space-x-4 min-w-0">
            <img src={coin.image} alt={coin.name} className="w-8 h-8 md:w-10 md:h-10 shadow-lg border border-white/20 bg-white/5 rounded-full" />
            <div className="min-w-0">
              <h2 className="text-lg md:text-2xl font-black uppercase leading-none tracking-tighter text-white truncate">{coin.name}</h2>
              <div className="flex items-center space-x-2 mt-0.5">
                 <span className="text-slate-300 font-bold uppercase text-[10px] tracking-widest px-1.5 py-0.5 bg-white/10 rounded border border-white/10">{coin.symbol}</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-1.5 md:gap-2 shrink-0 ml-2">
            <button 
              onClick={handleShareSystem} 
              className="group p-2 bg-white/5 border border-white/10 text-slate-300 hover:text-brand-primary hover:border-brand-primary/50 transition-all rounded active:scale-95 relative"
            >
              <Share2 size={18} />
            </button>
            <div className="w-px h-6 bg-white/10 mx-1"></div>
            <button 
              onClick={onClose} 
              className="p-2 bg-white/5 border border-white/10 text-slate-300 hover:bg-brand-danger hover:text-white hover:border-brand-danger transition-all rounded active:scale-95"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto overflow-x-hidden custom-scrollbar bg-transparent relative z-10">
          <div className="flex flex-col lg:flex-row min-h-full">
            
            {/* Main Chart Area */}
            <div className="flex-1 p-4 md:p-6 flex flex-col lg:overflow-y-auto lg:h-full">
              <div className="flex flex-col sm:flex-row items-start justify-between mb-6 gap-4">
                <div>
                  <div className="flex items-baseline space-x-3">
                    <span className={`text-3xl md:text-5xl font-mono font-black tracking-tight text-white drop-shadow-[0_0_10px_rgba(255,255,255,0.1)]`}>
                      ${coin.current_price?.toLocaleString(undefined, { minimumFractionDigits: 2 }) ?? 'N/A'}
                    </span>
                  </div>
                  <div className={`flex items-center space-x-2 font-bold mt-1 ${isUp ? 'text-brand-success' : 'text-brand-danger'}`}>
                    {isUp ? <TrendingUp size={14} strokeWidth={3} /> : <TrendingDown size={14} strokeWidth={3} />}
                    <span className="text-sm md:text-base tracking-tight">{Math.abs(coin.price_change_percentage_24h).toFixed(2)}% (24H)</span>
                  </div>
                </div>
              </div>

              {/* Chart Container - Fixed Flex Grow */}
              <div className="flex-1 w-full min-h-[500px] lg:h-full flex flex-col border border-white/10 overflow-hidden shadow-inner rounded-lg relative group hover:border-brand-primary/40 transition-all duration-500 hover:shadow-[0_0_40px_rgba(0,243,255,0.1)] backdrop-blur-md bg-transparent">
                 <div className="flex items-center justify-between px-3 py-2 border-b border-white/10 bg-white/5 relative z-20 shrink-0">
                     <div className="flex items-center gap-2">
                        {chartConfig.chartType === 'tradingview' ? (
                           <div className="flex gap-1">
                              {['60', '240', 'D', 'W'].map(int => (
                                 <button
                                   key={int}
                                   onClick={() => setChartInterval(int)}
                                   className={`px-2 py-1 rounded text-[9px] font-black uppercase tracking-wider transition-all ${chartInterval === int ? 'bg-brand-primary text-black' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}
                                 >
                                   {int === '60' ? '1H' : int === '240' ? '4H' : int}
                                 </button>
                              ))}
                           </div>
                        ) : (
                            <span className="text-[10px] font-black text-brand-primary uppercase tracking-widest flex items-center gap-2">
                               <Activity size={12} />
                               Market Depth
                            </span>
                        )}
                     </div>
                     
                     <button 
                        onClick={() => setShowChartSettings(true)}
                        className="flex items-center gap-2 px-3 py-1.5 bg-white/5 hover:bg-white/10 rounded text-[10px] font-black uppercase tracking-wider text-slate-400 hover:text-white transition-colors border border-white/5 hover:border-white/20"
                     >
                        <Settings size={12} />
                        <span className="hidden sm:inline">Indicators</span>
                     </button>
                 </div>
                 <div className="flex-grow relative w-full h-full">
                    {chartConfig.chartType === 'tradingview' ? (
                      <TradingViewChart symbol={coin.symbol} theme={'dark'} interval={chartInterval} />
                    ) : (
                      <PriceChart data={initialHistory} isUp={isUp} title={coin.name} settings={chartConfig} />
                    )}
                 </div>
              </div>

              {/* Action Bar */}
              <div className="mt-4 grid grid-cols-2 gap-4">
                <button 
                  onClick={() => setTradeModal({ type: 'buy', isOpen: true })}
                  className="group relative overflow-hidden bg-brand-success/5 border border-brand-success/20 hover:bg-brand-success hover:text-black py-4 flex items-center justify-center gap-2 transition-all hover:translate-y-[-2px] hover:shadow-[0_0_30px_rgba(0,255,163,0.3)] rounded backdrop-blur-md"
                >
                  <ShoppingCart className="text-brand-success group-hover:text-black w-4 h-4 md:w-5 md:h-5 transition-colors" strokeWidth={3} />
                  <span className="text-brand-success group-hover:text-black font-black uppercase tracking-widest text-xs md:text-sm transition-colors">Buy Long</span>
                </button>
                <button 
                  onClick={() => setTradeModal({ type: 'sell', isOpen: true })}
                  className="group relative overflow-hidden bg-brand-danger/5 border border-brand-danger/20 hover:bg-brand-danger hover:text-white py-4 flex items-center justify-center gap-2 transition-all hover:translate-y-[-2px] hover:shadow-[0_0_30px_rgba(255,46,95,0.3)] rounded backdrop-blur-md"
                >
                  <TrendingDown className="text-brand-danger group-hover:text-white w-4 h-4 md:w-5 md:h-5 transition-colors" strokeWidth={3} />
                  <span className="text-brand-danger group-hover:text-white font-black uppercase tracking-widest text-xs md:text-sm transition-colors">Sell Short</span>
                </button>
              </div>
              
              <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <div className="flex items-center mb-3">
                    <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 ml-1">Latest Intelligence</h4>
                    <InfoTooltip text="AI-curated news feed specific to this asset." />
                  </div>
                  <AssetNewsCarousel news={assetNews.slice(0, 5)} loading={newsLoading} onRead={setReadingArticle} />
                </div>
                <div>
                   <div className="flex items-center mb-3">
                    <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 ml-1">Pro Analysis</h4>
                    <InfoTooltip text="Advanced visual metrics." />
                  </div>
                  <ProVisuals coin={coin} />
                </div>
              </div>

              <div className="mt-6">
                 <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-3 ml-1">Key Statistics</h4>
                 <KeyStatsRow coin={coin} />
              </div>
            </div>

            {/* Sidebar */}
            <div className="w-full lg:w-[360px] p-4 md:p-6 bg-transparent border-t lg:border-t-0 lg:border-l border-white/10 flex flex-col shrink-0 lg:h-full lg:overflow-y-auto custom-scrollbar backdrop-blur-sm">
              <div className="space-y-6">
                
                {/* Global Sentiment */}
                <div>
                  <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-3 flex items-center gap-2">
                    <Target size={14} className="text-brand-primary" />
                    <span>Global Sentiment</span>
                  </h4>
                  <FearAndGreedGauge />
                </div>

                {/* Price Alert Section */}
                <div className="bg-[#0b0e14]/50 p-4 border border-white/10 rounded-lg group hover:border-brand-primary/20 transition-colors">
                   <div className="flex items-center justify-between mb-3">
                      <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 flex items-center gap-2">
                        <Bell size={14} className="text-brand-primary" />
                        <span>Set Price Alert</span>
                      </h4>
                      {activeAlert && (
                        <span className="text-[9px] font-bold text-brand-primary uppercase px-2 py-0.5 bg-brand-primary/10 rounded animate-pulse">Active</span>
                      )}
                   </div>
                   <div className="flex gap-2 mb-2">
                      <div className="relative flex-1">
                         <span className="absolute left-2 top-1/2 -translate-y-1/2 text-slate-500">$</span>
                         <input 
                           type="number" 
                           value={alertTarget}
                           onChange={(e) => setAlertTarget(e.target.value)}
                           placeholder="Target"
                           className="w-full bg-black/50 border border-white/10 rounded px-2 pl-5 py-2 text-xs font-mono font-bold text-white focus:border-brand-primary outline-none"
                         />
                      </div>
                      <select 
                        value={alertCondition}
                        onChange={(e) => setAlertCondition(e.target.value as 'above' | 'below')}
                        className="bg-black/50 border border-white/10 rounded px-2 py-2 text-[10px] font-bold uppercase text-slate-300 outline-none"
                      >
                        <option value="above">Above</option>
                        <option value="below">Below</option>
                      </select>
                   </div>
                   <button 
                     onClick={handleSetAlert}
                     className="w-full bg-white/5 border border-white/10 hover:bg-brand-primary/10 hover:border-brand-primary hover:text-brand-primary text-slate-400 text-[10px] font-black uppercase tracking-widest py-2 rounded transition-all"
                   >
                     Create Alert
                   </button>
                </div>

                {/* AI Sentiment */}
                <div>
                  <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-3 flex items-center gap-2">
                    <Zap size={14} className="text-brand-primary" />
                    <span>Market Sentiment</span>
                  </h4>
                  {!insight ? (
                    <div className="bg-white/5 p-5 border border-white/5 shadow-sm space-y-3 animate-pulse rounded-lg">
                      <div className="h-2.5 bg-white/10 w-3/4"></div>
                      <div className="h-2.5 bg-white/10 w-full"></div>
                    </div>
                  ) : (
                    <div className="bg-[#0b0e14]/50 backdrop-blur-sm p-5 border border-white/10 shadow-sm relative overflow-hidden transition-all duration-300 group hover:border-brand-primary/30 rounded-lg">
                      <div className="relative z-10">
                          <div className="flex justify-between items-start mb-3">
                              <div>
                                  <span className="text-[9px] font-black uppercase tracking-widest text-slate-400 block mb-1">AI Projection</span>
                                  <h3 className={`text-xl font-black uppercase tracking-tighter ${
                                      insight.sentiment === 'Bullish' ? 'text-brand-success' : 
                                      insight.sentiment === 'Bearish' ? 'text-brand-danger' : 'text-slate-200'
                                  }`}>
                                      {insight.sentiment}
                                  </h3>
                              </div>
                              <div className="text-right">
                                  <span className="text-[9px] font-black uppercase tracking-widest text-slate-400 block mb-1">Score</span>
                                  <div className="flex items-baseline justify-end gap-1">
                                      <span className={`text-xl font-mono font-black ${insight.score > 75 ? 'text-brand-success' : insight.score < 35 ? 'text-brand-danger' : 'text-white'}`}>
                                        {insight.score}
                                      </span>
                                      <span className="text-[9px] text-slate-400 font-bold">/100</span>
                                  </div>
                              </div>
                          </div>
                          <p className="text-xs leading-relaxed font-medium text-slate-200 border-l-2 border-brand-primary/20 pl-3">
                              {insight.text}
                          </p>
                      </div>
                  </div>
                  )}
                  <TechnicalAnalysisSummary />
                </div>

                {/* News Feed with Infinite Scroll - Enhanced Card Design */}
                <div className="flex-1 min-h-[200px] flex flex-col">
                  <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-3 flex items-center gap-2 shrink-0">
                    <Newspaper size={14} className="text-brand-primary" />
                    <span>Live Feed</span>
                  </h4>
                  <div 
                    className="space-y-3 pb-4 overflow-y-auto custom-scrollbar flex-1 max-h-[400px]"
                    ref={newsContainerRef} 
                    onScroll={handleNewsScroll}
                  >
                    {assetNews.length > 0 ? (
                      <>
                        {assetNews.slice(0, visibleNewsCount).map((news, i) => (
                          <div 
                            key={i} 
                            onClick={() => setReadingArticle(news)}
                            className="group relative flex flex-col bg-[#0b0e14] border border-white/5 hover:border-brand-primary/40 rounded-xl p-4 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lg hover:shadow-brand-primary/5 cursor-pointer overflow-hidden"
                          >
                            <div className="absolute inset-0 bg-brand-primary/0 group-hover:bg-brand-primary/5 transition-colors duration-300"></div>
                            <div className="flex items-start gap-3 relative z-10">
                                {getThumbnail(news)}
                                <div className="flex-1 min-w-0">
                                    <div className="flex items-center justify-between mb-1.5">
                                        <span className="text-[8px] font-black uppercase text-slate-400 bg-white/5 px-1.5 py-0.5 rounded group-hover:text-brand-primary group-hover:bg-brand-primary/10 transition-colors">{news.source}</span>
                                        <span className="text-[8px] font-mono text-slate-600 group-hover:text-slate-400">{new Date(news.published_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                    </div>
                                    <h4 className="text-xs font-bold text-slate-200 leading-snug line-clamp-2 group-hover:text-white transition-colors">
                                    {news.title}
                                    </h4>
                                </div>
                            </div>
                          </div>
                        ))}
                        {visibleNewsCount < assetNews.length && (
                           <div className="flex justify-center py-4">
                              <Loader2 size={20} className="animate-spin text-brand-primary" />
                           </div>
                        )}
                      </>
                    ) : (
                      <div className="flex flex-col items-center justify-center py-6 text-slate-500 border border-dashed border-white/10 rounded-lg">
                        <Newspaper size={20} className="mb-2 opacity-50" />
                        <p className="text-[10px] font-bold uppercase tracking-widest">No intelligence found</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AssetDetail;