
import React, { useState, useEffect } from 'react';
import { MarketStats } from '../types';
import { fetchFearAndGreedIndex } from '../services/cryptoService';
import { TrendingUp, TrendingDown, Fuel, Activity, Globe, Zap, BarChart3, PieChart } from 'lucide-react';

interface MarketHeaderProps {
  stats: MarketStats | null;
}

const MarketHeader: React.FC<MarketHeaderProps> = ({ stats }) => {
  const [fng, setFng] = useState<{value: number, classification: string} | null>(null);

  useEffect(() => {
    fetchFearAndGreedIndex().then(setFng);
  }, []);

  if (!stats) return <div className="h-9 bg-slate-100 dark:bg-white/5 animate-pulse w-full fixed bottom-0 z-[100] border-t border-slate-200 dark:border-white/5"></div>;

  const totalCap = (Number(Object.values(stats.total_market_cap)[0] ?? 0) / 1e12).toFixed(2);
  const vol24h = (Number(Object.values(stats.total_volume)[0] ?? 0) / 1e9).toFixed(2);
  const btcDom = stats.market_cap_percentage.btc.toFixed(1);
  const ethDom = stats.market_cap_percentage.eth.toFixed(1);
  const change = stats.market_cap_change_percentage_24h_usd;
  const isUp = change >= 0;

  return (
    <div className="fixed bottom-0 left-0 w-full z-[100] bg-white/95 dark:bg-[#0d1117]/95 border-t border-slate-200 dark:border-white/5 backdrop-blur-md text-[10px] sm:text-xs font-medium text-slate-600 dark:text-slate-400 shadow-[0_-5px_20px_rgba(0,0,0,0.1)] transition-colors duration-300">
      <div className="max-w-[1920px] mx-auto flex items-center justify-between px-4 py-2.5 overflow-x-auto scrollbar-hide gap-4 sm:gap-6 whitespace-nowrap">
        
        {/* Left Section: Market Metrics */}
        <div className="flex items-center gap-4 sm:gap-6">
          
          {/* Global Count - Hidden on Mobile */}
          <div className="hidden lg:flex items-center gap-4 border-r border-slate-200 dark:border-white/10 pr-6">
            <div className="flex items-center gap-1.5 hover:text-slate-900 dark:hover:text-slate-200 transition-colors cursor-default">
              <Globe size={12} className="text-slate-400" />
              <span className="text-slate-500">Cryptos:</span>
              <span className="text-brand-primary font-bold">2.4M+</span>
            </div>
            <div className="flex items-center gap-1.5 hover:text-slate-900 dark:hover:text-slate-200 transition-colors cursor-default">
              <Activity size={12} className="text-slate-400" />
              <span className="text-slate-500">Exchanges:</span>
              <span className="text-brand-primary font-bold">750+</span>
            </div>
          </div>

          {/* Market Cap - Always Visible */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 hidden sm:inline">Market Cap:</span>
            <span className="text-slate-500 sm:hidden">M.Cap:</span>
            <span className="text-brand-primary font-bold text-xs sm:text-sm">${totalCap}T</span>
            <span className={`flex items-center font-bold text-[10px] sm:text-xs ${isUp ? 'text-brand-success' : 'text-brand-danger'} bg-slate-100 dark:bg-white/5 px-1.5 py-0.5 ml-1`}>
              {isUp ? <TrendingUp size={10} className="mr-1" strokeWidth={3} /> : <TrendingDown size={10} className="mr-1" strokeWidth={3} />}
              {Math.abs(change).toFixed(1)}%
            </span>
          </div>

          {/* Volume - Hidden on tiny screens */}
          <div className="hidden sm:flex items-center gap-1.5">
            <BarChart3 size={12} className="text-slate-400" />
            <span className="text-slate-500">24h Vol:</span>
            <span className="text-slate-900 dark:text-slate-200 font-bold">${vol24h}B</span>
          </div>

          {/* Dominance - Hidden on Mobile */}
          <div className="hidden md:flex items-center gap-1.5">
            <PieChart size={12} className="text-slate-400" />
            <span className="text-slate-500">Dominance:</span>
            <span className="text-brand-primary font-bold">BTC {btcDom}%</span>
            <span className="text-slate-400 font-bold">ETH {ethDom}%</span>
          </div>
        </div>

        {/* Right Section: Network & Sentiment */}
        <div className="flex items-center gap-4 sm:gap-6 pl-4 sm:pl-6 border-l border-slate-200 dark:border-white/10 ml-auto sm:ml-0">
          
          {/* Gas - Hidden on Mobile */}
          <div className="hidden md:flex items-center gap-1.5 hover:opacity-80 transition-opacity cursor-help" title="Estimated Ethereum Gas Price">
             <Fuel size={12} className="text-brand-primary" />
             <span className="text-slate-500">ETH Gas:</span>
             <span className="text-slate-900 dark:text-slate-200 font-bold">15 Gwei</span>
          </div>

          {/* Fear & Greed - Always Visible (Compact on Mobile) */}
          <div className="flex items-center gap-1.5">
             <Zap size={12} className="text-brand-primary hidden sm:block" />
             <span className="text-slate-500 hidden sm:inline">Fear & Greed:</span>
             <span className="text-slate-500 sm:hidden">Sentiment:</span>
             {fng ? (
               <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-white/5 px-2 py-0.5 border border-slate-200 dark:border-white/5">
                 <span className={`font-bold ${fng.value > 50 ? 'text-brand-success' : 'text-brand-danger'}`}>
                   {fng.value}
                 </span>
                 <span className={`text-[9px] uppercase font-black tracking-wider ${fng.value > 50 ? 'text-brand-success' : 'text-brand-danger'}`}>
                   {fng.classification}
                 </span>
               </div>
             ) : (
               <span className="animate-pulse bg-slate-200 dark:bg-white/10 w-12 h-4"></span>
             )}
          </div>
        </div>

      </div>
    </div>
  );
};

export default MarketHeader;
