
import React from 'react';
import { X, Sliders, Activity, Layers, Eye, LayoutTemplate } from 'lucide-react';
import { ChartConfig } from '../types';

interface ChartSettingsModalProps {
  config: ChartConfig;
  onChange: (c: ChartConfig) => void;
  onClose: () => void;
}

const ChartSettingsModal: React.FC<ChartSettingsModalProps> = ({ 
  config, 
  onChange, 
  onClose 
}) => {
  const toggle = (key: keyof ChartConfig) => {
    // @ts-ignore
    onChange({ ...config, [key]: !config[key] });
  };

  const updateVal = (key: keyof ChartConfig, val: number) => {
    onChange({ ...config, [key]: val });
  };

  const setChartType = (type: 'area' | 'line' | 'tradingview') => {
    onChange({ ...config, chartType: type });
  };

  return (
    <div className="absolute inset-0 z-50 bg-black/60 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-[#0b0e14] border border-brand-primary/30 w-full max-w-sm rounded-2xl shadow-[0_0_40px_rgba(0,0,0,0.5)] overflow-hidden flex flex-col max-h-[85vh]">
        
        {/* Header */}
        <div className="p-4 border-b border-white/10 flex items-center justify-between bg-white/5">
          <div className="flex items-center gap-2">
             <Sliders size={16} className="text-brand-primary" />
             <h3 className="text-sm font-black uppercase tracking-widest text-white">Chart Configuration</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
            <X size={18} />
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-8">
          
          {/* Section: Display Style */}
          <div>
             <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-4 flex items-center gap-2">
                <LayoutTemplate size={12} /> Display Style
             </h4>
             <div className="flex bg-white/5 p-1 rounded-lg border border-white/10 gap-1">
                <button 
                  onClick={() => setChartType('area')}
                  className={`flex-1 py-2 rounded-md text-[10px] font-bold uppercase transition-all ${config.chartType === 'area' ? 'bg-brand-primary text-black shadow-lg' : 'text-slate-400 hover:text-white'}`}
                >
                  Area
                </button>
                <button 
                  onClick={() => setChartType('line')}
                  className={`flex-1 py-2 rounded-md text-[10px] font-bold uppercase transition-all ${config.chartType === 'line' ? 'bg-brand-primary text-black shadow-lg' : 'text-slate-400 hover:text-white'}`}
                >
                  Line
                </button>
                <button 
                  onClick={() => setChartType('tradingview')}
                  className={`flex-1 py-2 rounded-md text-[10px] font-bold uppercase transition-all ${config.chartType === 'tradingview' ? 'bg-brand-primary text-black shadow-lg' : 'text-slate-400 hover:text-white'}`}
                >
                  TradingView
                </button>
             </div>
          </div>

          {/* Section: Overlays (Hidden if TradingView) */}
          {config.chartType !== 'tradingview' && (
            <>
              <div>
                 <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-4 flex items-center gap-2">
                    <Layers size={12} /> Overlays
                 </h4>
                 <div className="space-y-4">
                    {/* SMA Short */}
                    <div className="bg-white/[0.02] p-3 rounded-xl border border-white/5 hover:border-white/10 transition-colors">
                       <div className="flex items-center justify-between mb-3">
                          <span className="text-xs font-bold text-white">SMA (Short)</span>
                          <button onClick={() => toggle('showMA_Short')} className={`w-10 h-5 rounded-full relative transition-colors ${config.showMA_Short ? 'bg-brand-primary' : 'bg-white/10'}`}>
                              <div className={`absolute top-1 left-1 w-3 h-3 bg-black rounded-full transition-transform ${config.showMA_Short ? 'translate-x-5' : 'translate-x-0'}`}></div>
                          </button>
                       </div>
                       {config.showMA_Short && (
                         <div className="flex items-center justify-between animate-in slide-in-from-top-2 duration-200">
                            <label className="text-[10px] font-mono text-slate-400 uppercase">Period</label>
                            <input 
                              type="number" 
                              value={config.maShortPeriod} 
                              onChange={(e) => updateVal('maShortPeriod', parseInt(e.target.value))}
                              className="w-16 bg-black border border-white/10 rounded px-2 py-1 text-xs font-mono text-right focus:border-brand-primary outline-none text-brand-primary"
                            />
                         </div>
                       )}
                    </div>

                    {/* SMA Long */}
                    <div className="bg-white/[0.02] p-3 rounded-xl border border-white/5 hover:border-white/10 transition-colors">
                       <div className="flex items-center justify-between mb-3">
                          <span className="text-xs font-bold text-white">SMA (Long)</span>
                          <button onClick={() => toggle('showMA_Long')} className={`w-10 h-5 rounded-full relative transition-colors ${config.showMA_Long ? 'bg-brand-primary' : 'bg-white/10'}`}>
                              <div className={`absolute top-1 left-1 w-3 h-3 bg-black rounded-full transition-transform ${config.showMA_Long ? 'translate-x-5' : 'translate-x-0'}`}></div>
                          </button>
                       </div>
                       {config.showMA_Long && (
                         <div className="flex items-center justify-between animate-in slide-in-from-top-2 duration-200">
                            <label className="text-[10px] font-mono text-slate-400 uppercase">Period</label>
                            <input 
                              type="number" 
                              value={config.maLongPeriod} 
                              onChange={(e) => updateVal('maLongPeriod', parseInt(e.target.value))}
                              className="w-16 bg-black border border-white/10 rounded px-2 py-1 text-xs font-mono text-right focus:border-brand-primary outline-none text-brand-primary"
                            />
                         </div>
                       )}
                    </div>

                    {/* Bollinger Bands */}
                    <div className="bg-white/[0.02] p-3 rounded-xl border border-white/5 hover:border-white/10 transition-colors">
                       <div className="flex items-center justify-between mb-3">
                          <span className="text-xs font-bold text-white">Bollinger Bands</span>
                          <button onClick={() => toggle('showBB')} className={`w-10 h-5 rounded-full relative transition-colors ${config.showBB ? 'bg-brand-primary' : 'bg-white/10'}`}>
                              <div className={`absolute top-1 left-1 w-3 h-3 bg-black rounded-full transition-transform ${config.showBB ? 'translate-x-5' : 'translate-x-0'}`}></div>
                          </button>
                       </div>
                       {config.showBB && (
                         <div className="grid grid-cols-2 gap-4 animate-in slide-in-from-top-2 duration-200">
                            <div>
                               <label className="text-[10px] font-mono text-slate-400 uppercase block mb-1">Period</label>
                               <input 
                                 type="number" 
                                 value={config.bbPeriod} 
                                 onChange={(e) => updateVal('bbPeriod', parseInt(e.target.value))}
                                 className="w-full bg-black border border-white/10 rounded px-2 py-1 text-xs font-mono text-right focus:border-brand-primary outline-none text-brand-primary"
                               />
                            </div>
                            <div>
                               <label className="text-[10px] font-mono text-slate-400 uppercase block mb-1">Std Dev</label>
                               <input 
                                 type="number" 
                                 value={config.bbStdDev} 
                                 onChange={(e) => updateVal('bbStdDev', parseFloat(e.target.value))}
                                 className="w-full bg-black border border-white/10 rounded px-2 py-1 text-xs font-mono text-right focus:border-brand-primary outline-none text-brand-primary"
                               />
                            </div>
                         </div>
                       )}
                    </div>
                 </div>
              </div>

              {/* Section: Oscillators */}
              <div>
                 <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-4 flex items-center gap-2">
                    <Activity size={12} /> Oscillators
                 </h4>
                 <div className="space-y-4">
                    
                    {/* RSI */}
                    <div className="bg-white/[0.02] p-3 rounded-xl border border-white/5 hover:border-white/10 transition-colors">
                       <div className="flex items-center justify-between mb-3">
                          <span className="text-xs font-bold text-white">RSI</span>
                          <button onClick={() => toggle('showRSI')} className={`w-10 h-5 rounded-full relative transition-colors ${config.showRSI ? 'bg-brand-primary' : 'bg-white/10'}`}>
                              <div className={`absolute top-1 left-1 w-3 h-3 bg-black rounded-full transition-transform ${config.showRSI ? 'translate-x-5' : 'translate-x-0'}`}></div>
                          </button>
                       </div>
                       {config.showRSI && (
                         <div className="flex items-center justify-between animate-in slide-in-from-top-2 duration-200">
                            <label className="text-[10px] font-mono text-slate-400 uppercase">Length</label>
                            <input 
                              type="number" 
                              value={config.rsiPeriod} 
                              onChange={(e) => updateVal('rsiPeriod', parseInt(e.target.value))}
                              className="w-16 bg-black border border-white/10 rounded px-2 py-1 text-xs font-mono text-right focus:border-brand-primary outline-none text-brand-primary"
                            />
                         </div>
                       )}
                    </div>

                    {/* MACD */}
                    <div className="bg-white/[0.02] p-3 rounded-xl border border-white/5 hover:border-white/10 transition-colors">
                       <div className="flex items-center justify-between mb-3">
                          <span className="text-xs font-bold text-white">MACD</span>
                          <button onClick={() => toggle('showMACD')} className={`w-10 h-5 rounded-full relative transition-colors ${config.showMACD ? 'bg-brand-primary' : 'bg-white/10'}`}>
                              <div className={`absolute top-1 left-1 w-3 h-3 bg-black rounded-full transition-transform ${config.showMACD ? 'translate-x-5' : 'translate-x-0'}`}></div>
                          </button>
                       </div>
                       {config.showMACD && (
                         <div className="grid grid-cols-3 gap-2 animate-in slide-in-from-top-2 duration-200">
                            <div>
                               <label className="text-[10px] font-mono text-slate-400 uppercase block mb-1">Fast</label>
                               <input 
                                 type="number" 
                                 value={config.macdFast} 
                                 onChange={(e) => updateVal('macdFast', parseInt(e.target.value))}
                                 className="w-full bg-black border border-white/10 rounded px-1 py-1 text-[10px] font-mono text-center focus:border-brand-primary outline-none text-brand-primary"
                               />
                            </div>
                            <div>
                               <label className="text-[10px] font-mono text-slate-400 uppercase block mb-1">Slow</label>
                               <input 
                                 type="number" 
                                 value={config.macdSlow} 
                                 onChange={(e) => updateVal('macdSlow', parseInt(e.target.value))}
                                 className="w-full bg-black border border-white/10 rounded px-1 py-1 text-[10px] font-mono text-center focus:border-brand-primary outline-none text-brand-primary"
                               />
                            </div>
                            <div>
                               <label className="text-[10px] font-mono text-slate-400 uppercase block mb-1">Sig</label>
                               <input 
                                 type="number" 
                                 value={config.macdSignal} 
                                 onChange={(e) => updateVal('macdSignal', parseInt(e.target.value))}
                                 className="w-full bg-black border border-white/10 rounded px-1 py-1 text-[10px] font-mono text-center focus:border-brand-primary outline-none text-brand-primary"
                               />
                            </div>
                         </div>
                       )}
                    </div>
                 </div>
              </div>
            </>
          )}

        </div>

        <div className="p-4 border-t border-white/10 bg-white/5">
           <button 
              onClick={onClose}
              className="w-full py-3 bg-brand-primary text-black font-black uppercase tracking-widest text-xs rounded-lg hover:brightness-110 transition-all shadow-[0_0_20px_rgba(0,243,255,0.2)]"
           >
              Apply Configuration
           </button>
        </div>

      </div>
    </div>
  );
};

export default ChartSettingsModal;
