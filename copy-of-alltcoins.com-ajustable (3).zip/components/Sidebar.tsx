
import React, { Suspense } from 'react';
import { Newspaper, Calculator, Zap } from 'lucide-react';
import Converter from './Converter';
import CouponBanner from './CouponBanner';
import { NewsArticle, Coupon, Coin } from '../types';

interface SidebarProps {
  coins: Coin[];
  news: NewsArticle[];
  coupons: Coupon[];
  loadingNews: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ coins, news, coupons, loadingNews }) => {
  return (
    <aside className="w-full lg:w-[360px] flex flex-col gap-6 shrink-0 animate-in slide-in-from-right duration-500">
      
      {/* 1. Converter - Top Utility */}
      <div className="bg-white dark:bg-[#0d1117] rounded-[2rem] border border-slate-200 dark:border-white/5 shadow-lg overflow-hidden">
         <Suspense fallback={<div className="h-64 animate-pulse bg-slate-100 dark:bg-white/5" />}>
            <Converter coins={coins} compact={true} />
         </Suspense>
      </div>

      {/* 2. Compact News Feed - Vertical List */}
      <div className="bg-white dark:bg-[#0d1117] rounded-[2rem] border border-slate-200 dark:border-white/5 shadow-lg flex flex-col overflow-hidden max-h-[500px]">
        <div className="p-5 border-b border-slate-200 dark:border-white/5 bg-slate-50/50 dark:bg-white/[0.02] flex items-center justify-between">
           <div className="flex items-center gap-2">
              <Newspaper size={16} className="text-brand-primary" />
              <h3 className="text-sm font-black uppercase tracking-widest text-slate-700 dark:text-slate-200">Flash Feed</h3>
           </div>
           <span className="w-1.5 h-1.5 rounded-full bg-brand-primary animate-pulse"></span>
        </div>
        
        <div className="overflow-y-auto custom-scrollbar p-4 space-y-3">
           {loadingNews ? (
             [1,2,3].map(i => <div key={i} className="h-20 bg-slate-100 dark:bg-white/5 rounded-xl animate-pulse" />)
           ) : (
             news.slice(0, 8).map((item, idx) => (
                <a 
                  key={idx} 
                  href={item.url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="block p-4 rounded-xl bg-slate-50 dark:bg-white/[0.02] border border-slate-100 dark:border-white/5 hover:border-brand-primary/30 hover:bg-white dark:hover:bg-white/[0.05] transition-all group"
                >
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-[9px] font-black uppercase text-brand-primary tracking-wider">{item.source}</span>
                    <span className="text-[9px] text-slate-400 font-mono">{new Date(item.published_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                  </div>
                  <h4 className="text-xs font-bold leading-snug line-clamp-2 text-slate-900 dark:text-slate-100 group-hover:text-brand-primary transition-colors">
                    {item.title}
                  </h4>
                </a>
             ))
           )}
        </div>
      </div>

      {/* 3. Partner Drop - Compact */}
      <div className="h-[250px]">
         <CouponBanner coupons={coupons} />
      </div>

    </aside>
  );
};

export default Sidebar;
