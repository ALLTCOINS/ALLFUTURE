
import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';

const RainbowChart: React.FC = () => {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current) return;

    const width = 800;
    const height = 400;
    const margin = { top: 20, right: 30, bottom: 40, left: 60 };

    const svg = d3.select(svgRef.current)
      .attr('viewBox', `0 0 ${width} ${height}`)
      .html(''); // Clear previous content

    const g = svg.append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    // Mock Rainbow Bands (Logarithmic)
    const years = d3.range(2012, 2026);
    const x = d3.scaleLinear()
      .domain([2012, 2025])
      .range([0, width - margin.left - margin.right]);

    const y = d3.scaleLog()
      .domain([1, 1000000])
      .range([height - margin.top - margin.bottom, 0]);

    const colors = [
      { name: 'Bubble', color: '#ff0000' },
      { name: 'FOMO', color: '#ff7f00' },
      { name: 'Is this a bubble?', color: '#ffff00' },
      { name: 'HODL!', color: '#00ff00' },
      { name: 'Cheap', color: '#0000ff' },
      { name: 'Accumulate', color: '#4b0082' },
      { name: 'Fire Sale', color: '#8b00ff' }
    ];

    const generateBand = (offset: number) => {
      return years.map(yr => {
        const t = yr - 2009;
        // Formula approx: Price = 10^(a * ln(t) - b)
        const price = Math.pow(10, 2.9 * Math.log(t) - (3.5 - offset));
        return { year: yr, price };
      });
    };

    const area = d3.area<any>()
      .x(d => x(d.year))
      .y0(height - margin.top - margin.bottom)
      .y1(d => y(d.price))
      .curve(d3.curveMonotoneX);

    colors.forEach((c, i) => {
      g.append('path')
        .datum(generateBand(i * 0.4))
        .attr('fill', c.color)
        .attr('opacity', 0.15)
        .attr('d', area);
    });

    // Axes
    g.append('g')
      .attr('transform', `translate(0, ${height - margin.top - margin.bottom})`)
      .call(d3.axisBottom(x).ticks(5).tickFormat(d3.format('d')));

    g.append('g')
      .call(d3.axisLeft(y).ticks(5, '$.0s'));

    // Label
    svg.append('text')
      .attr('x', width / 2)
      .attr('y', height - 5)
      .attr('text-anchor', 'middle')
      .attr('class', 'text-xs fill-slate-500')
      .text('Logarithmic Growth Curves (Visualization purposes)');

  }, []);

  return (
    <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-lg font-bold">Bitcoin Rainbow Index</h3>
        <span className="text-xs bg-crypto-primary/10 text-crypto-primary px-2 py-1 rounded">Logarithmic</span>
      </div>
      <div className="w-full overflow-hidden">
        <svg ref={svgRef} className="w-full h-auto text-slate-400"></svg>
      </div>
    </div>
  );
};

export default RainbowChart;
