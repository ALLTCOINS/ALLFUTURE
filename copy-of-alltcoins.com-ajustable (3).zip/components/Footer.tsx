
import React, { useState } from 'react';
import { Shield, Lock, Activity, Twitter, Facebook, Link as LinkIcon, Github, Globe, Check } from 'lucide-react';

const Footer: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const handleCopyLink = () => {
    navigator.clipboard.writeText('https://alltcoins.com');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <footer className="relative bg-[#020617] border-t border-white/10 pt-16 pb-8 overflow-hidden">
      {/* Background Grid */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.05]" 
           style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '40px 40px' }}>
      </div>

      <div className="max-w-[1920px] mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          
          {/* Brand Column */}
          <div className="col-span-1 md:col-span-2">
            <h2 className="text-2xl font-black uppercase tracking-tighter text-white mb-4">
              ALLTCOINS<span className="text-brand-primary">.COM</span>
            </h2>
            <p className="text-slate-400 text-sm font-mono leading-relaxed max-w-md mb-6">
              Advanced decentralized terminal providing real-time intelligence, AI-driven market analysis, and institutional-grade data visualization for the modern trader.
            </p>
            <div className="flex items-center gap-2">
               <span className="flex items-center gap-1.5 px-3 py-1 bg-brand-success/10 border border-brand-success/20 text-brand-success text-[10px] font-black uppercase tracking-widest rounded-full">
                 <Activity size={12} /> Systems Normal
               </span>
               <span className="flex items-center gap-1.5 px-3 py-1 bg-brand-primary/10 border border-brand-primary/20 text-brand-primary text-[10px] font-black uppercase tracking-widest rounded-full">
                 v2.4.0 Quantum
               </span>
            </div>
          </div>

          {/* Security Column */}
          <div>
            <h3 className="text-xs font-black uppercase tracking-[0.2em] text-slate-500 mb-6">Security Protocols</h3>
            <ul className="space-y-4">
              <li className="flex items-center gap-3 text-slate-400">
                <Shield size={16} className="text-brand-primary" />
                <span className="text-xs font-bold uppercase">End-to-End Encryption</span>
              </li>
              <li className="flex items-center gap-3 text-slate-400">
                <Lock size={16} className="text-brand-primary" />
                <span className="text-xs font-bold uppercase">256-BIT SSL Secured</span>
              </li>
              <li className="flex items-center gap-3 text-slate-400">
                <Globe size={16} className="text-brand-primary" />
                <span className="text-xs font-bold uppercase">Decentralized Data</span>
              </li>
              {/* Secure Badge Moved Here */}
              <li className="pt-2">
                <div className="inline-flex items-center gap-1.5 px-3 py-1.5 border border-brand-primary/20 bg-brand-primary/5 text-[9px] font-black uppercase tracking-widest text-brand-primary">
                  <Lock size={10} /> Secure Connection
                </div>
              </li>
            </ul>
          </div>

          {/* Social / Share Column */}
          <div>
            <h3 className="text-xs font-black uppercase tracking-[0.2em] text-slate-500 mb-6">Connect & Share</h3>
            <div className="flex gap-2">
              <a href="https://x.com/alltcoins_x" target="_blank" rel="noopener noreferrer" className="p-3 bg-white/5 border border-white/10 text-slate-400 hover:text-white hover:bg-brand-primary/20 hover:border-brand-primary transition-all group">
                <Twitter size={18} />
              </a>
              <button className="p-3 bg-white/5 border border-white/10 text-slate-400 hover:text-white hover:bg-brand-primary/20 hover:border-brand-primary transition-all group">
                <Github size={18} />
              </button>
              <button 
                onClick={handleCopyLink}
                className="p-3 bg-white/5 border border-white/10 text-slate-400 hover:text-white hover:bg-brand-primary/20 hover:border-brand-primary transition-all group relative"
                title="Copy alltcoins.com"
              >
                {copied ? <Check size={18} className="text-brand-success" /> : <LinkIcon size={18} />}
                {copied && <span className="absolute -top-8 left-1/2 -translate-x-1/2 text-[9px] bg-brand-success text-black px-2 py-1 rounded font-bold uppercase">Copied</span>}
              </button>
            </div>
            <p className="mt-4 text-[10px] text-slate-500 font-mono">
              Join the quantum financial revolution.
            </p>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
           <p className="text-[10px] text-slate-600 font-bold uppercase tracking-wider">
             © 2024 ALLTCOINS.COM // All Rights Reserved
           </p>
           <div className="flex gap-6">
             <a href="#" className="text-[10px] text-slate-600 hover:text-brand-primary font-bold uppercase tracking-wider transition-colors">Privacy Policy</a>
             <a href="#" className="text-[10px] text-slate-600 hover:text-brand-primary font-bold uppercase tracking-wider transition-colors">Terms of Service</a>
           </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
