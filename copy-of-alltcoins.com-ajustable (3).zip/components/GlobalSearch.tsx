
import React, { useState, useEffect, useRef } from 'react';
import { Search, Loader2, Coins, Image as ImageIcon, Wrench, X, Calculator, Ticket, ChevronRight, Command } from 'lucide-react';
import { searchGlobal } from '../services/cryptoService';
import { SearchResultItem } from '../types';

interface GlobalSearchProps {
  onCoinSelect: (id: string) => void;
  onNavigate?: (type: string) => void;
}

const GlobalSearch: React.FC<GlobalSearchProps> = ({ onCoinSelect, onNavigate }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResultItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [isMobileExpanded, setIsMobileExpanded] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Close when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
        if (query === '') {
           setIsMobileExpanded(false);
        }
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [query]);

  // Keyboard shortcut to focus
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        inputRef.current?.focus();
        setIsOpen(true);
        setIsMobileExpanded(true);
      }
      if (e.key === 'Escape') {
        setIsOpen(false);
        setIsMobileExpanded(false);
        inputRef.current?.blur();
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    const delayDebounceFn = setTimeout(async () => {
      if (query.length >= 2) {
        setLoading(true);
        setIsOpen(true);
        try {
          // 1. Fetch API Results
          const apiResults = await searchGlobal(query);
          
          // 2. Inject Internal Tools if they match
          const internalResults: SearchResultItem[] = [];
          const q = query.toLowerCase();
          
          if (['swap', 'convert', 'calc', 'fx', 'exchange', 'tool'].some(k => q.includes(k))) {
            internalResults.push({ id: 'tool-converter', name: 'FX Gateway / Converter', symbol: 'TOOL', thumb: '', type: 'tool' });
          }
          if (['bonus', 'coupon', 'drop', 'free', 'code', 'reward'].some(k => q.includes(k))) {
            internalResults.push({ id: 'tool-bonus', name: 'Partner Drops & Codes', symbol: 'BONUS', thumb: '', type: 'tool' });
          }

          setResults([...internalResults, ...apiResults]);
        } catch (error) {
          console.error(error);
          setResults([]);
        } finally {
          setLoading(false);
        }
      } else {
        setResults([]);
        setIsOpen(false);
      }
    }, 400); // 400ms debounce

    return () => clearTimeout(delayDebounceFn);
  }, [query]);

  const handleSelect = (item: SearchResultItem) => {
    setQuery('');
    setIsOpen(false);
    setIsMobileExpanded(false);
    
    if (item.type === 'coin') {
      onCoinSelect(item.id);
    } else if (item.type === 'tool') {
      if (onNavigate) {
         if (item.id === 'tool-converter') onNavigate('products');
         // Can add more navigation logic here
      }
      const elementId = item.id === 'tool-converter' ? 'converter-widget' : 'bonus-widget';
      const el = document.getElementById(elementId);
      if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  const clearSearch = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    setQuery('');
    setIsOpen(false);
    setResults([]);
    // On mobile, clearing closes the expansion
    if (window.innerWidth < 640) {
       setIsMobileExpanded(false);
    }
  };

  const toggleMobileSearch = () => {
    setIsMobileExpanded(!isMobileExpanded);
    if (!isMobileExpanded) {
       setTimeout(() => inputRef.current?.focus(), 100);
    }
  };

  return (
    <div ref={containerRef} className={`relative group transition-all duration-300 ${isMobileExpanded ? 'w-full absolute right-0 top-0 left-0 z-50' : 'w-auto sm:w-full sm:max-w-[320px] static'}`}>
      
      {/* Mobile Icon Trigger (Visible only on mobile when NOT expanded) */}
      {!isMobileExpanded && (
        <button 
           onClick={toggleMobileSearch}
           className="sm:hidden p-2 text-slate-400 hover:text-white hover:bg-white/5 rounded-lg transition-colors"
        >
           <Search size={18} />
        </button>
      )}

      {/* Input Field (Visible on Desktop OR when expanded on Mobile) */}
      <div className={`relative flex items-center w-full transition-all duration-300 ${(isMobileExpanded || window.innerWidth >= 640) ? 'block' : 'hidden'}`}>
        <Search className={`absolute left-4 top-1/2 -translate-y-1/2 transition-colors ${isOpen ? 'text-brand-primary' : 'text-slate-500'}`} size={16} />
        
        <input 
          ref={inputRef}
          type="text" 
          placeholder="SEARCH ASSETS / TOOLS..." 
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            if (e.target.value.length > 0) setIsOpen(true);
          }}
          onFocus={() => { 
             setIsMobileExpanded(true); 
             if (query.length >= 2) setIsOpen(true); 
          }}
          className={`
            w-full bg-[#0d1117] border 
            ${isOpen ? 'border-brand-primary shadow-[0_0_15px_rgba(0,243,255,0.15)]' : 'border-white/10 group-hover:border-white/20'} 
            py-2.5 pl-11 pr-10 text-xs font-bold font-mono outline-none transition-all placeholder:text-slate-600 text-white rounded-xl
            ${isMobileExpanded ? 'shadow-2xl' : ''}
          `}
        />
        
        {loading ? (
          <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 text-brand-primary animate-spin" size={14} />
        ) : (query.length > 0 || isMobileExpanded) ? (
          <button onClick={clearSearch} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white p-1">
            <X size={14} />
          </button>
        ) : (
          <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1 pointer-events-none opacity-50 hidden sm:flex">
             <Command size={10} className="text-slate-500" />
             <span className="text-[9px] font-black text-slate-500">K</span>
          </div>
        )}
      </div>

      {/* Results Window */}
      {isOpen && (results.length > 0 || loading || query.length >= 2) && (
        <>
           {/* Backdrop for mobile focus */}
           <div className="fixed inset-0 z-[50] bg-black/10 backdrop-blur-[1px] sm:hidden" onClick={() => setIsOpen(false)}></div>
           
           <div className="absolute top-full left-0 right-0 mt-3 bg-[#020617] border border-brand-primary/20 shadow-[0_10px_40px_rgba(0,0,0,0.5)] rounded-2xl overflow-hidden z-[60] animate-in fade-in zoom-in-95 duration-200">
              
              {/* Header / Status Bar */}
              <div className="px-4 py-2 bg-brand-primary/5 border-b border-brand-primary/10 flex justify-between items-center">
                 <span className="text-[9px] font-black uppercase tracking-widest text-brand-primary flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-brand-primary rounded-full animate-pulse"></span>
                    System Search
                 </span>
                 <span className="text-[9px] text-slate-500 font-mono">
                    {results.length} Results
                 </span>
              </div>

              <div className="max-h-[60vh] overflow-y-auto custom-scrollbar p-2">
                 
                 {/* Internal Tools Section */}
                 {results.some(r => r.type === 'tool') && (
                    <div className="mb-2">
                       <div className="px-3 py-1.5 text-[9px] font-bold text-slate-500 uppercase tracking-wider">Internal Tools</div>
                       {results.filter(r => r.type === 'tool').map(item => (
                          <button 
                             key={item.id}
                             onClick={() => handleSelect(item)}
                             className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-brand-primary/10 hover:border hover:border-brand-primary/20 transition-all group text-left border border-transparent"
                          >
                             <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center text-brand-primary group-hover:scale-110 transition-transform">
                                {item.id.includes('bonus') ? <Ticket size={16} /> : <Calculator size={16} />}
                             </div>
                             <div>
                                <div className="text-xs font-black uppercase text-white group-hover:text-brand-primary transition-colors">{item.name}</div>
                                <div className="text-[9px] text-slate-500">Launch Module</div>
                             </div>
                             <ChevronRight size={14} className="ml-auto text-slate-600 group-hover:text-brand-primary group-hover:translate-x-1 transition-all" />
                          </button>
                       ))}
                    </div>
                 )}

                 {/* Coins Section */}
                 {results.some(r => r.type === 'coin') && (
                    <div className="mb-2">
                       <div className="px-3 py-1.5 text-[9px] font-bold text-slate-500 uppercase tracking-wider">Assets</div>
                       {results.filter(r => r.type === 'coin').map(item => (
                          <button 
                             key={item.id}
                             onClick={() => handleSelect(item)}
                             className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-slate-800/50 hover:border-l-2 hover:border-l-brand-primary transition-all group text-left border-l-2 border-transparent"
                          >
                             <img src={item.thumb} alt={item.symbol} className="w-6 h-6 rounded-full grayscale group-hover:grayscale-0" />
                             <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2">
                                   <span className="text-xs font-bold text-white truncate">{item.name}</span>
                                   <span className="text-[9px] font-black bg-slate-800 px-1.5 py-0.5 rounded text-slate-400">{item.symbol}</span>
                                </div>
                             </div>
                             {item.market_cap_rank && (
                                <span className="text-[9px] font-mono text-slate-600">#{item.market_cap_rank}</span>
                             )}
                          </button>
                       ))}
                    </div>
                 )}

                 {/* NFTs Section */}
                 {results.some(r => r.type === 'nft') && (
                    <div>
                       <div className="px-3 py-1.5 text-[9px] font-bold text-slate-500 uppercase tracking-wider">NFT Collections</div>
                       {results.filter(r => r.type === 'nft').map(item => (
                          <button 
                             key={item.id}
                             className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-purple-500/10 hover:border-l-2 hover:border-l-purple-500 transition-all group text-left border-l-2 border-transparent opacity-70 hover:opacity-100"
                          >
                             {item.thumb ? (
                                <img src={item.thumb} alt={item.symbol} className="w-6 h-6 rounded-lg" />
                             ) : (
                                <div className="w-6 h-6 bg-slate-800 rounded-lg flex items-center justify-center"><ImageIcon size={12}/></div>
                             )}
                             <div className="flex-1 min-w-0">
                                <div className="text-xs font-bold text-white truncate">{item.name}</div>
                             </div>
                             <span className="text-[9px] text-purple-400 font-bold uppercase">NFT</span>
                          </button>
                       ))}
                    </div>
                 )}

                 {results.length === 0 && !loading && (
                    <div className="py-8 text-center flex flex-col items-center opacity-50">
                       <Search size={24} className="mb-2 text-slate-600" />
                       <span className="text-[10px] font-black uppercase text-slate-500">No assets found</span>
                    </div>
                 )}
              </div>
              
              {/* Footer */}
              <div className="px-3 py-1.5 bg-slate-900/50 border-t border-white/5 flex justify-between text-[8px] text-slate-600 font-mono">
                 <span>SEARCH API v3</span>
                 <span className="flex items-center gap-1">
                    PRESS <span className="bg-slate-700 text-white px-1 rounded">ESC</span> TO CLOSE
                 </span>
              </div>
           </div>
        </>
      )}
    </div>
  );
};

export default GlobalSearch;
