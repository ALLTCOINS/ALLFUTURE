
import React, { useState, useEffect } from 'react';
import { Reorder, motion, AnimatePresence } from 'framer-motion';
import { GripVertical, X, Maximize2, Minimize2, Plus, LayoutGrid, Check, RefreshCcw, Newspaper, ExternalLink, Twitter, Link as LinkIcon, Star, AlignLeft } from 'lucide-react';
import { DashboardWidget, WidgetSize, Coin, NewsArticle, Coupon } from '../types';
import MarketTable from './MarketTable';
import Converter from './Converter';
import NewsWidget from './NewsWidget';
import CouponBanner from './CouponBanner';

interface DashboardProps {
  coins: Coin[];
  news: NewsArticle[];
  coupons: Coupon[];
  loadingNews: boolean;
  onCoinSelect: (id: string) => void;
  selectedCoinId: string;
  favorites: string[];
  toggleFavorite: (e: React.MouseEvent, id: string) => void;
  sortConfig: any;
  onSort: any;
  isWatchlistActive: boolean;
  onToggleWatchlist: () => void;
}

const DEFAULT_WIDGETS: DashboardWidget[] = [
  // Row 1: The Main Terminal (Full Width)
  { id: 'market-1', type: 'market-table', size: 'full', visible: true },
  
  // Row 2: Tools & Insights (3 Columns)
  { id: 'converter-1', type: 'converter', size: 'small', visible: true },
  { id: 'news-1', type: 'news-feed', size: 'small', visible: true },
  { id: 'bonus-1', type: 'bonus-drops', size: 'small', visible: true },
];

const SIZE_MAP: Record<WidgetSize, string> = {
  small: 'w-full lg:w-[33.333%] lg:max-w-[33.333%]',
  medium: 'w-full lg:w-[50%] lg:max-w-[50%]',
  large: 'w-full lg:w-[66.666%] lg:max-w-[66.666%]',
  full: 'w-full',
};

// Defined specific glow colors per module type
const WIDGET_STYLES: Record<string, string> = {
  'market-table': 'hover:border-brand-primary/60 hover:shadow-[0_0_30px_rgba(0,243,255,0.15)] bg-[#050910]/60 backdrop-blur-md', // Cyan Glow + Transparency
  'converter': 'hover:border-orange-500/60 hover:shadow-[0_0_30px_rgba(249,115,22,0.15)] bg-[#050910]/80 backdrop-blur-md', // Orange Glow
  'news-feed': 'hover:border-purple-500/60 hover:shadow-[0_0_30px_rgba(168,85,247,0.15)] bg-[#050910]/80 backdrop-blur-md', // Purple Glow
  'bonus-drops': 'hover:border-green-500/60 hover:shadow-[0_0_30px_rgba(34,197,94,0.15)] bg-[#050910]/80 backdrop-blur-md', // Green Glow
};

// Internal News Reader Modal Component
const NewsReaderModal = ({ article, onClose }: { article: NewsArticle, onClose: () => void }) => {
  if (!article) return null;
  
  const handleShare = (platform: 'twitter' | 'copy') => {
     const text = encodeURIComponent(`${article.title} - via Alltcoins Terminal`);
     const url = encodeURIComponent(article.url);
     
     if (platform === 'twitter') {
       window.open(`https://twitter.com/intent/tweet?text=${text}&url=${url}`, '_blank');
     } else {
       navigator.clipboard.writeText(`${article.title} ${article.url}`);
     }
  };

  return (
    <div className="fixed inset-0 z-[200] bg-black/80 backdrop-blur-xl flex items-center justify-center p-4">
       <div className="bg-[#050910] border border-white/10 w-full max-w-4xl rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200">
         <div className="flex items-center justify-between p-6 border-b border-white/10">
            <div className="flex items-center gap-3">
               <div className="p-2 bg-brand-primary/10 rounded-lg text-brand-primary">
                  <Newspaper size={20} />
               </div>
               <div>
                  <h3 className="text-sm font-black uppercase tracking-widest text-slate-400">Intel Reader</h3>
                  <p className="text-xs font-bold text-white">{article.source}</p>
               </div>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors text-slate-400 hover:text-white">
               <X size={24} />
            </button>
         </div>
         
         <div className="flex-1 overflow-y-auto p-8">
            <h1 className="text-2xl md:text-3xl font-black text-white leading-tight mb-6">{article.title}</h1>
            <p className="text-lg text-slate-300 leading-relaxed font-medium mb-8">
               {article.summary || "Full detailed report available at source."}
            </p>

            <div className="flex gap-4 pt-6 border-t border-white/10">
               <button onClick={() => handleShare('twitter')} className="flex items-center gap-2 px-4 py-2 bg-[#1DA1F2]/10 text-[#1DA1F2] border border-[#1DA1F2]/20 rounded-lg hover:bg-[#1DA1F2] hover:text-white transition-all font-bold text-xs uppercase">
                  <Twitter size={16} /> Tweet
               </button>
               <button onClick={() => handleShare('copy')} className="flex items-center gap-2 px-4 py-2 bg-white/5 text-slate-300 border border-white/10 rounded-lg hover:bg-white/10 hover:text-white transition-all font-bold text-xs uppercase">
                  <LinkIcon size={16} /> Copy Link
               </button>
               <a href={article.url} target="_blank" rel="noopener noreferrer" className="ml-auto flex items-center gap-2 px-6 py-2 bg-brand-primary text-black font-black uppercase tracking-widest text-xs rounded-lg hover:scale-105 transition-transform">
                  Read Source <ExternalLink size={14} />
               </a>
            </div>
         </div>
       </div>
    </div>
  );
};

const Dashboard: React.FC<DashboardProps> = (props) => {
  const [widgets, setWidgets] = useState<DashboardWidget[]>(() => {
    try {
      const saved = localStorage.getItem('dashboard_layout_v3');
      return saved ? JSON.parse(saved) : DEFAULT_WIDGETS;
    } catch {
      return DEFAULT_WIDGETS;
    }
  });

  const [isEditMode, setIsEditMode] = useState(false);
  const [readingArticle, setReadingArticle] = useState<NewsArticle | null>(null);

  useEffect(() => {
    localStorage.setItem('dashboard_layout_v3', JSON.stringify(widgets));
  }, [widgets]);

  const handleResize = (id: string) => {
    const sizes: WidgetSize[] = ['small', 'medium', 'large', 'full'];
    setWidgets(prev => prev.map(w => {
      if (w.id === id) {
        const nextIndex = (sizes.indexOf(w.size) + 1) % sizes.length;
        return { ...w, size: sizes[nextIndex] };
      }
      return w;
    }));
  };

  const handleRemove = (id: string) => {
    setWidgets(prev => prev.map(w => w.id === id ? { ...w, visible: false } : w));
  };

  const handleAdd = (id: string) => {
    setWidgets(prev => prev.map(w => w.id === id ? { ...w, visible: true } : w));
  };

  const handleReset = () => {
    setWidgets(JSON.parse(JSON.stringify(DEFAULT_WIDGETS)));
  };

  const renderWidgetContent = (widget: DashboardWidget) => {
    switch (widget.type) {
      case 'market-table':
        return (
          <MarketTable 
            coins={props.coins} 
            onSelect={props.onCoinSelect}
            selectedId={props.selectedCoinId}
            favorites={props.favorites}
            toggleFavorite={props.toggleFavorite}
            sortConfig={props.sortConfig}
            onSort={props.onSort}
          />
        );
      case 'converter':
        return <Converter coins={props.coins} compact={true} />;
      case 'news-feed':
        return <NewsWidget news={props.news} loading={props.loadingNews} onRead={setReadingArticle} />;
      case 'bonus-drops':
        return <CouponBanner coupons={props.coupons} />;
      default:
        return null;
    }
  };

  const hiddenWidgets = widgets.filter(w => !w.visible);

  return (
    <div className="w-full relative">
      
      {/* Modal for Dashboard News */}
      {readingArticle && (
        <NewsReaderModal article={readingArticle} onClose={() => setReadingArticle(null)} />
      )}

      {/* Background Grid Lines for Technical Feel */}
      <div className="absolute inset-0 pointer-events-none z-[-1] opacity-[0.03]" 
           style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '40px 40px' }}>
      </div>

      {/* Controls Bar - REFINED */}
      <div className="flex items-center justify-between mb-6 sticky top-20 z-40 bg-[#010409]/80 backdrop-blur-md py-2 border-b border-white/5">
        
        {/* Left Side: Label */}
        <div className="flex items-center gap-2 px-2">
           <div className="flex items-center gap-2 px-2 text-slate-300">
              <AlignLeft size={16} />
              <span className="text-xs font-black uppercase tracking-[0.2em] text-white">Alt Markets</span>
           </div>
        </div>

        {/* Right Side: Watchlist & Edit */}
        <div className="flex items-center gap-2 px-2">
           {isEditMode && hiddenWidgets.length > 0 && (
             <motion.div 
               initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }}
               className="flex items-center gap-2 px-2"
             >
               <span className="text-[10px] font-bold text-slate-500 uppercase mr-2 hidden sm:inline">Add:</span>
               {hiddenWidgets.map(w => (
                 <button 
                   key={w.id} 
                   onClick={() => handleAdd(w.id)}
                   className="flex items-center gap-1.5 px-3 py-1.5 bg-brand-success/10 text-brand-success border border-brand-success/20 text-[9px] font-black uppercase hover:bg-brand-success hover:text-black transition-colors"
                 >
                   <Plus size={10} /> {w.type}
                 </button>
               ))}
             </motion.div>
           )}

           <button 
             onClick={props.onToggleWatchlist}
             className={`flex items-center gap-2 px-4 py-2 text-[10px] font-black uppercase tracking-[0.2em] transition-all border ${props.isWatchlistActive ? 'bg-brand-primary text-black border-brand-primary shadow-[0_0_15px_rgba(0,243,255,0.4)]' : 'bg-transparent text-slate-400 border-slate-700 hover:border-brand-primary hover:text-brand-primary'}`}
           >
             <Star size={14} className={props.isWatchlistActive ? "fill-black" : ""} />
             {props.isWatchlistActive ? 'Watchlist Active' : 'Watchlist'}
           </button>

           <button 
             onClick={() => setIsEditMode(!isEditMode)}
             className={`flex items-center gap-2 px-4 py-2 text-[10px] font-black uppercase tracking-[0.2em] transition-all border ${isEditMode ? 'bg-white text-black border-white' : 'bg-transparent text-slate-500 border-slate-700 hover:border-white hover:text-white'}`}
           >
             {isEditMode ? <Check size={14} strokeWidth={3} /> : <LayoutGrid size={14} />}
             {isEditMode ? 'Done' : 'Edit Grid'}
           </button>
           
           {isEditMode && (
             <motion.button 
               initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }}
               onClick={handleReset}
               className="p-2 border border-slate-700 text-slate-400 hover:border-brand-danger hover:text-brand-danger transition-colors"
               title="Reset Layout"
             >
               <RefreshCcw size={14} />
             </motion.button>
           )}
        </div>
      </div>

      <Reorder.Group 
        values={widgets} 
        onReorder={setWidgets} 
        // Using Flex Wrap instead of Grid for smoother 2D dragging flow
        className="flex flex-wrap w-full gap-y-4"
        style={{ marginLeft: '-0.5rem', marginRight: '-0.5rem' }} // Negative margin for gaps
      >
        <AnimatePresence>
          {widgets.map((widget) => (
            widget.visible && (
              <Reorder.Item 
                key={widget.id} 
                value={widget} 
                dragListener={isEditMode}
                // IF it's the market table, force it to be extremely tall to show 100 items without internal scroll (or minimal)
                className={`${SIZE_MAP[widget.size]} px-2 ${widget.type === 'market-table' ? 'h-[1200px]' : 'h-[500px]'}`} 
                layout // Enable layout animation for smooth sorting
              >
                {/* WIDGET CONTAINER - ALIVE & CONNECTED */}
                <div 
                  className={`
                    relative h-full group
                    border border-white/5 
                    transition-all duration-300 ease-out
                    flex flex-col overflow-hidden
                    rounded-lg
                    ${WIDGET_STYLES[widget.type]}
                    ${isEditMode ? 'cursor-move opacity-90 border-dashed border-slate-500 bg-black' : ''}
                  `}
                >
                  
                  {/* Scanline Effect (Only visible on hover) */}
                  <div className="absolute inset-0 bg-gradient-to-b from-transparent via-white/5 to-transparent -translate-y-full group-hover:animate-[shimmer_1.5s_infinite] pointer-events-none z-10"></div>

                  {/* Widget Content */}
                  <div className="flex-1 relative z-0 flex flex-col overflow-hidden">
                    {renderWidgetContent(widget)}
                  </div>

                  {/* Edit Mode Overlays */}
                  {isEditMode && (
                    <div className="absolute top-2 right-2 z-50 flex items-center gap-1">
                          <button 
                             onClick={() => handleResize(widget.id)}
                             className="p-1.5 bg-black text-white border border-white/20 hover:border-brand-primary hover:text-brand-primary transition-colors"
                             title="Resize Widget"
                           >
                             {widget.size === 'small' && <Maximize2 size={12} />}
                             {widget.size === 'full' && <Minimize2 size={12} />}
                             {(widget.size === 'medium' || widget.size === 'large') && <Maximize2 size={12} />}
                          </button>
                          <button 
                             onClick={() => handleRemove(widget.id)}
                             className="p-1.5 bg-black text-white border border-white/20 hover:border-brand-danger hover:text-brand-danger transition-colors"
                             title="Hide Widget"
                          >
                             <X size={12} />
                          </button>
                    </div>
                  )}
                  
                  {/* Type Label (Technical Design) */}
                  <div className={`absolute bottom-0 right-0 px-2 py-0.5 text-[8px] font-black uppercase bg-black/50 backdrop-blur-sm border-t border-l border-slate-800 text-slate-500 group-hover:text-white transition-colors pointer-events-none z-20 opacity-50 group-hover:opacity-100`}>
                     {widget.type} :: {widget.size}
                  </div>
                </div>
              </Reorder.Item>
            )
          ))}
        </AnimatePresence>
      </Reorder.Group>

      {/* Empty State */}
      {widgets.every(w => !w.visible) && (
        <div className="flex flex-col items-center justify-center py-32 border border-dashed border-slate-700 bg-[#050910]">
           <LayoutGrid size={48} className="text-slate-600 mb-4" />
           <h3 className="text-xl font-black uppercase text-slate-500">System Empty</h3>
           <button onClick={handleReset} className="mt-6 px-6 py-3 bg-brand-primary text-black font-bold uppercase tracking-wider text-xs border border-brand-primary hover:bg-black hover:text-brand-primary transition-colors">
             Initialize Default
           </button>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
