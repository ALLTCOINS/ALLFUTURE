
import React, { useEffect, useRef } from 'react';

interface TradingViewChartProps {
  symbol: string;
  theme: 'light' | 'dark';
  interval?: string;
}

const TradingViewChart: React.FC<TradingViewChartProps> = ({ symbol, theme, interval = 'D' }) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // Create unique ID for the container to avoid collisions
    const containerId = `tv-chart-${Math.random().toString(36).substring(7)}`;
    const widgetContainer = document.createElement('div');
    widgetContainer.id = containerId;
    widgetContainer.style.width = '100%';
    widgetContainer.style.height = '100%';
    widgetContainer.className = "tradingview-widget-container__widget";

    // Clear and append new container
    containerRef.current.innerHTML = '';
    containerRef.current.appendChild(widgetContainer);

    const script = document.createElement("script");
    script.src = "https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js";
    script.type = "text/javascript";
    script.async = true;
    script.innerHTML = JSON.stringify({
      "autosize": true,
      "symbol": `BINANCE:${symbol.toUpperCase()}USDT`,
      "interval": interval,
      "timezone": "Etc/UTC",
      "theme": theme,
      "style": "1",
      "locale": "en",
      "enable_publishing": false,
      "backgroundColor": "rgba(0, 0, 0, 0)", 
      "gridColor": "rgba(255, 255, 255, 0.05)",
      "hide_top_toolbar": true,
      "allow_symbol_change": true,
      "calendar": false,
      "support_host": "https://www.tradingview.com"
    });
    
    containerRef.current.appendChild(script);

    // Cleanup
    return () => {
      if (containerRef.current) {
        containerRef.current.innerHTML = '';
      }
    };
  }, [symbol, theme, interval]);

  return (
    <div className="tradingview-widget-container w-full h-full" ref={containerRef}>
      {/* Widget injected here */}
    </div>
  );
};

export default TradingViewChart;
