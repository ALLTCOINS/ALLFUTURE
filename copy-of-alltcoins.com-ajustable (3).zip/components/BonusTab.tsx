
import React, { useState, useMemo } from 'react';
import { Gift, Copy, Check, Search, ExternalLink } from 'lucide-react';
import { Coupon } from '../types';

interface BonusTabProps {
  coupons: Coupon[];
}

const BonusTab: React.FC<BonusTabProps> = ({ coupons }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [imgError, setImgError] = useState<Record<string, boolean>>({});

  const handleCopy = (id: string, code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleImgError = (id: string) => {
    setImgError(prev => ({ ...prev, [id]: true }));
  };

  const filteredCoupons = useMemo(() => {
    if (!searchTerm) return coupons;
    const lowerTerm = searchTerm.toLowerCase();
    return coupons.filter(c => 
      c.platform.toLowerCase().includes(lowerTerm) || 
      c.description.toLowerCase().includes(lowerTerm) ||
      c.code.toLowerCase().includes(lowerTerm)
    );
  }, [coupons, searchTerm]);

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-20">
      
      {/* Header Section */}
      <div className="bg-gradient-to-br from-brand-primary/10 via-[#0d1117] to-slate-900 p-10 md:p-14 rounded-[3rem] border border-brand-primary/20 relative overflow-hidden shadow-2xl">
        <div className="relative z-10 max-w-2xl">
          <div className="flex items-center gap-4 mb-6">
             <div className="p-4 bg-brand-primary text-black rounded-full shadow-[0_0_25px_rgba(0,243,255,0.4)]">
                <Gift size={36} strokeWidth={2.5} />
             </div>
             <div className="h-px w-24 bg-brand-primary/50"></div>
          </div>
          <h2 className="text-4xl md:text-6xl font-black tracking-tighter uppercase text-white mb-6">
            Partner <span className="text-brand-primary">Drops</span>
          </h2>
          <p className="text-slate-300 font-medium text-base md:text-lg leading-relaxed max-w-lg uppercase tracking-wide opacity-80">
            Access exclusive fee discounts, welcome bonuses, and premium tiers with our verified partner codes.
          </p>

          {/* Search Input */}
          <div className="mt-8 relative max-w-md group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-brand-primary transition-colors" size={20} />
            <input 
              type="text" 
              placeholder="Search by platform or benefit..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-900/50 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white placeholder:text-slate-500 outline-none focus:border-brand-primary/50 focus:ring-1 focus:ring-brand-primary/50 transition-all font-bold"
            />
          </div>
        </div>
        
        {/* Background Decoration */}
        <div className="absolute right-0 top-0 h-full w-2/3 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5 mask-image-linear-to-l"></div>
        <div className="absolute -right-32 -top-32 w-[600px] h-[600px] bg-brand-primary/10 blur-[120px] rounded-full pointer-events-none"></div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-8 min-h-[400px]">
        {filteredCoupons.length > 0 ? (
          filteredCoupons.map((coupon, index) => (
            <div 
              key={coupon.id} 
              className="group relative bg-white dark:bg-[#161b22] rounded-[2.5rem] border border-slate-200 dark:border-white/5 p-8 flex flex-col hover:border-brand-primary/50 transition-all duration-300 hover:shadow-[0_0_25px_rgba(0,243,255,0.1)] hover:-translate-y-1 overflow-hidden"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              {/* Hover Glow - Subtle */}
              <div className="absolute inset-0 bg-gradient-to-br from-brand-primary/0 to-brand-primary/0 group-hover:from-brand-primary/5 group-hover:to-transparent transition-all duration-500 pointer-events-none"></div>

              <div className="relative z-10 flex flex-col items-center text-center mb-6">
                  {/* Circular Logo Container */}
                  <div className="w-24 h-24 rounded-full bg-white p-1 shadow-xl border-4 border-slate-50 dark:border-white/5 flex items-center justify-center overflow-hidden mb-6 group-hover:border-brand-primary/30 transition-colors duration-300 relative">
                    <div className="absolute inset-0 bg-gradient-to-tr from-slate-100 to-white opacity-50"></div>
                    {imgError[coupon.id] ? (
                        <div className="w-full h-full flex items-center justify-center bg-slate-100 rounded-full text-slate-400 font-bold text-3xl">
                          {coupon.platform.charAt(0)}
                        </div>
                    ) : (
                        <img 
                          src={coupon.logo} 
                          alt={coupon.platform} 
                          className="w-full h-full object-cover rounded-full" 
                          onError={() => handleImgError(coupon.id)}
                        />
                    )}
                  </div>
                  
                  <h3 className="text-2xl font-black uppercase tracking-tight text-slate-900 dark:text-white leading-none mb-2">
                    {coupon.platform}
                  </h3>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest border border-slate-200 dark:border-white/10 px-3 py-1 rounded-full bg-slate-50 dark:bg-white/5 group-hover:text-brand-primary transition-colors">
                    Verified Partner
                  </span>
              </div>

              {/* Description Box */}
              <div className="relative z-10 mb-8 flex-grow text-center bg-slate-50 dark:bg-black/20 p-5 rounded-2xl border border-slate-100 dark:border-white/5 flex items-center justify-center">
                  <p className="text-sm font-bold text-slate-700 dark:text-slate-200 leading-snug">
                    {coupon.description}
                  </p>
              </div>

              {/* Actions */}
              <div className="relative z-10 space-y-3 mt-auto">
                  <div className="flex items-center gap-2">
                    <div className="flex-1 relative">
                        <div className="absolute inset-0 bg-slate-100 dark:bg-black/20 rounded-2xl border border-slate-200 dark:border-white/5"></div>
                        <div className="relative px-4 py-3.5 font-mono font-bold text-sm text-slate-900 dark:text-slate-300 tracking-wider text-center truncate select-all">
                          {coupon.code}
                        </div>
                    </div>
                    <button 
                      onClick={() => handleCopy(coupon.id, coupon.code)}
                      className="p-3.5 bg-slate-100 dark:bg-white/5 rounded-2xl border border-slate-200 dark:border-white/5 hover:bg-slate-200 dark:hover:bg-white/10 hover:text-brand-primary transition-colors text-slate-500"
                      title="Copy Code"
                    >
                        {copiedId === coupon.id ? <Check size={20} className="text-brand-success" /> : <Copy size={20} />}
                    </button>
                  </div>

                  {/* Distinctive Reward Button */}
                  <a 
                    href={coupon.link} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="w-full flex items-center justify-center gap-3 bg-gradient-to-r from-brand-primary to-brand-secondary text-black py-4 rounded-2xl text-xs font-black uppercase tracking-widest hover:brightness-110 active:scale-95 transition-all shadow-[0_4px_20px_rgba(0,243,255,0.25)] hover:shadow-[0_4px_25px_rgba(0,243,255,0.4)]"
                  >
                    <ExternalLink size={16} strokeWidth={3} />
                    <span>Claim Reward</span>
                  </a>
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-full flex flex-col items-center justify-center py-20 opacity-50">
             <Search size={48} className="text-slate-500 mb-4" />
             <p className="text-xl font-bold uppercase tracking-widest text-slate-500">No coupons found</p>
             <button onClick={() => setSearchTerm('')} className="mt-4 text-brand-primary font-bold text-sm uppercase hover:underline">Clear Search</button>
          </div>
        )}
      </div>
    </div>
  );
};

export default BonusTab;
