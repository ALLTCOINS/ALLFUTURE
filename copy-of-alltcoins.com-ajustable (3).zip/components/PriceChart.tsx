
import React, { useMemo, useState, useCallback, useRef, useEffect, memo } from 'react';
import { 
  ComposedChart, Area, Line, XAxis, YAxis, CartesianGrid, Tooltip, 
  ResponsiveContainer, ReferenceLine, Legend, Brush
} from 'recharts';
import { Pencil, Trash2, MousePointer2, Eraser } from 'lucide-react';
import { ChartConfig } from '../types';

interface PriceChartProps {
  data: { time: number; price: number }[];
  isUp: boolean;
  title: string;
  settings: ChartConfig;
}

interface TrendLine {
  id: string;
  x1: number; // percentage 0-100
  y1: number; // percentage 0-100
  x2: number;
  y2: number;
  color: string;
}

const PriceChart: React.FC<PriceChartProps> = ({ data, isUp, settings }) => {
  const [zoomDomain, setZoomDomain] = useState<[number, number] | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const color = isUp ? '#00ffa3' : '#ff2e5f';

  // Drawing State
  const [isDrawingMode, setIsDrawingMode] = useState(false);
  const [lines, setLines] = useState<TrendLine[]>([]);
  const [currentStart, setCurrentStart] = useState<{x: number, y: number} | null>(null);
  const [currentEnd, setCurrentEnd] = useState<{x: number, y: number} | null>(null);
  const [drawingColor, setDrawingColor] = useState('#00f3ff');

  const [isPanning, setIsPanning] = useState(false);
  const [startX, setStartX] = useState(0);

  const chartData = useMemo(() => {
    if (!data || data.length === 0) return [];
    const prices = data.map(d => d.price);
    
    // Optimizations: Calculate loop once for SMAs if needed, but separate is cleaner for reading.
    const calculateSMA = (period: number) => {
      return prices.map((_, idx) => {
        if (idx < period - 1) return null;
        const sum = prices.slice(idx - period + 1, idx + 1).reduce((a, b) => a + b, 0);
        return sum / period;
      });
    };

    const calculateRSI = (period: number) => {
      const rsi = new Array(prices.length).fill(null);
      let avgGain = 0; let avgLoss = 0;
      for (let i = 1; i < prices.length; i++) {
        const diff = prices[i] - prices[i - 1];
        const gain = diff > 0 ? diff : 0; const loss = diff < 0 ? -diff : 0;
        if (i <= period) {
          avgGain += gain; avgLoss += loss;
          if (i === period) { avgGain /= period; avgLoss /= period; }
        } else {
          avgGain = (avgGain * (period - 1) + gain) / period;
          avgLoss = (avgLoss * (period - 1) + loss) / period;
          const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
          rsi[i] = 100 - (100 / (1 + rs));
        }
      }
      return rsi;
    };

    const calculateEMA = (period: number, prevEMA: number | null, currentPrice: number) => {
      const k = 2 / (period + 1);
      return prevEMA === null ? currentPrice : currentPrice * k + prevEMA * (1 - k);
    };

    const calculateMACD = () => {
      const emaFastArr = []; const emaSlowArr = [];
      let emaFast = null; let emaSlow = null;
      for (let i = 0; i < prices.length; i++) {
        emaFast = calculateEMA(settings.macdFast, emaFast, prices[i]);
        emaSlow = calculateEMA(settings.macdSlow, emaSlow, prices[i]);
        emaFastArr.push(emaFast); emaSlowArr.push(emaSlow);
      }
      const macdLine = emaFastArr.map((ef, i) => (ef && emaSlowArr[i]) ? ef - emaSlowArr[i] : null);
      let signal = null;
      const signalLine = macdLine.map((m) => {
        if (m === null) return null;
        signal = calculateEMA(settings.macdSignal, signal, m);
        return signal;
      });
      return { macdLine, signalLine };
    };

    const calculateBB = (period: number, multiplier: number) => {
      const sma = calculateSMA(period);
      const upper = sma.map((m, i) => {
        if (m === null) return null;
        const slice = prices.slice(Math.max(0, i - period + 1), i + 1);
        const variance = slice.reduce((acc, curr) => acc + Math.pow(curr - m, 2), 0) / period;
        return m + multiplier * Math.sqrt(variance);
      });
      const lower = sma.map((m, i) => {
        if (m === null) return null;
        const slice = prices.slice(Math.max(0, i - period + 1), i + 1);
        const variance = slice.reduce((acc, curr) => acc + Math.pow(curr - m, 2), 0) / period;
        return m - multiplier * Math.sqrt(variance);
      });
      return { upper, lower };
    };

    const maShort = settings.showMA_Short ? calculateSMA(settings.maShortPeriod) : [];
    const maLong = settings.showMA_Long ? calculateSMA(settings.maLongPeriod) : [];
    const rsi = settings.showRSI ? calculateRSI(settings.rsiPeriod) : [];
    const { macdLine, signalLine } = settings.showMACD ? calculateMACD() : { macdLine: [], signalLine: [] };
    const { upper: bbUpper, lower: bbLower } = settings.showBB ? calculateBB(settings.bbPeriod, settings.bbStdDev) : { upper: [], lower: [] };

    return data.map((d, i) => ({
      ...d,
      maShort: maShort[i], maLong: maLong[i], rsi: rsi[i],
      macd: macdLine[i], signal: signalLine[i],
      bbUpper: bbUpper[i], bbLower: bbLower[i]
    }));
  }, [data, settings]);

  useEffect(() => {
    const el = containerRef.current;
    if (!el || isDrawingMode) return; // Disable zoom wheel when drawing

    const handleWheelNative = (e: WheelEvent) => {
      if (!data.length) return;
      e.preventDefault();
      e.stopPropagation();

      const zoomFactor = 0.12;
      const direction = e.deltaY > 0 ? 1 : -1;
      const currentDomain = zoomDomain || [0, data.length - 1];
      const range = currentDomain[1] - currentDomain[0];
      const mid = (currentDomain[0] + currentDomain[1]) / 2;
      const newRange = range * (1 + direction * zoomFactor);
      
      const clampedRange = Math.max(15, Math.min(data.length - 1, newRange));
      const nextStart = Math.max(0, mid - clampedRange / 2);
      const nextEnd = Math.min(data.length - 1, nextStart + clampedRange);
      
      // Clear lines on zoom change as they are screen-space relative
      setLines([]);
      setZoomDomain([Math.floor(nextStart), Math.ceil(nextEnd)]);
    };

    el.addEventListener('wheel', handleWheelNative, { passive: false });
    return () => el.removeEventListener('wheel', handleWheelNative);
  }, [data.length, zoomDomain, isDrawingMode]);

  const handleMouseDown = (e: React.MouseEvent) => {
    if (isDrawingMode) {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 100;
      const y = ((e.clientY - rect.top) / rect.height) * 100;
      setCurrentStart({ x, y });
      setCurrentEnd({ x, y });
    } else {
      if (e.button !== 0) return;
      e.preventDefault();
      setIsPanning(true);
      setStartX(e.clientX);
      if (containerRef.current) containerRef.current.style.cursor = 'grabbing';
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDrawingMode) {
      if (!currentStart || !containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 100;
      const y = ((e.clientY - rect.top) / rect.height) * 100;
      setCurrentEnd({ x, y });
    } else {
      if (!isPanning || !data.length || !containerRef.current) return;
      
      e.preventDefault();

      const dX = e.clientX - startX;
      if (Math.abs(dX) < 2) return; 

      const currentDomain = zoomDomain || [0, data.length - 1];
      const range = currentDomain[1] - currentDomain[0];
      const containerWidth = containerRef.current.clientWidth;
      
      const shift = Math.round((dX / containerWidth) * range);

      if (shift === 0) return;

      let nextStart = currentDomain[0] - shift;
      let nextEnd = currentDomain[1] - shift;

      if (nextStart < 0) {
        const diff = 0 - nextStart;
        nextStart += diff;
        nextEnd += diff;
      }
      if (nextEnd > data.length - 1) {
        const diff = nextEnd - (data.length - 1);
        nextStart -= diff;
        nextEnd -= diff;
      }

      nextStart = Math.max(0, nextStart);
      nextEnd = Math.min(data.length - 1, nextEnd);

      if (nextStart !== currentDomain[0] || nextEnd !== currentDomain[1]) {
        setLines([]); // Clear lines on pan
        setZoomDomain([nextStart, nextEnd]);
        setStartX(e.clientX);
      }
    }
  };

  const handleMouseUp = () => {
    if (isDrawingMode) {
      if (currentStart && currentEnd) {
        setLines(prev => [...prev, {
          id: Date.now().toString(),
          x1: currentStart.x,
          y1: currentStart.y,
          x2: currentEnd.x,
          y2: currentEnd.y,
          color: drawingColor
        }]);
      }
      setCurrentStart(null);
      setCurrentEnd(null);
    } else {
      setIsPanning(false);
      if (containerRef.current) containerRef.current.style.cursor = 'grab';
    }
  };

  const formatYAxis = (val: number) => {
    if (val >= 1e6) return `$${(val / 1e6).toFixed(1)}M`;
    if (val >= 1e3) return `$${(val / 1e3).toFixed(1)}k`;
    return `$${val.toFixed(2)}`;
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    // Hide tooltip while panning or drawing
    if (isPanning || isDrawingMode) return null;
    
    if (active && payload && payload.length) {
      return (
        <div className="bg-[#020617]/95 border border-white/10 p-5 rounded-[1.5rem] shadow-2xl backdrop-blur-xl z-[200]">
          <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-3 border-b border-white/5 pb-2">
            {new Date(label).toLocaleString()}
          </p>
          <div className="space-y-2">
            {payload.map((p: any, i: number) => (
              <div key={i} className="flex items-center justify-between space-x-6">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-tighter">{p.name}</span>
                <span className="text-xs font-mono font-black" style={{ color: p.color }}>
                  {p.value?.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </span>
              </div>
            ))}
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="relative w-full h-full flex flex-col space-y-4 select-none touch-none bg-black/10 rounded-[2.5rem] p-4 transition-all">
      
      {/* Drawing Toolbar */}
      <div className="absolute top-4 left-4 z-50 flex flex-col gap-2 bg-white/10 dark:bg-black/40 backdrop-blur-md p-1.5 rounded-xl border border-white/10">
         <button 
           onClick={() => setIsDrawingMode(!isDrawingMode)}
           className={`p-2 rounded-lg transition-all ${isDrawingMode ? 'bg-brand-primary text-black shadow-[0_0_15px_rgba(0,243,255,0.4)]' : 'text-slate-400 hover:bg-white/10 hover:text-white'}`}
           title={isDrawingMode ? "Exit Drawing Mode" : "Draw Trendline"}
         >
           {isDrawingMode ? <Pencil size={16} /> : <MousePointer2 size={16} />}
         </button>
         
         {isDrawingMode && (
           <div className="flex flex-col gap-2 animate-in fade-in slide-in-from-left-2 duration-200 border-t border-white/10 pt-2">
              <div className="flex flex-col gap-1.5 items-center">
                 <button onClick={() => setDrawingColor('#00f3ff')} className={`w-3 h-3 rounded-full bg-[#00f3ff] ${drawingColor === '#00f3ff' ? 'ring-2 ring-white' : ''}`} />
                 <button onClick={() => setDrawingColor('#39ff14')} className={`w-3 h-3 rounded-full bg-[#39ff14] ${drawingColor === '#39ff14' ? 'ring-2 ring-white' : ''}`} />
                 <button onClick={() => setDrawingColor('#ff2e5f')} className={`w-3 h-3 rounded-full bg-[#ff2e5f] ${drawingColor === '#ff2e5f' ? 'ring-2 ring-white' : ''}`} />
              </div>
              <div className="w-full h-px bg-white/10"></div>
              <button 
                onClick={() => setLines([])}
                className="p-2 text-slate-400 hover:text-brand-danger hover:bg-white/10 rounded-lg transition-colors"
                title="Clear All Lines"
              >
                <Eraser size={16} />
              </button>
           </div>
         )}
      </div>

      <div 
        ref={containerRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        className={`relative w-full h-full flex flex-col space-y-4 ${isDrawingMode ? 'cursor-crosshair' : 'cursor-grab active:cursor-grabbing'}`}
      >
        {/* Drawing Layer */}
        <svg className="absolute inset-0 w-full h-full z-30 pointer-events-none">
          {lines.map(line => (
            <line 
              key={line.id}
              x1={`${line.x1}%`} y1={`${line.y1}%`}
              x2={`${line.x2}%`} y2={`${line.y2}%`}
              stroke={line.color}
              strokeWidth="2"
              strokeLinecap="round"
              className="drop-shadow-[0_0_3px_rgba(0,0,0,0.5)]"
            />
          ))}
          {currentStart && currentEnd && (
            <line 
              x1={`${currentStart.x}%`} y1={`${currentStart.y}%`}
              x2={`${currentEnd.x}%`} y2={`${currentEnd.y}%`}
              stroke={drawingColor}
              strokeWidth="2"
              strokeLinecap="round"
              strokeDasharray="4 4"
            />
          )}
        </svg>

        <div className={`${settings.showRSI || settings.showMACD ? 'h-[65%]' : 'h-full'}`}>
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={chartData} margin={{ top: 10, right: 0, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={color} stopOpacity={0.25}/>
                  <stop offset="95%" stopColor={color} stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" opacity={0.15} />
              <XAxis dataKey="time" hide domain={zoomDomain || ['auto', 'auto']} type="number" />
              <YAxis domain={['auto', 'auto']} tickFormatter={formatYAxis} axisLine={false} tickLine={false} tick={{ fontSize: 9, fill: '#64748b', fontWeight: 'bold' }} orientation="right" />
              <Tooltip content={<CustomTooltip />} isAnimationActive={false} cursor={!isPanning && !isDrawingMode} />
              <Legend verticalAlign="top" align="right" iconType="circle" wrapperStyle={{ fontSize: '8px', fontWeight: '900', textTransform: 'uppercase', paddingBottom: '20px' }} />
              
              {settings.chartType === 'area' ? (
                <Area name="Price" type="monotone" dataKey="price" stroke={color} fillOpacity={1} fill="url(#colorPrice)" strokeWidth={2.5} isAnimationActive={false} />
              ) : (
                <Line name="Price" type="monotone" dataKey="price" stroke={color} dot={false} strokeWidth={2.5} isAnimationActive={false} />
              )}

              {settings.showMA_Short && <Line name={`SMA ${settings.maShortPeriod}`} type="monotone" dataKey="maShort" stroke="#00d1ff" strokeWidth={1.5} dot={false} isAnimationActive={false} />}
              {settings.showMA_Long && <Line name={`SMA ${settings.maLongPeriod}`} type="monotone" dataKey="maLong" stroke="#fbbf24" strokeWidth={1.5} dot={false} isAnimationActive={false} />}
              {settings.showBB && (
                <>
                  <Line name="BB Upper" type="monotone" dataKey="bbUpper" stroke="#8b5cf6" strokeDasharray="5 5" strokeWidth={1} dot={false} isAnimationActive={false} />
                  <Line name="BB Lower" type="monotone" dataKey="bbLower" stroke="#8b5cf6" strokeDasharray="5 5" strokeWidth={1} dot={false} isAnimationActive={false} />
                </>
              )}
              {/* Hide Brush when drawing to prevent conflict */}
              {!isDrawingMode && (
                <Brush dataKey="time" height={30} stroke="#1e293b" fill="#020617" tickFormatter={(t) => new Date(t).toLocaleDateString()} startIndex={zoomDomain ? zoomDomain[0] : undefined} endIndex={zoomDomain ? zoomDomain[1] : undefined} onChange={(idx) => setZoomDomain([idx.startIndex || 0, idx.endIndex || 0])} />
              )}
            </ComposedChart>
          </ResponsiveContainer>
        </div>

        {settings.showRSI && (
          <div className="h-[15%] border-t border-white/5 pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={chartData}>
                <XAxis dataKey="time" hide domain={zoomDomain || ['auto', 'auto']} type="number" />
                <YAxis domain={[0, 100]} hide />
                <ReferenceLine y={70} stroke="#ff2e5f" strokeDasharray="3 3" opacity={0.4} />
                <ReferenceLine y={30} stroke="#00ffa3" strokeDasharray="3 3" opacity={0.4} />
                <Line name="RSI" type="monotone" dataKey="rsi" stroke="#8b5cf6" dot={false} strokeWidth={2} isAnimationActive={false} />
                <Tooltip content={<CustomTooltip />} cursor={!isPanning && !isDrawingMode} />
                <Legend verticalAlign="top" align="right" iconType="circle" wrapperStyle={{ fontSize: '8px', fontWeight: '900', textTransform: 'uppercase' }} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        )}

        {settings.showMACD && (
          <div className="h-[15%] border-t border-white/5 pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={chartData}>
                <XAxis dataKey="time" hide domain={zoomDomain || ['auto', 'auto']} type="number" />
                <YAxis hide />
                <Line name="MACD" type="monotone" dataKey="macd" stroke="#3b82f6" dot={false} strokeWidth={1.5} isAnimationActive={false} />
                <Line name="Signal" type="monotone" dataKey="signal" stroke="#f43f5e" dot={false} strokeWidth={1.5} isAnimationActive={false} />
                <Tooltip content={<CustomTooltip />} cursor={!isPanning && !isDrawingMode} />
                <Legend verticalAlign="top" align="right" iconType="circle" wrapperStyle={{ fontSize: '8px', fontWeight: '900', textTransform: 'uppercase' }} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>
    </div>
  );
};

export default memo(PriceChart);
