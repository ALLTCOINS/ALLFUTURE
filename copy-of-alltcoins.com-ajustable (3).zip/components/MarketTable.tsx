
import React, { memo } from 'react';
import { Coin } from '../types';
import { Star, ArrowUp, ArrowDown, ArrowUpDown } from 'lucide-react';

interface MarketTableProps {
  coins: Coin[];
  onSelect: (id: string) => void;
  selectedId: string;
  favorites: string[];
  toggleFavorite: (e: React.MouseEvent, id: string) => void;
  sortConfig: { key: keyof Coin; direction: 'asc' | 'desc' } | null;
  onSort: (key: keyof Coin) => void;
}

// Optimized Sparkline
const Sparkline = memo(({ data, isUp }: { data: number[], isUp: boolean }) => {
  if (!data || data.length < 2) return <div className="w-24 h-8 bg-white/5 animate-pulse rounded" />;
  
  const width = 100;
  const height = 30;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  
  const points = data.map((d, i) => {
    const x = (i / (data.length - 1)) * width;
    const y = height - ((d - min) / range) * height;
    return `${x},${y}`;
  }).join(' ');

  return (
    <svg width={width} height={height} className="overflow-visible">
      <polyline 
        points={points} 
        fill="none" 
        stroke={isUp ? '#00ffa3' : '#ff2e5f'} 
        strokeWidth="1.5" 
        strokeLinecap="round" 
        strokeLinejoin="round" 
      />
    </svg>
  );
});

const SortHeader = ({ label, sortKey, activeSort, onSort, align = 'right', className = '' }: any) => {
  const isActive = activeSort?.key === sortKey;
  return (
    <th 
      className={`py-4 px-2 text-[10px] font-black uppercase tracking-wider text-slate-500 cursor-pointer select-none group hover:text-brand-primary transition-colors ${align === 'left' ? 'text-left' : align === 'center' ? 'text-center' : 'text-right'} ${className}`}
      onClick={() => onSort(sortKey)}
    >
      <div className={`flex items-center gap-1 ${align === 'left' ? 'justify-start' : align === 'center' ? 'justify-center' : 'justify-end'}`}>
        {label}
        <span className={`transition-opacity ${isActive ? 'opacity-100 text-brand-primary' : 'opacity-0 group-hover:opacity-50'}`}>
           {isActive && activeSort.direction === 'asc' ? <ArrowUp size={10} /> : <ArrowDown size={10} />}
           {!isActive && <ArrowUpDown size={10} />}
        </span>
      </div>
    </th>
  );
};

const MarketTable: React.FC<MarketTableProps> = ({ 
  coins, 
  onSelect, 
  selectedId, 
  favorites, 
  toggleFavorite, 
  sortConfig, 
  onSort 
}) => {

  const handleImageError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
    e.currentTarget.src = 'https://assets.coingecko.com/coins/images/1/thumb/bitcoin.png';
    e.currentTarget.style.opacity = '0.5';
  };

  return (
    <div className="w-full h-full flex flex-col bg-transparent relative">
      <div className="flex-1 overflow-auto custom-scrollbar">
        <table className="w-full border-collapse min-w-[1000px]">
          <thead className="bg-[#050910]/95 backdrop-blur-md sticky top-0 z-20 shadow-sm border-b border-white/5">
            <tr>
              {/* Strictly controlled widths for the first two columns to minimize gaps */}
              <th className="py-4 pl-4 pr-0 w-[32px] text-center sticky left-0 z-30 bg-[#050910]"></th>
              <SortHeader label="#" sortKey="market_cap_rank" activeSort={sortConfig} onSort={onSort} align="center" className="w-[40px]" />
              <SortHeader label="Asset" sortKey="name" activeSort={sortConfig} onSort={onSort} align="left" />
              <SortHeader label="Price" sortKey="current_price" activeSort={sortConfig} onSort={onSort} />
              <SortHeader label="1h %" sortKey="price_change_percentage_1h_in_currency" activeSort={sortConfig} onSort={onSort} />
              <SortHeader label="24h %" sortKey="price_change_percentage_24h" activeSort={sortConfig} onSort={onSort} />
              <SortHeader label="7d %" sortKey="price_change_percentage_7d_in_currency" activeSort={sortConfig} onSort={onSort} />
              <SortHeader label="Market Cap" sortKey="market_cap" activeSort={sortConfig} onSort={onSort} />
              <SortHeader label="Volume (24h)" sortKey="total_volume" activeSort={sortConfig} onSort={onSort} />
              <SortHeader label="Supply" sortKey="circulating_supply" activeSort={sortConfig} onSort={onSort} />
              <th className="py-4 px-4 text-right text-[10px] font-black uppercase tracking-wider text-slate-500">7 Day Trend</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {coins.map((coin) => {
              const isSelected = selectedId === coin.id;
              const isFav = favorites.includes(coin.id);
              const isUp1h = (coin.price_change_percentage_1h_in_currency || 0) >= 0;
              const isUp24 = (coin.price_change_percentage_24h || 0) >= 0;
              const isUp7d = (coin.price_change_percentage_7d_in_currency || 0) >= 0;

              return (
                <tr 
                  key={coin.id}
                  onClick={() => onSelect(coin.id)}
                  className={`
                    group cursor-pointer transition-none
                    ${isSelected ? 'bg-brand-primary/10' : 'hover:bg-white/[0.02]'}
                  `}
                >
                  {/* Star - Fixed Width */}
                  <td className="py-3 pl-2 pr-0 w-[32px] text-center sticky left-0 z-10 bg-transparent">
                    <button 
                      onClick={(e) => toggleFavorite(e, coin.id)}
                      className="p-1.5 hover:text-brand-primary text-slate-500 transition-colors"
                    >
                      <Star size={12} className={isFav ? "fill-brand-primary text-brand-primary" : "opacity-30 group-hover:opacity-100"} />
                    </button>
                  </td>

                  {/* Rank - Fixed Width */}
                  <td className="py-3 px-0 w-[40px] text-center text-[10px] font-mono font-bold text-slate-500">
                    {coin.market_cap_rank}
                  </td>

                  {/* Name - Tight Left Padding */}
                  <td className="py-3 pl-1 pr-4">
                    <div className="flex items-center gap-2">
                      <img 
                        src={coin.image} 
                        alt={coin.name} 
                        className="w-6 h-6 rounded-full bg-white/5"
                        onError={handleImageError}
                        loading="lazy"
                      />
                      <div className="flex flex-col">
                        <span className="text-sm font-bold text-slate-200 group-hover:text-brand-primary transition-colors truncate max-w-[140px]">
                          {coin.name}
                        </span>
                        <div className="flex items-center gap-1">
                           <span className="text-[9px] font-black uppercase text-slate-500 bg-white/5 px-1 rounded">
                             {coin.symbol}
                           </span>
                        </div>
                      </div>
                    </div>
                  </td>

                  {/* Data Columns */}
                  <td className="py-3 px-2 text-right font-mono font-bold text-sm text-slate-200">
                    ${coin.current_price?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 6 })}
                  </td>

                  <td className={`py-3 px-2 text-right font-mono text-xs font-bold ${isUp1h ? 'text-brand-success' : 'text-brand-danger'}`}>
                    {Math.abs(coin.price_change_percentage_1h_in_currency || 0).toFixed(2)}%
                  </td>

                  <td className={`py-3 px-2 text-right font-mono text-xs font-bold ${isUp24 ? 'text-brand-success' : 'text-brand-danger'}`}>
                    {Math.abs(coin.price_change_percentage_24h || 0).toFixed(2)}%
                  </td>

                  <td className={`py-3 px-2 text-right font-mono text-xs font-bold ${isUp7d ? 'text-brand-success' : 'text-brand-danger'}`}>
                    {Math.abs(coin.price_change_percentage_7d_in_currency || 0).toFixed(2)}%
                  </td>

                  <td className="py-3 px-2 text-right font-mono text-xs text-slate-400">
                    ${(coin.market_cap / 1e9).toLocaleString(undefined, { maximumFractionDigits: 2 })}B
                  </td>

                  <td className="py-3 px-2 text-right font-mono text-xs text-slate-400">
                    ${(coin.total_volume / 1e6).toLocaleString(undefined, { maximumFractionDigits: 2 })}M
                  </td>

                  <td className="py-3 px-2 text-right font-mono text-xs text-slate-400">
                    {(coin.circulating_supply / 1e6).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                    <span className="text-[9px] ml-1 text-slate-600">{coin.symbol.toUpperCase()}</span>
                  </td>

                  <td className="py-3 px-4 text-right min-w-[120px]">
                    <div className="flex justify-end">
                      <Sparkline data={coin.sparkline_in_7d?.price || []} isUp={isUp7d} />
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default MarketTable;
