
import React, { useState } from 'react';
import { ArrowRightLeft, ChevronDown, Calculator, Loader2, CheckCircle2, X } from 'lucide-react';
import { Coin } from '../types';

interface ConverterProps {
  coins: Coin[];
  compact?: boolean;
}

const FIAT_STABLES = [
  { id: 'usd', symbol: 'USD', name: 'US Dollar', price: 1.0, type: 'Fiat', image: 'https://cdn-icons-png.flaticon.com/512/197/197374.png' },
  { id: 'eur', symbol: 'EUR', name: 'Euro', price: 1.08, type: 'Fiat', image: 'https://cdn-icons-png.flaticon.com/512/197/197615.png' },
  { id: 'usdt', symbol: 'USDT', name: 'Tether', price: 1.00, type: 'Stable', image: 'https://assets.coingecko.com/coins/images/325/large/Tether.png' },
];

const Converter: React.FC<ConverterProps> = ({ coins, compact = false }) => {
  const [amount, setAmount] = useState<string>("1.00");
  const [fromCoin, setFromCoin] = useState<string>(coins[0]?.id || 'bitcoin');
  const [toCoin, setToCoin] = useState<string>('usd');
  const [isProcessing, setIsProcessing] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const getPrice = (id: string) => {
    const fiatOrStable = FIAT_STABLES.find(c => c.id === id);
    if (fiatOrStable) return fiatOrStable.price;
    return coins.find(c => c.id === id)?.current_price || 0;
  };

  const getDetails = (id: string) => {
    const fiatOrStable = FIAT_STABLES.find(c => c.id === id);
    if (fiatOrStable) return { ...fiatOrStable, isCrypto: false };
    const coin = coins.find(c => c.id === id);
    return coin ? { ...coin, type: 'Crypto', isCrypto: true, price: coin.current_price } : null;
  };
  
  const numericAmount = parseFloat(amount) || 0;
  const fromPrice = getPrice(fromCoin);
  const toPrice = getPrice(toCoin);
  const result = toPrice > 0 ? (numericAmount * fromPrice) / toPrice : 0;

  const handleFlip = () => {
    const temp = fromCoin;
    setFromCoin(toCoin);
    setToCoin(temp);
    if (result > 0) setAmount(result.toFixed(4));
  };

  const handleConfirm = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
    }, 1500);
  };

  const CoinSelector = ({ value, onChange, label, displayValue, id }: any) => {
    const selected = getDetails(value);
    
    return (
      <div className="bg-[#0a0f18] border border-white/5 p-4 hover:border-orange-500/30 transition-colors group">
        <div className="flex items-center justify-between mb-2">
          <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest group-hover:text-orange-500 transition-colors">{label}</label>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="relative flex items-center gap-2 bg-[#050910] pl-2 pr-3 py-2 border border-white/10 min-w-[120px] hover:border-white/30 transition-colors">
            {selected?.image ? (
              <img src={selected.image} className="w-5 h-5 rounded-none" alt="" />
            ) : (
              <div className="w-5 h-5 bg-slate-700"></div>
            )}
            <div className="flex flex-col">
               <span className="text-xs font-black uppercase text-white">{selected?.symbol}</span>
            </div>
            <ChevronDown size={12} className="text-slate-500 ml-auto" />
            <select 
              value={value}
              onChange={(e) => onChange(e.target.value)}
              className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
            >
              <optgroup label="Fiat & Stablecoins">
                {FIAT_STABLES.map(c => <option key={c.id} value={c.id}>{c.symbol}</option>)}
              </optgroup>
              <optgroup label="Cryptocurrencies">
                {coins.map(c => <option key={c.id} value={c.id}>{c.symbol.toUpperCase()}</option>)}
              </optgroup>
            </select>
          </div>
          
          <div className="flex-1 min-w-0 border-b border-white/10 focus-within:border-orange-500 transition-colors">
            {displayValue !== undefined ? (
              <div className="text-2xl font-mono font-bold text-right text-orange-500 py-1 truncate">
                {displayValue.toLocaleString(undefined, { maximumFractionDigits: displayValue < 1 ? 8 : 4 })}
              </div>
            ) : (
              <input 
                type="number" 
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="bg-transparent text-2xl font-mono font-bold w-full outline-none text-right text-white py-1 placeholder:text-slate-700"
                placeholder="0.00"
              />
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div id="converter-widget" className={`bg-[#050910] h-full flex flex-col relative`}>
      
      {showSuccess && (
        <div className="absolute inset-0 z-50 bg-orange-500 flex flex-col items-center justify-center">
           <CheckCircle2 size={48} className="text-black mb-2 animate-bounce" />
           <span className="text-xl font-black text-black uppercase tracking-tighter">Swap Complete</span>
           <button onClick={() => setShowSuccess(false)} className="mt-4 p-1 text-black border border-black hover:bg-black hover:text-white transition-colors"><X size={20}/></button>
        </div>
      )}

      <div className="p-4 border-b border-white/5 bg-[#0a0f18] flex items-center justify-between">
          <div className="flex items-center gap-2 text-orange-500">
            <Calculator size={16} />
            <h3 className="text-xs font-black uppercase tracking-widest">FX Gateway</h3>
          </div>
          <div className="w-1.5 h-1.5 bg-orange-500 animate-pulse"></div>
      </div>

      <div className="p-4 flex-1 flex flex-col gap-4 justify-center">
          <CoinSelector value={fromCoin} onChange={setFromCoin} label="Sell" id="sell" />
          
          <div className="flex justify-center -my-6 relative z-10">
            <button 
              onClick={handleFlip}
              className="bg-[#050910] text-orange-500 p-2 border border-white/10 hover:border-orange-500 hover:text-white transition-all"
            >
              <ArrowRightLeft size={16} />
            </button>
          </div>

          <CoinSelector value={toCoin} onChange={setToCoin} label="Buy" displayValue={result} id="buy" />

          <button 
            onClick={handleConfirm}
            disabled={isProcessing}
            className="mt-2 w-full bg-orange-500/10 border border-orange-500/50 text-orange-500 py-3 font-black uppercase tracking-widest text-xs hover:bg-orange-500 hover:text-black transition-all disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {isProcessing ? <Loader2 size={14} className="animate-spin" /> : "Execute Swap"}
          </button>
      </div>
    </div>
  );
};

export default Converter;
