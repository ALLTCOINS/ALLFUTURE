
import React from 'react';
import { TrendingUp, TrendingDown, Minus, Zap } from 'lucide-react';
import { NewsArticle } from '../types';

interface NewsTickerProps {
  news: NewsArticle[];
}

const NewsTicker: React.FC<NewsTickerProps> = ({ news }) => {
  if (!news || news.length === 0) return null;

  return (
    <div className="w-full bg-[#020617] border-b border-white/5 h-8 flex items-center overflow-hidden relative z-[49]">
      <div className="bg-brand-primary text-black px-3 h-full flex items-center z-10 font-black text-[9px] uppercase tracking-widest shrink-0 shadow-[0_0_15px_rgba(0,243,255,0.4)]">
        <Zap size={10} className="mr-1 fill-black" />
        Live Intel
      </div>
      
      <div className="flex whitespace-nowrap animate-[marquee_40s_linear_infinite] hover:[animation-play-state:paused]">
        {[...news, ...news].map((item, i) => (
          <a 
            key={i} 
            href={item.url} 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center mx-6 text-[10px] font-mono text-slate-400 hover:text-white transition-colors group"
          >
            <span className={`mr-2 font-bold uppercase ${
              item.sentiment === 'positive' ? 'text-brand-success' : 
              item.sentiment === 'negative' ? 'text-brand-danger' : 'text-slate-500'
            }`}>
              [{item.category || 'Crypto'}]
            </span>
            <span className="group-hover:text-brand-primary transition-colors">{item.title}</span>
            <span className="ml-2 opacity-50">
               {item.sentiment === 'positive' && <TrendingUp size={10} />}
               {item.sentiment === 'negative' && <TrendingDown size={10} />}
               {item.sentiment === 'neutral' && <Minus size={10} />}
            </span>
          </a>
        ))}
      </div>
    </div>
  );
};

export default NewsTicker;
