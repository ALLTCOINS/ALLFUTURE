
import React from 'react';
import { AreaChart, Area, ResponsiveContainer } from 'recharts';
import { Coin } from '../types';

interface CoinCardProps {
  coin: Coin;
  onClick: (id: string) => void;
}

const CoinCard: React.FC<CoinCardProps> = ({ coin, onClick }) => {
  const isUp = coin.price_change_percentage_24h >= 0;
  const sparklineData = coin.sparkline_in_7d?.price.map((val, idx) => ({ id: idx, val })) || [];

  return (
    <div 
      onClick={() => onClick(coin.id)}
      className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-crypto-primary/50 transition-all cursor-pointer group shadow-sm hover:shadow-neon"
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <img src={coin.image} alt={coin.name} className="w-8 h-8 rounded-full" />
          <div>
            <h4 className="font-bold text-sm leading-tight">{coin.name}</h4>
            <span className="text-xs text-slate-500 uppercase">{coin.symbol}</span>
          </div>
        </div>
        <div className="text-right">
          <div className="font-mono font-bold text-sm">
            ${coin.current_price.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </div>
          <div className={`text-xs font-medium ${isUp ? 'text-crypto-success' : 'text-crypto-danger'}`}>
            {isUp ? '+' : ''}{coin.price_change_percentage_24h.toFixed(2)}%
          </div>
        </div>
      </div>

      <div className="h-12 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={sparklineData}>
            <defs>
              <linearGradient id={`grad-${coin.id}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={isUp ? '#10b981' : '#ef4444'} stopOpacity={0.3}/>
                <stop offset="95%" stopColor={isUp ? '#10b981' : '#ef4444'} stopOpacity={0}/>
              </linearGradient>
            </defs>
            <Area 
              type="monotone" 
              dataKey="val" 
              stroke={isUp ? '#10b981' : '#ef4444'} 
              fillOpacity={1} 
              fill={`url(#grad-${coin.id})`} 
              strokeWidth={1.5}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default CoinCard;
