
import React, { useState, useEffect } from 'react';
import { Coupon } from '../types';
import { ExternalLink, Tag, Copy, Check } from 'lucide-react';

interface CouponBannerProps {
  coupons: Coupon[];
}

const CouponBanner: React.FC<CouponBannerProps> = ({ coupons }) => {
  const [index, setIndex] = useState(0);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setIndex((prev) => (prev + 1) % coupons.length);
      setCopied(false);
    }, 6000);
    return () => clearInterval(timer);
  }, [coupons.length]);

  const current = coupons[index];

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(current.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!current) return null;

  return (
    <div className="h-full bg-[#050910] flex flex-col relative overflow-hidden group">
        
        {/* Header */}
        <div className="p-4 border-b border-white/5 bg-[#0a0f18] flex items-center justify-between shrink-0 relative z-10">
           <div className="flex items-center gap-2 text-green-500">
              <Tag size={16} />
              <h3 className="text-xs font-black uppercase tracking-widest">Drops</h3>
           </div>
           <div className="flex gap-1">
                {coupons.map((_, i) => (
                  <div key={i} className={`h-1 w-1 ${i === index ? 'bg-green-500' : 'bg-slate-800'}`} />
                ))}
           </div>
        </div>

        <div className="relative z-10 p-6 flex flex-col justify-between h-full">
           
           <div className="flex flex-col gap-4">
              <div className="flex items-center gap-4">
                 <div className="w-12 h-12 bg-white p-1 flex items-center justify-center shrink-0 border border-white/10">
                     <img src={current.logo} className="w-full h-full object-contain" alt={current.platform} />
                 </div>
                 <div>
                    <h3 className="text-lg font-black text-white uppercase tracking-tighter leading-none mb-1">{current.platform}</h3>
                    <span className="text-[9px] text-green-500 border border-green-500/30 px-2 py-0.5 uppercase tracking-wider">Verified</span>
                 </div>
              </div>
              <p className="text-sm font-bold text-slate-400 uppercase leading-snug min-h-[3rem]">
                 {current.description}
              </p>
           </div>

           <div className="grid grid-cols-2 gap-px bg-white/10 border border-white/10 mt-auto">
              <button 
                onClick={handleCopy}
                className="bg-[#0a0f18] p-3 flex items-center justify-center gap-2 hover:bg-white/5 transition-colors group/btn"
              >
                {copied ? <Check size={14} className="text-green-500" /> : <Copy size={14} className="text-slate-500 group-hover/btn:text-white" />}
                <span className="text-[10px] font-black uppercase text-slate-500 group-hover/btn:text-white">
                    {copied ? 'Copied' : current.code}
                </span>
              </button>
              <a 
                href={current.link} 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-[#0a0f18] p-3 flex items-center justify-center gap-2 hover:bg-green-500 hover:text-black transition-colors text-green-500"
              >
                <span className="text-[10px] font-black uppercase tracking-wider">Claim</span>
                <ExternalLink size={12} />
              </a>
           </div>
        </div>
        
        {/* Background Effect */}
        <div className="absolute right-0 bottom-0 w-48 h-48 bg-green-500/5 blur-[50px] pointer-events-none"></div>
    </div>
  );
};

export default CouponBanner;
