
import React, { useState } from 'react';
import { NewsArticle } from '../types';
import { ExternalLink, TrendingUp, TrendingDown, Minus, Clock, Newspaper, Share2, X, Twitter, Link as LinkIcon } from 'lucide-react';

interface NewsSectionProps {
  news: NewsArticle[];
  loading: boolean;
}

// Reusing the modal component for consistency
const NewsReaderModal = ({ article, onClose }: { article: NewsArticle, onClose: () => void }) => {
  if (!article) return null;
  
  const handleShare = (platform: 'twitter' | 'copy') => {
     const text = encodeURIComponent(`${article.title} - via Alltcoins Terminal`);
     const url = encodeURIComponent(article.url);
     
     if (platform === 'twitter') {
       window.open(`https://twitter.com/intent/tweet?text=${text}&url=${url}`, '_blank');
     } else {
       navigator.clipboard.writeText(`${article.title} ${article.url}`);
     }
  };

  return (
    <div className="fixed inset-0 z-[200] bg-black/80 backdrop-blur-xl flex items-center justify-center p-4 animate-in fade-in duration-200">
       <div className="bg-[#050910] border border-white/10 w-full max-w-4xl rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
         <div className="flex items-center justify-between p-6 border-b border-white/10">
            <div className="flex items-center gap-3">
               <div className="p-2 bg-brand-primary/10 rounded-lg text-brand-primary">
                  <Newspaper size={20} />
               </div>
               <div>
                  <h3 className="text-sm font-black uppercase tracking-widest text-slate-400">Intel Reader</h3>
                  <p className="text-xs font-bold text-white">{article.source}</p>
               </div>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors text-slate-400 hover:text-white">
               <X size={24} />
            </button>
         </div>
         
         <div className="flex-1 overflow-y-auto p-8">
            <h1 className="text-2xl md:text-3xl font-black text-white leading-tight mb-6">{article.title}</h1>
            <p className="text-lg text-slate-300 leading-relaxed font-medium mb-8">
               {article.summary || "Full detailed report available at source."}
            </p>

            <div className="flex gap-4 pt-6 border-t border-white/10">
               <button onClick={() => handleShare('twitter')} className="flex items-center gap-2 px-4 py-2 bg-[#1DA1F2]/10 text-[#1DA1F2] border border-[#1DA1F2]/20 rounded-lg hover:bg-[#1DA1F2] hover:text-white transition-all font-bold text-xs uppercase">
                  <Twitter size={16} /> Tweet
               </button>
               <button onClick={() => handleShare('copy')} className="flex items-center gap-2 px-4 py-2 bg-white/5 text-slate-300 border border-white/10 rounded-lg hover:bg-white/10 hover:text-white transition-all font-bold text-xs uppercase">
                  <LinkIcon size={16} /> Copy Link
               </button>
               <a href={article.url} target="_blank" rel="noopener noreferrer" className="ml-auto flex items-center gap-2 px-6 py-2 bg-brand-primary text-black font-black uppercase tracking-widest text-xs rounded-lg hover:scale-105 transition-transform">
                  Read Source <ExternalLink size={14} />
               </a>
            </div>
         </div>
       </div>
    </div>
  );
};

const NewsSection: React.FC<NewsSectionProps> = ({ news, loading }) => {
  const [readingArticle, setReadingArticle] = useState<NewsArticle | null>(null);

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[1, 2, 3, 4, 5, 6].map(i => (
          <div key={i} className="h-64 bg-slate-100 dark:bg-[#161b22] animate-pulse rounded-2xl border border-slate-200 dark:border-white/5"></div>
        ))}
      </div>
    );
  }

  return (
    <>
      {readingArticle && <NewsReaderModal article={readingArticle} onClose={() => setReadingArticle(null)} />}
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-in fade-in duration-500 pb-20">
        {news.map((item, idx) => (
          <div 
            key={idx} 
            className="group relative flex flex-col justify-between bg-white dark:bg-[#0d1117] p-6 rounded-2xl border border-slate-200 dark:border-white/10 hover:border-brand-primary/50 transition-all duration-300 hover:shadow-[0_0_25px_rgba(0,243,255,0.15)] hover:-translate-y-1 cursor-pointer overflow-hidden"
            onClick={() => setReadingArticle(item)}
          >
            {/* Hover Glow Effect */}
            <div className="absolute inset-0 bg-gradient-to-br from-brand-primary/0 to-transparent group-hover:from-brand-primary/5 transition-all duration-500"></div>

            <div className="relative z-10 flex flex-col h-full">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 rounded bg-slate-100 dark:bg-white/5 text-[9px] font-black uppercase text-slate-600 dark:text-slate-400 tracking-widest border border-slate-200 dark:border-white/5 flex items-center gap-1.5 group-hover:text-brand-primary group-hover:border-brand-primary/20 transition-colors">
                    <Newspaper size={10} />
                    {item.source}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 text-[9px] font-bold text-slate-400 font-mono">
                  <Clock size={10} />
                  <span>{new Date(item.published_at).toLocaleDateString()}</span>
                </div>
              </div>

              <h4 className="font-bold text-lg leading-tight text-slate-900 dark:text-white group-hover:text-brand-primary transition-colors line-clamp-3 mb-3 tracking-tight">
                {item.title}
              </h4>

              {item.summary && (
                <p className="text-xs font-medium text-slate-500 dark:text-slate-400 line-clamp-3 leading-relaxed mb-6">
                  {item.summary}
                </p>
              )}

              <div className="mt-auto pt-4 border-t border-slate-100 dark:border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                    {item.sentiment === 'positive' && (
                      <span className="flex items-center gap-1 text-[9px] font-black uppercase text-brand-success">
                        <TrendingUp size={10} /> Bullish
                      </span>
                    )}
                    {item.sentiment === 'negative' && (
                      <span className="flex items-center gap-1 text-[9px] font-black uppercase text-brand-danger">
                        <TrendingDown size={10} /> Bearish
                      </span>
                    )}
                    {(!item.sentiment || item.sentiment === 'neutral') && (
                      <span className="flex items-center gap-1 text-[9px] font-black uppercase text-slate-500">
                        <Minus size={10} /> Neutral
                      </span>
                    )}
                </div>
                
                <div className="flex items-center gap-3 opacity-60 group-hover:opacity-100 transition-opacity">
                   <div className="flex items-center gap-1 text-[9px] font-black uppercase text-slate-400 group-hover:text-white transition-colors tracking-widest">
                     Read Report <ExternalLink size={10} />
                   </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

export default NewsSection;
