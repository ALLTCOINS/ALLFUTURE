
import React, { useEffect, useRef } from 'react';

interface StarfieldProps {
  className?: string;
}

const Starfield: React.FC<StarfieldProps> = ({ className }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Use parent container dimensions if not fixed full screen
    const updateSize = () => {
      const parent = canvas.parentElement;
      if (parent) {
        canvas.width = parent.clientWidth;
        canvas.height = parent.clientHeight;
      } else {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
      }
    };
    
    updateSize();

    let width = canvas.width;
    let height = canvas.height;

    const stars: {x: number, y: number, z: number, opacity: number}[] = [];
    // Adjust star count based on area approx
    const area = width * height;
    const STAR_COUNT = Math.floor(area / 4000); // Responsive star count
    const SPEED = 0.05;

    for (let i = 0; i < STAR_COUNT; i++) {
      stars.push({
        x: Math.random() * width,
        y: Math.random() * height,
        z: Math.random() * 2 + 0.5,
        opacity: Math.random()
      });
    }

    let animationFrameId: number;

    const animate = () => {
      ctx.clearRect(0, 0, width, height);
      
      ctx.fillStyle = 'rgba(200, 230, 255, 0.8)';

      stars.forEach(star => {
        star.y -= SPEED * star.z;

        if (star.y < 0) {
          star.y = height;
          star.x = Math.random() * width;
        }

        ctx.globalAlpha = star.opacity * (Math.random() * 0.3 + 0.7);
        ctx.beginPath();
        const size = Math.max(0.5, 1.2 * (star.z / 2));
        ctx.arc(star.x, star.y, size, 0, Math.PI * 2);
        ctx.fill();
      });

      animationFrameId = requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      updateSize();
      width = canvas.width;
      height = canvas.height;
    };
    
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return <canvas ref={canvasRef} className={className || "fixed inset-0 z-[-10] pointer-events-none bg-[#010409]"} />;
};

export default Starfield;
