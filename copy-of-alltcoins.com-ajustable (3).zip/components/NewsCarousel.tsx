
import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Newspaper, Clock } from 'lucide-react';
import { NewsArticle } from '../types';

interface NewsCarouselProps {
  news: NewsArticle[];
  loading: boolean;
}

const NewsCarousel: React.FC<NewsCarouselProps> = ({ news, loading }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (news.length > 0) {
      const interval = setInterval(() => {
        setCurrentIndex((prev) => (prev + 1) % news.length);
      }, 7000);
      return () => clearInterval(interval);
    }
  }, [news.length]);

  if (loading || news.length === 0) {
    return (
      <div className="h-full min-h-[300px] bg-slate-200/50 dark:bg-[#0d1117] rounded-[1.5rem] animate-pulse border border-slate-200 dark:border-white/5"></div>
    );
  }

  const current = news[currentIndex];

  return (
    <div className="relative h-full min-h-[300px] bg-white dark:bg-[#0d1117] rounded-[1.5rem] border border-slate-200 dark:border-white/10 overflow-hidden group shadow-lg">
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-brand-primary/10 via-transparent to-brand-secondary/5"></div>
      </div>
      
      <div className="relative z-10 p-8 h-full flex flex-col justify-between">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <Newspaper size={16} className="text-brand-primary" />
            <span className="text-[10px] font-black text-brand-primary uppercase tracking-widest">{current.source}</span>
          </div>
          <div className="flex items-center space-x-1.5 text-[9px] text-slate-500 font-bold uppercase">
            <Clock size={12} />
            <span>{new Date(current.published_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
          </div>
        </div>

        <div className="flex-1 flex flex-col justify-center mb-4">
          {/* NO ITALIC */}
          <h4 className="text-lg md:text-xl font-black uppercase tracking-tighter line-clamp-4 leading-tight text-slate-900 dark:text-white">
            {current.title}
          </h4>
          {current.summary && (
             <p className="text-sm text-slate-500 mt-2 line-clamp-3 leading-relaxed hidden sm:block">
                {current.summary}
             </p>
          )}
        </div>

        <div className="flex items-center justify-between mt-auto">
          <div className="flex space-x-1">
            {news.slice(0, 5).map((_, i) => (
              <div key={i} className={`h-1.5 rounded-full transition-all duration-300 ${i === currentIndex ? 'w-6 bg-brand-primary' : 'w-1.5 bg-slate-300 dark:bg-white/10'}`}></div>
            ))}
          </div>
          <div className="flex space-x-2">
            <button 
              onClick={() => setCurrentIndex(prev => (prev - 1 + news.length) % news.length)}
              className="p-2 bg-slate-100 dark:bg-white/5 rounded-xl border border-slate-200 dark:border-white/5 hover:text-brand-primary transition-colors"
            >
              <ChevronLeft size={16} />
            </button>
            <button 
              onClick={() => setCurrentIndex(prev => (prev + 1) % news.length)}
              className="p-2 bg-slate-100 dark:bg-white/5 rounded-xl border border-slate-200 dark:border-white/5 hover:text-brand-primary transition-colors"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NewsCarousel;
