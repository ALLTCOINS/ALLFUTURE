
import React, { useState, useEffect } from 'react';
import { NewsArticle } from '../types';
import { Newspaper, Clock, ExternalLink, Activity, Loader2, ArrowRight, X, Twitter, Link as LinkIcon, Share2, Zap, Hash, Database, Layers, ShieldCheck, Cpu, Wallet, Code, Image as ImageIcon } from 'lucide-react';
import { generateNewsThumbnail } from '../services/geminiService';

interface NewsPortalProps {
  news: NewsArticle[];
  loading: boolean;
  onRead: (article: NewsArticle) => void;
  onClose: () => void;
}

// -- INTERNAL MODAL COMPONENT (The Retention Engine) --
const NewsReader = ({ 
  article, 
  onClose, 
  allNews,
  onSelectNext
}: { 
  article: NewsArticle, 
  onClose: () => void,
  allNews: NewsArticle[],
  onSelectNext: (article: NewsArticle) => void
}) => {
  if (!article) return null;

  // Find 3 recommended stories, prioritizing same category
  const suggestedNews = allNews
    .filter(n => n.title !== article.title)
    .sort((a, b) => (a.category === article.category ? -1 : 1))
    .slice(0, 3);

  const handleShare = (platform: 'twitter' | 'copy') => {
      const text = encodeURIComponent(`${article.title}`);
      const url = encodeURIComponent(article.url);
      if (platform === 'twitter') {
        window.open(`https://twitter.com/intent/tweet?text=${text}&url=${url}`, '_blank');
      } else {
        navigator.clipboard.writeText(`${article.title} ${article.url}`);
      }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-0 md:p-6 bg-black/95 backdrop-blur-xl animate-in fade-in duration-300">
      <div className="w-full max-w-4xl h-full md:h-[90vh] bg-[#020617] md:rounded-2xl border border-white/10 shadow-2xl flex flex-col relative overflow-hidden">
         
         {/* Modal Header */}
         <div className="flex items-center justify-between p-6 border-b border-white/10 bg-[#020617]/95 backdrop-blur z-20 sticky top-0">
             <div className="flex items-center gap-3">
                 <div className="p-2 bg-brand-primary text-black rounded font-black uppercase text-xs tracking-wider">
                    {article.category || "Intel"}
                 </div>
                 <span className="text-slate-500 text-xs font-mono">{new Date(article.published_at).toLocaleString()}</span>
             </div>
             <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full text-slate-400 hover:text-white transition-colors">
                 <X size={24} />
             </button>
         </div>

         {/* Content Scroll */}
         <div className="flex-1 overflow-y-auto custom-scrollbar p-0">
             {/* Hero Image in Modal */}
             {/* @ts-ignore */}
             {article.imageUrl && (
                 <div className="w-full h-[300px] md:h-[400px] relative">
                    <img 
                       /* @ts-ignore */
                       src={article.imageUrl} 
                       className="w-full h-full object-cover mask-image-b"
                       alt="Cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#020617] via-[#020617]/50 to-transparent"></div>
                 </div>
             )}

             <div className="max-w-3xl mx-auto px-6 py-8 md:-mt-32 relative z-10">
                 <h1 className="text-2xl md:text-5xl font-black text-white leading-tight mb-8 drop-shadow-2xl">
                    {article.title}
                 </h1>
                 
                 <div className="prose prose-invert prose-lg max-w-none">
                     <p className="text-lg md:text-2xl text-slate-200 leading-relaxed font-medium border-l-4 border-brand-primary pl-6 mb-10">
                        {article.summary}
                     </p>
                 </div>

                 <div className="flex flex-wrap gap-4 mt-12 pt-8 border-t border-white/10">
                    <a 
                       href={article.url} 
                       target="_blank" 
                       rel="noopener noreferrer"
                       className="flex-1 md:flex-none flex items-center justify-center gap-3 px-8 py-4 bg-brand-primary text-black font-black uppercase tracking-widest text-sm rounded hover:brightness-110 transition-all shadow-[0_0_20px_rgba(0,243,255,0.3)] hover:shadow-[0_0_30px_rgba(0,243,255,0.5)]"
                    >
                       Read Full Source <ExternalLink size={16} />
                    </a>
                    <button onClick={() => handleShare('twitter')} className="px-6 py-4 bg-[#1DA1F2]/10 text-[#1DA1F2] border border-[#1DA1F2]/20 rounded font-bold uppercase hover:bg-[#1DA1F2] hover:text-white transition-colors">
                       <Twitter size={20} />
                    </button>
                    <button onClick={() => handleShare('copy')} className="px-6 py-4 bg-white/5 text-slate-300 border border-white/10 rounded font-bold uppercase hover:bg-white/10 hover:text-white transition-colors">
                       <Share2 size={20} />
                    </button>
                 </div>
             </div>

             {/* THE VICIOUS CYCLE: Next Stories */}
             <div className="bg-[#0b0e14] border-t border-white/5 py-12 px-6 mt-12">
                 <div className="max-w-4xl mx-auto">
                    <h3 className="text-sm font-black uppercase tracking-[0.2em] text-slate-500 mb-8 flex items-center gap-2">
                       <Activity size={16} className="text-brand-primary" />
                       Continue Briefing
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                       {suggestedNews.map((news, idx) => (
                          <div 
                            key={idx} 
                            onClick={() => onSelectNext(news)}
                            className="group cursor-pointer"
                          >
                             <div className="aspect-video bg-white/5 rounded-lg border border-white/5 overflow-hidden mb-4 relative">
                                {/* @ts-ignore */}
                                {news.imageUrl && (
                                   <img 
                                      /* @ts-ignore */
                                      src={news.imageUrl} 
                                      className="w-full h-full object-cover opacity-60 group-hover:opacity-100 group-hover:scale-110 transition-all duration-500" 
                                   />
                                )}
                                <div className="absolute inset-0 bg-brand-primary/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                             </div>
                             <h4 className="text-sm font-bold text-slate-300 group-hover:text-brand-primary transition-colors leading-snug line-clamp-3">
                                {news.title}
                             </h4>
                          </div>
                       ))}
                    </div>
                 </div>
             </div>
         </div>
      </div>
    </div>
  );
};

const NewsPortal: React.FC<NewsPortalProps> = ({ news, loading, onRead, onClose }) => {
  const [activeTab, setActiveTab] = useState('All');
  const [visibleCount, setVisibleCount] = useState(12);
  const [generatedImages, setGeneratedImages] = useState<Record<string, string>>({});
  const [generating, setGenerating] = useState<Record<string, boolean>>({});
  
  // State for the internal modal
  const [selectedArticle, setSelectedArticle] = useState<NewsArticle | null>(null);

  const categories = [
    { id: 'All', icon: <Newspaper size={12} /> },
    { id: 'Bitcoin', icon: <Hash size={12} /> },
    { id: 'Altcoins', icon: <Layers size={12} /> },
    { id: 'Mining', icon: <Cpu size={12} /> },
    { id: 'Regulation', icon: <ShieldCheck size={12} /> },
    { id: 'DeFi', icon: <Activity size={12} /> },
    { id: 'Tech', icon: <Zap size={12} /> },
    { id: 'Web3', icon: <Database size={12} /> },
    { id: 'Blockchain', icon: <LinkIcon size={12} /> },
    { id: 'NFTs', icon: <Clock size={12} /> },
    { id: 'APIs', icon: <Code size={12} /> },
    { id: 'Trading', icon: <Activity size={12} /> },
    { id: 'Wallets', icon: <Wallet size={12} /> },
    { id: 'Layer2', icon: <Layers size={12} /> },
  ];

  const filteredNews = activeTab === 'All' 
    ? news 
    : news.filter(n => {
        const cat = n.category?.toLowerCase() || '';
        const tab = activeTab.toLowerCase();
        return cat.includes(tab) || n.title.toLowerCase().includes(tab);
    });

  const visibleNews = filteredNews.slice(0, visibleCount);

  // Auto-generate images for visible items
  useEffect(() => {
    visibleNews.forEach(async (article) => {
      // Only generate if we haven't already and aren't currently generating
      if (!generatedImages[article.title] && !generating[article.title]) {
        setGenerating(prev => ({ ...prev, [article.title]: true }));
        
        // Slight delay to stagger api calls to prevent rate limits
        await new Promise(r => setTimeout(r, Math.random() * 3000));
        
        const imageUrl = await generateNewsThumbnail(article.title);
        if (imageUrl) {
          setGeneratedImages(prev => ({ ...prev, [article.title]: imageUrl }));
        }
        setGenerating(prev => ({ ...prev, [article.title]: false }));
      }
    });
  }, [visibleNews, generatedImages, generating]);

  // Pass generated image to the article object when opening
  const handleOpenArticle = (article: NewsArticle) => {
      const enrichedArticle = { ...article, imageUrl: generatedImages[article.title] };
      setSelectedArticle(enrichedArticle);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#020617] p-8 flex items-center justify-center">
        <div className="flex flex-col items-center">
           <div className="w-16 h-16 border-4 border-brand-primary border-t-transparent rounded-none animate-spin"></div>
           <p className="mt-4 text-brand-primary font-black uppercase tracking-widest animate-pulse">Initializing News Feed...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#020617] relative z-0 animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      {/* Internal Reader Modal */}
      {selectedArticle && (
        <NewsReader 
            article={selectedArticle} 
            onClose={() => setSelectedArticle(null)}
            allNews={news.map(n => ({...n, imageUrl: generatedImages[n.title]}))}
            onSelectNext={(next) => handleOpenArticle(next)}
        />
      )}

      {/* Background Tech Grid */}
      <div className="absolute inset-0 pointer-events-none z-[-1] opacity-[0.05]" 
           style={{ backgroundImage: 'linear-gradient(#00f3ff 1px, transparent 1px), linear-gradient(90deg, #00f3ff 1px, transparent 1px)', backgroundSize: '60px 60px' }}>
      </div>

      <div className="max-w-[1800px] mx-auto p-4 md:p-6 relative z-10 pb-24">
        
        {/* Portal Header - Compact */}
        <div className="flex flex-col gap-6 border-b border-white/10 pb-6 mb-8">
          <div className="flex items-center gap-4">
             <div className="p-2 bg-brand-primary text-black rounded-none shadow-[0_0_20px_rgba(0,243,255,0.4)]">
                <Activity size={24} strokeWidth={2.5} />
             </div>
             <div>
                <h1 className="text-2xl md:text-3xl font-black uppercase tracking-tighter text-white">
                   Global <span className="text-brand-primary">Intel</span>
                </h1>
             </div>
          </div>
          
          {/* Scrollable Compact Categories */}
          <div className="w-full overflow-x-auto scrollbar-hide">
            <div className="flex gap-2 min-w-max pb-2">
              {categories.map(cat => (
                  <button
                    key={cat.id}
                    onClick={() => setActiveTab(cat.id)}
                    className={`flex items-center gap-2 px-3 py-1.5 text-[10px] font-black uppercase tracking-wider transition-all rounded-full border ${
                        activeTab === cat.id 
                        ? 'bg-brand-primary text-black border-brand-primary shadow-[0_0_15px_rgba(0,243,255,0.4)]' 
                        : 'bg-white/5 text-slate-400 border-white/10 hover:border-white/30 hover:text-white'
                    }`}
                  >
                    {cat.icon}
                    {cat.id}
                  </button>
              ))}
            </div>
          </div>
        </div>

        {/* High Density Grid - 4 Columns - IMPROVED CARD DESIGN */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-12">
            {visibleNews.map((news, idx) => (
               <div 
                  key={idx} 
                  onClick={() => handleOpenArticle(news)}
                  className="group relative bg-[#0d1117] border border-white/10 hover:border-brand-primary/50 transition-all duration-300 cursor-pointer overflow-hidden flex flex-col h-[380px] rounded-2xl hover:shadow-[0_0_30px_rgba(0,243,255,0.15)] hover:-translate-y-1"
               >
                  {/* Image Container */}
                  <div className="relative h-44 w-full bg-[#050910] border-b border-white/5 overflow-hidden">
                     {generatedImages[news.title] ? (
                        <img 
                           src={generatedImages[news.title]} 
                           alt={news.title} 
                           className="w-full h-full object-cover opacity-80 transition-transform duration-[1.5s] ease-out group-hover:scale-110 group-hover:opacity-100" 
                        />
                     ) : (
                        <div className="w-full h-full flex flex-col items-center justify-center text-slate-600 bg-white/5">
                           {generating[news.title] ? (
                              <Loader2 size={24} className="animate-spin text-brand-primary" />
                           ) : (
                              <ImageIcon size={32} className="opacity-20" />
                           )}
                           <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5"></div>
                        </div>
                     )}
                     
                     <div className="absolute inset-0 bg-gradient-to-t from-[#0d1117] to-transparent opacity-80 group-hover:opacity-60 transition-opacity"></div>

                     {/* Category Tag */}
                     <div className="absolute top-3 left-3 px-2.5 py-1 bg-black/80 backdrop-blur border border-white/10 rounded-md z-20 shadow-lg">
                        <span className="text-[9px] font-black uppercase tracking-widest text-brand-primary">
                            {news.category || 'Crypto'}
                        </span>
                     </div>
                  </div>

                  <div className="p-6 flex flex-col justify-between flex-1 relative z-10 bg-[#0d1117]">
                     <div>
                        <div className="flex justify-between items-start mb-3">
                           <span className="text-[9px] font-mono text-slate-500 uppercase flex items-center gap-1.5 bg-white/5 px-2 py-0.5 rounded">
                              <span className="w-1.5 h-1.5 bg-slate-500 rounded-full group-hover:bg-brand-primary transition-colors"></span>
                              {news.source}
                           </span>
                           <span className="text-[9px] font-mono text-slate-600 flex items-center gap-1">
                                <Clock size={10} />
                                {new Date(news.published_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                           </span>
                        </div>
                        
                        <h3 className="text-sm md:text-base font-bold text-slate-200 leading-snug mb-3 group-hover:text-brand-primary transition-colors line-clamp-3 tracking-tight">
                           {news.title}
                        </h3>
                     </div>
                     
                     {/* Call to Action - Slides In */}
                     <div className="mt-auto pt-4 border-t border-white/5 flex items-center justify-between">
                         <div className="flex items-center gap-2">
                             {news.sentiment === 'positive' && <div className="w-1.5 h-1.5 rounded-full bg-brand-success shadow-[0_0_5px_rgba(34,197,94,0.5)]"></div>}
                             {news.sentiment === 'negative' && <div className="w-1.5 h-1.5 rounded-full bg-brand-danger shadow-[0_0_5px_rgba(255,46,95,0.5)]"></div>}
                             {(!news.sentiment || news.sentiment === 'neutral') && <div className="w-1.5 h-1.5 rounded-full bg-slate-500"></div>}
                             <span className="text-[9px] font-black uppercase text-slate-500">{news.sentiment || 'NEUTRAL'}</span>
                         </div>
                         
                         <div className="flex items-center gap-1 text-slate-500 text-[9px] font-bold uppercase tracking-widest group-hover:text-white transition-colors">
                            Read More <ArrowRight size={10} className="group-hover:translate-x-1 transition-transform" />
                         </div>
                     </div>
                  </div>
               </div>
            ))}
        </div>

        {/* Load More Button */}
        {visibleCount < filteredNews.length && (
           <div className="flex justify-center">
              <button 
                 onClick={() => setVisibleCount(prev => prev + 12)}
                 className="px-8 py-3 bg-white/5 border border-white/10 hover:border-brand-primary hover:text-brand-primary hover:bg-brand-primary/5 transition-all text-xs font-black uppercase tracking-widest shadow-[0_0_15px_rgba(0,0,0,0)] hover:shadow-[0_0_20px_rgba(0,243,255,0.2)] rounded-lg"
              >
                 Load Additional Reports
              </button>
           </div>
        )}

      </div>
    </div>
  );
};

export default NewsPortal;
