
import React, { useState, useEffect } from 'react';
import { X, Wallet, ArrowRightLeft, Info, Loader2, CheckCircle2 } from 'lucide-react';
import { Coin } from '../types';

interface TradeModalProps {
  isOpen: boolean;
  type: 'buy' | 'sell';
  coin: Coin;
  onClose: () => void;
}

const TradeModal: React.FC<TradeModalProps> = ({ isOpen, type, coin, onClose }) => {
  const [amount, setAmount] = useState('');
  const [usdValue, setUsdValue] = useState('');
  const [step, setStep] = useState<'input' | 'processing' | 'success'>('input');
  const [leverage, setLeverage] = useState(1);

  // Reset state on open
  useEffect(() => {
    if (isOpen) {
      setStep('input');
      setAmount('');
      setUsdValue('');
      setLeverage(1);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleAmountChange = (val: string) => {
    setAmount(val);
    const num = parseFloat(val);
    if (!isNaN(num)) {
      setUsdValue((num * coin.current_price).toFixed(2));
    } else {
      setUsdValue('');
    }
  };

  const handleUsdChange = (val: string) => {
    setUsdValue(val);
    const num = parseFloat(val);
    if (!isNaN(num)) {
      setAmount((num / coin.current_price).toFixed(6));
    } else {
      setAmount('');
    }
  };

  const executeTrade = () => {
    if (!amount || parseFloat(amount) <= 0) return;
    setStep('processing');
    
    // Simulate API Latency
    setTimeout(() => {
      setStep('success');
      // Auto close after success
      setTimeout(() => {
        onClose();
      }, 2000);
    }, 1500);
  };

  const fee = parseFloat(usdValue || '0') * 0.001; // 0.1% fee
  const total = parseFloat(usdValue || '0') + (type === 'buy' ? fee : -fee);

  return (
    <div className="fixed inset-0 z-[10000] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-white dark:bg-[#0d1117] border border-slate-200 dark:border-white/10 shadow-2xl overflow-hidden relative flex flex-col">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-white/5 flex items-center justify-between bg-slate-50 dark:bg-white/[0.02]">
          <div className="flex items-center gap-3">
             <div className={`p-2 ${type === 'buy' ? 'bg-brand-success/10 text-brand-success' : 'bg-brand-danger/10 text-brand-danger'}`}>
               <ArrowRightLeft size={20} />
             </div>
             <div>
               <h3 className="text-lg font-black uppercase tracking-tight leading-none">
                 {type === 'buy' ? 'Buy Long' : 'Sell Short'} {coin.symbol}
               </h3>
               <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                 Market Order • Paper Trading
               </span>
             </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-200 dark:hover:bg-white/10 transition-colors">
            <X size={20} className="text-slate-500" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          
          {step === 'input' && (
            <>
              {/* Price Display */}
              <div className="flex justify-between items-end">
                <span className="text-xs font-bold text-slate-500 uppercase">Mark Price</span>
                <span className="text-xl font-mono font-black tracking-tight text-slate-900 dark:text-white">
                  ${coin.current_price?.toLocaleString() ?? 'N/A'}
                </span>
              </div>

              {/* Leverage Selector (Mock) */}
              <div>
                <span className="text-[10px] font-bold text-slate-500 uppercase mb-2 block">Leverage</span>
                <div className="flex gap-2 bg-slate-100 dark:bg-white/5 p-1">
                  {[1, 5, 10, 20].map((lev) => (
                    <button
                      key={lev}
                      onClick={() => setLeverage(lev)}
                      className={`flex-1 py-1.5 text-xs font-black transition-all ${leverage === lev ? 'bg-white dark:bg-[#1e232a] shadow-sm text-brand-primary' : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'}`}
                    >
                      {lev}x
                    </button>
                  ))}
                </div>
              </div>

              {/* Input Fields */}
              <div className="space-y-4">
                <div className="bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/5 p-4 focus-within:border-brand-primary/50 transition-colors">
                  <div className="flex justify-between mb-1">
                    <label className="text-[10px] font-black text-slate-400 uppercase">Amount ({coin.symbol.toUpperCase()})</label>
                  </div>
                  <div className="flex items-center gap-2">
                    <input 
                      type="number" 
                      value={amount}
                      onChange={(e) => handleAmountChange(e.target.value)}
                      placeholder="0.00"
                      className="w-full bg-transparent text-2xl font-mono font-bold outline-none placeholder:text-slate-600"
                    />
                    <div className="shrink-0 flex items-center gap-1">
                       <img src={coin.image} className="w-5 h-5" />
                       <span className="font-bold text-sm">{coin.symbol.toUpperCase()}</span>
                    </div>
                  </div>
                </div>

                <div className="flex justify-center -my-2 relative z-10">
                   <div className="bg-slate-200 dark:bg-[#1e232a] p-1.5 border-4 border-white dark:border-[#0d1117]">
                     <ArrowRightLeft size={14} className="text-slate-500" />
                   </div>
                </div>

                <div className="bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/5 p-4 focus-within:border-brand-primary/50 transition-colors">
                  <div className="flex justify-between mb-1">
                    <label className="text-[10px] font-black text-slate-400 uppercase">Total (USD)</label>
                  </div>
                  <div className="flex items-center gap-2">
                    <input 
                      type="number" 
                      value={usdValue}
                      onChange={(e) => handleUsdChange(e.target.value)}
                      placeholder="0.00"
                      className="w-full bg-transparent text-2xl font-mono font-bold outline-none placeholder:text-slate-600"
                    />
                    <div className="shrink-0 font-bold text-sm text-slate-500">USD</div>
                  </div>
                </div>
              </div>

              {/* Summary */}
              <div className="space-y-2 pt-2">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-500 font-medium">Est. Fee (0.1%)</span>
                  <span className="font-mono font-bold">${fee.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-500 font-medium">Total Cost</span>
                  <span className="font-mono font-bold text-slate-900 dark:text-white">${total.toFixed(2)}</span>
                </div>
              </div>

              {/* Action Button */}
              <button 
                onClick={executeTrade}
                disabled={!amount || parseFloat(amount) <= 0}
                className={`w-full py-4 font-black uppercase tracking-widest text-sm shadow-xl transition-all hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed ${
                  type === 'buy' 
                    ? 'bg-brand-success text-black shadow-brand-success/10 hover:shadow-brand-success/20' 
                    : 'bg-brand-danger text-white shadow-brand-danger/10 hover:shadow-brand-danger/20'
                }`}
              >
                {type === 'buy' ? 'Confirm Long' : 'Confirm Short'}
              </button>
            </>
          )}

          {step === 'processing' && (
            <div className="py-12 flex flex-col items-center justify-center text-center space-y-4">
              <Loader2 size={48} className={`animate-spin ${type === 'buy' ? 'text-brand-success' : 'text-brand-danger'}`} />
              <div>
                <h4 className="text-lg font-black uppercase">Executing Order</h4>
                <p className="text-sm text-slate-500">Routing to matching engine...</p>
              </div>
            </div>
          )}

          {step === 'success' && (
            <div className="py-8 flex flex-col items-center justify-center text-center space-y-4 animate-in zoom-in duration-300">
              <div className={`p-4 rounded-full ${type === 'buy' ? 'bg-brand-success/10 text-brand-success' : 'bg-brand-danger/10 text-brand-danger'}`}>
                 <CheckCircle2 size={48} />
              </div>
              <div>
                <h4 className="text-2xl font-black uppercase">Order Filled</h4>
                <p className="text-sm text-slate-500 font-bold mt-1">
                  {type === 'buy' ? 'Bought' : 'Sold'} {amount} {coin.symbol.toUpperCase()}
                </p>
                <div className="mt-4 p-3 bg-slate-50 dark:bg-white/5 border border-dashed border-slate-300 dark:border-white/10">
                   <p className="text-[10px] text-slate-400 uppercase tracking-widest">Execution Price</p>
                   <p className="font-mono font-bold text-lg">${coin.current_price?.toLocaleString() ?? 'N/A'}</p>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-50 dark:bg-[#080b0f] border-t border-slate-200 dark:border-white/5 flex items-center justify-between">
           <div className="flex items-center gap-1.5 text-slate-400">
             <Wallet size={12} />
             <span className="text-[10px] font-bold uppercase tracking-wider">Avail. Margin</span>
           </div>
           <span className="text-xs font-mono font-black text-slate-900 dark:text-white">$50,000.00</span>
        </div>
      </div>
    </div>
  );
};

export default TradeModal;
