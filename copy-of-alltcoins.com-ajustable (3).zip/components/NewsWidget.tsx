
import React from 'react';
import { Newspaper, ExternalLink, Image as ImageIcon } from 'lucide-react';
import { NewsArticle } from '../types';

interface NewsWidgetProps {
  news: NewsArticle[];
  loading: boolean;
  onRead?: (article: NewsArticle) => void;
}

const NewsWidget: React.FC<NewsWidgetProps> = ({ news, loading, onRead }) => {
  
  // Helper to generate a visual thumbnail based on content
  const getThumbnail = (article: NewsArticle) => {
    const text = (article.title + article.source).toLowerCase();
    
    // Determine color based on sentiment/keywords
    let bgClass = "bg-slate-800";
    let icon = <Newspaper size={14} className="text-slate-400" />;
    
    if (text.includes('bitcoin') || text.includes('btc')) {
        bgClass = "bg-[#F7931A]/20";
        icon = <img src="https://assets.coingecko.com/coins/images/1/thumb/bitcoin.png" className="w-full h-full object-cover opacity-80" />;
    } else if (text.includes('ethereum') || text.includes('eth') || text.includes('defi')) {
        bgClass = "bg-[#627EEA]/20";
        icon = <img src="https://assets.coingecko.com/coins/images/279/thumb/ethereum.png" className="w-full h-full object-cover opacity-80" />;
    } else if (text.includes('bull') || article.sentiment === 'positive') {
        bgClass = "bg-brand-success/20";
        icon = <div className="text-brand-success font-black text-[8px] uppercase">BULL</div>;
    } else if (text.includes('bear') || article.sentiment === 'negative') {
        bgClass = "bg-brand-danger/20";
        icon = <div className="text-brand-danger font-black text-[8px] uppercase">BEAR</div>;
    }

    return (
        <div className={`w-8 h-8 rounded-lg shrink-0 flex items-center justify-center border border-white/5 overflow-hidden ${bgClass}`}>
            {icon}
        </div>
    );
  };

  return (
    <div className="h-full bg-[#050910] flex flex-col">
        <div className="p-4 border-b border-white/5 bg-[#0a0f18] flex items-center justify-between shrink-0">
           <div className="flex items-center gap-2 text-purple-500">
              <Newspaper size={16} />
              <h3 className="text-xs font-black uppercase tracking-widest">Intel Feed</h3>
           </div>
           <span className="w-1.5 h-1.5 bg-purple-500 animate-pulse"></span>
        </div>
        
        <div className="flex-1 overflow-y-auto custom-scrollbar p-0">
           {loading ? (
             [1,2,3,4].map(i => <div key={i} className="h-24 border-b border-white/5 animate-pulse bg-white/5" />)
           ) : (
             news.slice(0, 15).map((item, idx) => (
                <div 
                  key={idx} 
                  onClick={() => onRead && onRead(item)}
                  className="flex gap-3 p-4 border-b border-white/5 hover:bg-purple-500/5 hover:border-l-2 hover:border-l-purple-500 transition-all group cursor-pointer relative pl-4 hover:pl-6"
                >
                  {/* Thumbnail */}
                  {getThumbnail(item)}

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                        <span className="text-[8px] font-black uppercase text-purple-400 border border-purple-500/30 px-1.5 py-0.5 rounded">{item.source}</span>
                        <span className="text-[9px] text-slate-500 font-mono">{new Date(item.published_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                    </div>
                    <h4 className="text-[11px] font-bold leading-snug text-slate-300 group-hover:text-white transition-colors line-clamp-2">
                        {item.title}
                    </h4>
                    {item.sentiment && (
                        <div className="mt-1.5 flex items-center gap-1">
                            <div className={`h-0.5 w-4 ${item.sentiment === 'positive' ? 'bg-green-500' : item.sentiment === 'negative' ? 'bg-red-500' : 'bg-slate-500'}`}></div>
                            <span className="text-[8px] uppercase text-slate-600 group-hover:text-slate-400">{item.sentiment}</span>
                        </div>
                    )}
                  </div>
                  
                  <ExternalLink size={10} className="absolute top-4 right-4 text-purple-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
             ))
           )}
        </div>
    </div>
  );
};

export default NewsWidget;
