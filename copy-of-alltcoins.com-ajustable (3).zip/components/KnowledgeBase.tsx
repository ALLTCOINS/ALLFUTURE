
import React, { useState } from 'react';
import { BookOpen, ChevronDown, ChevronUp, Cpu, Globe, Layers, ShieldCheck, Zap, X, Coins, Activity, Lock } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface KnowledgeBaseProps {
  isOpen: boolean;
  onClose: () => void;
}

const TOPICS = [
  {
    id: 'bitcoin',
    title: 'What is Bitcoin?',
    icon: <Zap size={18} className="text-[#F7931A]" />,
    content: "Bitcoin is the first decentralized digital currency. Think of it as 'Digital Gold'. Unlike fiat money (USD, EUR) controlled by governments, Bitcoin runs on a network of computers (nodes) that verify transactions without a middleman. It is scarce (only 21 million will ever exist) and secure."
  },
  {
    id: 'defi',
    title: 'What is DeFi?',
    icon: <Layers size={18} className="text-[#627EEA]" />,
    content: "DeFi stands for Decentralized Finance. It's a financial system built on blockchain technology that removes intermediaries like banks. With DeFi, you can lend, borrow, and trade directly with others using smart contracts (code that executes automatically)."
  },
  {
    id: 'nft',
    title: 'Understanding NFTs',
    icon: <Cpu size={18} className="text-[#E84142]" />,
    content: "NFTs (Non-Fungible Tokens) represent digital ownership. While one Bitcoin is equal to another Bitcoin (fungible), an NFT is unique (non-fungible). It can represent art, music, game items, or even real-world assets like real estate deeds, proving you are the sole owner on the blockchain."
  },
  {
    id: 'web3',
    title: 'The Web3 Revolution',
    icon: <Globe size={18} className="text-[#00f3ff]" />,
    content: "Web1 was 'Read-Only' (static pages). Web2 was 'Read-Write' (Social Media, but owned by corporations). Web3 is 'Read-Write-Own'. It gives users control over their data and identity through wallets and blockchain, rather than logging in with Google or Facebook."
  },
  {
    id: 'stablecoins',
    title: 'What are Stablecoins?',
    icon: <Coins size={18} className="text-[#26A17B]" />,
    content: "Stablecoins are cryptocurrencies pegged to stable assets like the US Dollar (USDT, USDC). They offer the speed and decentralization of crypto without the extreme volatility, making them ideal for trading pairs and storing value temporarily."
  },
  {
    id: 'mining-staking',
    title: 'Mining vs. Staking',
    icon: <Activity size={18} className="text-[#A020F0]" />,
    content: "Mining (Proof of Work) involves solving complex puzzles to secure the network (like Bitcoin), requiring energy. Staking (Proof of Stake) involves locking up coins to validate transactions (like Ethereum), which is more energy-efficient and earns rewards (yield)."
  },
  {
    id: 'security',
    title: 'Wallet Security 101',
    icon: <ShieldCheck size={18} className="text-brand-success" />,
    content: "Your 'Private Key' or 'Seed Phrase' is the master key to your funds. Never share it. A 'Hot Wallet' (like MetaMask) is connected to the internet and good for trading. A 'Cold Wallet' (like Ledger) is offline and best for long-term storage. Not your keys, not your coins."
  }
];

const KnowledgeBase: React.FC<KnowledgeBaseProps> = ({ isOpen, onClose }) => {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-300">
      <div className="w-full max-w-2xl bg-[#050910] border border-brand-primary/30 rounded-3xl shadow-[0_0_50px_rgba(0,243,255,0.1)] flex flex-col max-h-[85vh] overflow-hidden relative">
        
        {/* Header */}
        <div className="p-6 border-b border-white/10 flex items-center justify-between bg-gradient-to-r from-brand-primary/10 to-transparent">
           <div className="flex items-center gap-3">
              <div className="p-2 bg-brand-primary text-black rounded-lg">
                <BookOpen size={24} strokeWidth={2.5} />
              </div>
              <div>
                <h2 className="text-xl font-black uppercase tracking-tighter text-white">Crypto Academy</h2>
                <p className="text-[10px] text-brand-primary font-bold uppercase tracking-widest">Master the Blockchain</p>
              </div>
           </div>
           <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors text-slate-400 hover:text-white">
             <X size={24} />
           </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-4">
           <p className="text-slate-400 text-sm mb-6 leading-relaxed">
             Welcome to the Nexus of Knowledge. Here we break down complex protocols into actionable intelligence. Click a module below to synchronize your understanding.
           </p>

           {TOPICS.map((topic) => (
             <div 
               key={topic.id}
               className={`border rounded-xl transition-all duration-300 overflow-hidden ${
                 expandedId === topic.id 
                 ? 'border-brand-primary bg-brand-primary/5 shadow-[0_0_15px_rgba(0,243,255,0.1)]' 
                 : 'border-white/10 bg-white/[0.02] hover:border-brand-primary/50'
               }`}
             >
               <button 
                 onClick={() => setExpandedId(expandedId === topic.id ? null : topic.id)}
                 className="w-full flex items-center justify-between p-4 text-left"
               >
                 <div className="flex items-center gap-4">
                    <div className={`p-2 rounded-lg transition-colors ${expandedId === topic.id ? 'bg-brand-primary text-black' : 'bg-white/5 text-slate-400'}`}>
                      {topic.icon}
                    </div>
                    <span className={`text-sm font-bold uppercase tracking-wider ${expandedId === topic.id ? 'text-white' : 'text-slate-300'}`}>
                      {topic.title}
                    </span>
                 </div>
                 {expandedId === topic.id ? <ChevronUp size={16} className="text-brand-primary" /> : <ChevronDown size={16} className="text-slate-500" />}
               </button>
               
               <AnimatePresence>
                 {expandedId === topic.id && (
                   <motion.div 
                     initial={{ height: 0, opacity: 0 }}
                     animate={{ height: 'auto', opacity: 1 }}
                     exit={{ height: 0, opacity: 0 }}
                     className="px-4 pb-5 pl-[4.5rem] pr-6"
                   >
                      <p className="text-slate-300 text-sm leading-7 font-medium border-l-2 border-brand-primary/30 pl-4">
                        {topic.content}
                      </p>
                   </motion.div>
                 )}
               </AnimatePresence>
             </div>
           ))}
        </div>

        {/* Footer */}
        <div className="p-4 bg-black/20 border-t border-white/5 text-center">
           <p className="text-[10px] text-slate-500 font-mono uppercase">
              Knowledge is the ultimate alpha.
           </p>
        </div>

      </div>
    </div>
  );
};

export default KnowledgeBase;
